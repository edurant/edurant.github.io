// $Id: main.cpp,v 1.2 2005/02/03 19:27:22 durant Exp durant $
// Branched from GLUT version:
// main.cpp,v 1.9 2003/12/03 21:59:15 durant Exp

// Lego class test program
// Author: Dr. Eric Durant <durant@msoe.edu>
// Original version: Thursday 19 December 2002
// Revised for QGLWidget: Wednesday 3 December 2003
// Revised for blending: Thursday 3 February 2005

#ifdef _WIN32
#include <windows.h>
#endif // _WIN32

#ifdef __GNUC__
#include <cstdlib> // EXIT_SUCCESS
#endif // __GNUC__

#include <qapplication.h>
#include <qgl.h> // QGLFormat::hasOpenGL
#include "GLObjectWindow.h"

int main (int argc, char** argv)
{
	QApplication::setColorSpec( QApplication::CustomColor );
	QApplication theApp(argc, argv);

	if ( !QGLFormat::hasOpenGL() )
	{
		qWarning( "This system has no OpenGL support. Exiting." );
		return EXIT_FAILURE;
	}

	GLObjectWindow window(NULL, "CS421 Blending Example");
	window.resize(500, 500);
	theApp.setMainWidget( &window );
	window.show();

	return theApp.exec();
}
