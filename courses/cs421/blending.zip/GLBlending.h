// $Id: GLBlending.h,v 1.2 2005/02/03 19:27:40 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for blending: Thursday 3 February 2005

// This QGLWidget encapsulates an OpenGL blending example.

#ifndef GLBLENDING_H
#define GLBLENDING_H

#include <qgl.h>

class GLBlending : public QGLWidget
{
	Q_OBJECT

public:
	GLBlending(QWidget* parent, const char* name = NULL);
	~GLBlending();

protected:
	void initializeGL();
	void paintGL();
	void resizeGL(int w, int h);
};

#endif
