// $Id: GLObjectWindow.cpp,v 1.3 2005/02/03 19:27:14 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for blending: Thursday 3 February 2005
// Some Qt revisions based on Qt globjwin.cpp sample code

#include <qlayout.h>
#include <qframe.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qapplication.h>
#include "GLObjectWindow.h"
#include "GLBlending.h"

GLObjectWindow::GLObjectWindow(QWidget* parent, const char* name)
    : QWidget(parent, name)
{
    // Create a menu
    QPopupMenu *file = new QPopupMenu(this);
    file->insertItem("Exit", qApp, SLOT(quit()), CTRL+Key_Q);

    // Create a menu bar
    QMenuBar *mb = new QMenuBar(this);
    mb->setSeparator(QMenuBar::InWindowsStyle);
    mb->insertItem("&File", file );

    // Create our OpenGL widget
    GLBlending* glwidget = new GLBlending(this);

    // Now that we have all the widgets, put them into a layout
    QVBoxLayout* vblayout = new QVBoxLayout(this);
    vblayout->addWidget(glwidget);

    vblayout->setMenuBar(mb);
}
