// $Id: GLObjectWindow.h,v 1.2 2005/02/03 19:27:51 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for blending: Thursday 3 February 2005
// Some Qt revisions based on Qt globjwin.h sample code

// This GLObjectWindow represents the GUI shell and contains a GLBlending widget.

#ifndef GLOBJECTWINDOW_H
#define GLOBJECTWINDOW_H

#include <qwidget.h>

class GLObjectWindow : public QWidget
{
    Q_OBJECT
public:
    GLObjectWindow(QWidget* parent = 0, const char* name = 0);
};

#endif // GLOBJECTWINDOW_H
