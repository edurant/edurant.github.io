// $Id: GLBlending.cpp,v 1.3 2005/02/03 19:26:55 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for blending: Thursday 3 February 2005

#include "GLBlending.h"

#if defined(Q_CC_MSVC)
#pragma warning(disable:4305) // init: truncation from const double to float
#endif

GLBlending::GLBlending( QWidget* parent, const char* name )
    : QGLWidget( parent, name )
{}

GLBlending::~GLBlending()
{
	makeCurrent();
	// Call glDeleteLists, if needed, here.
}

void GLBlending::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear all pixels and the depth buffer

	glBegin(GL_TRIANGLES);

	// red triangle
	glColor3f(1.0, 0.0, 0.0);
	glVertex3i(0, 0, 0);
	glVertex3i(1, 0, 0);
	glVertex3i(1, 1, 0);

	// partially overlapping green triangle
	glColor3f(0.0, 1.0, 0.0);
	glVertex3i(1, 0, -1);
	glVertex3i(1, 1, 1);
	glVertex3i(0, 1, 1);

	glEnd();

	// now overlay the translucent objects
	glDepthMask(GL_FALSE); // generates OpenGL error if executed between glBegin and glEnd

	glBegin(GL_TRIANGLES);

	// partially overlapping triangle - between center overlap point and other translucent triangle
	glColor4f(1.0, 1.0, 0.0, 0.4); // translucent yellow
	glVertex3f(0.8, 0.2, 0.1);
	glVertex3f(0.8, 0.8, 0.1);
	glVertex3f(0.2, 0.5, 0.1);

	// partially overlapping triangle - slightly in front of center overlap point
	glColor4f(0.0, 0.0, 1.0, 0.7); // nearly opaque blue
	glVertex3f(0.2, 0.2, 0.3);
	glVertex3f(0.2, 0.8, 0.3);
	glVertex3f(0.8, 0.5, 0.3);

	glEnd();

	glDepthMask(GL_TRUE);
}

void GLBlending::initializeGL()
{
	printf("OpenGL Information...\n");
	printf("    Vendor: %s\n", glGetString(GL_VENDOR));
	printf("  Renderer: %s\n", glGetString(GL_RENDERER));
	printf("   Version: %s\n", glGetString(GL_VERSION));
//	printf("Extensions: %s\n", glGetString(GL_EXTENSIONS));

	printf("Qt Information...\n");
	printf("   Version: %s\n", qVersion());

	qglClearColor(black); // more convenient than glClearColor

	glEnable(GL_DEPTH_TEST);
	// glEnable(GL_NORMALIZE);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // source, destination - let source alpha be the OPACITY

	glShadeModel(GL_SMOOTH);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); // no viewing transformation for this simple example

	// Generate an OpenGL display list here, if needed.
}

void GLBlending::resizeGL( int w, int h )
{
	glViewport(0, 0, w, h); // use the whole window
	if (w > 0 && h > 0) // if not minimized...
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		float xe = 1.0, ye = 1.0;
		if (w>h)
			xe *= static_cast<float>(w)/h;
		else
			ye *= static_cast<float>(h)/w;

		glOrtho(0, xe, 0, ye, -5, 5);

		glMatrixMode(GL_MODELVIEW); // only reshape touches the projection
	}
}
