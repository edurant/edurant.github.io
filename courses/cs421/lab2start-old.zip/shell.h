/*!
	$Id: shell.h,v 1.2 2003/12/12 18:50:43 durant Exp durant $
*/

#ifndef SHELL_H
#define SHELL_H

#include <qwidget.h>

/// QWidget derived class that represents the GUI shell and contains a "myGlWidget"..
/** Original GLUT version: Thursday 19 December 2002
 *  Revised for Qt: Wednesday 3 December 2003, Monday 6 December 2004
 *
 *  Some Qt revisions based on Qt globjwin.h sample code
 *  
 *  In a future version, user interface QWidgets (e.g., sliders) could be 
 *  created and connected to "myGlWidget" slots.
 *  
 *  \author Dr. Eric Durant <durant@msoe.edu>
 * 
 *  \todo Document todo items thusly. 
 */
class shell : public QWidget
{
    Q_OBJECT
public:
    shell(QWidget* parent = 0, const char* name = 0); ///< Construct a shell, given its parent and name (both optional)
};

#endif // SHELL_H
