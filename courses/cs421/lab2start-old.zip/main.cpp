/*!
   $Id: main.cpp,v 1.1 2003/12/12 18:15:02 durant Exp durant $

   Branched from GLUT version: main.cpp,v 1.9 2003/12/03 21:59:15 durant Exp

   CS421 Lab 2 Demo Program

   Original version: Thursday 19 December 2002

   Revised: Wednesday 3 December 2003, Monday 6 December 2004

   \author Dr. Eric Durant <durant@msoe.edu>
 */

#ifdef _WIN32
#include <windows.h>
#endif // _WIN32

#ifdef __GNUC__
#include <cstdlib> // EXIT_SUCCESS
#endif // __GNUC__

#include <qapplication.h>
#include <qgl.h> // QGLFormat

#include "shell.h"

/// Application entry point that creates the QApplication and its main widget and starts the event loop.
int main (int argc, char** argv)
{
	QApplication::setColorSpec( QApplication::CustomColor );
	QApplication theApp(argc, argv); // QApplication handles instead of glutInit
	// check documentation if you wish to use command line arguments

	if ( !QGLFormat::hasOpenGL() )
	{
		qWarning( "This system has no OpenGL support. Exiting." );
		return EXIT_FAILURE;
	}

	shell window(NULL, "CS421 Lab 2 Example"); // caption would normally be in glutCreateWindow Call
	window.resize(500, 500); // instead of glutInitWindowSize
	theApp.setMainWidget(&window);
	window.show();

	return theApp.exec();
}
