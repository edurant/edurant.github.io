/*!
   $Id: myGlWidget.h,v 1.2 2003/12/12 18:45:40 durant Exp durant $
 */

#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <qgl.h>

/// This QGLWidget encapsulates application specific OpenGL behavior in Qt.
/**Original GLUT version: Thursday 19 December 2002
 *
 * Revised for Qt: Wednesday 3 December 2003, Monday 6 December 2004
 *
 * \author Dr. Eric Durant <durant@msoe.edu>
 */ 
class myGlWidget : public QGLWidget
{
    Q_OBJECT

public:
    /// Constructor (verbose documentation format, use only if needed, end with period).
    /** This is the detailed documentation,
     *  which may span multiple lines.  Some newer versions of doxygen support [in] and [out] attributes.
     * @param parent the parent widget, for proper cascaded destruction
     * @param name   the title of the window
     */
    myGlWidget(QWidget* parent, const char* name );

    ~myGlWidget();

protected:
//@{
/** @name virtual functions replacing the basic GLUT callbacks and functions. */
	void initializeGL();
	void paintGL();
	void resizeGL( int w, int h );
//@}

private:

};

#endif // MYGLWIDGET_H
