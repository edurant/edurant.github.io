// $Id: GLShadowVolumes.h,v 1.1 2005/02/07 03:56:40 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for shadow volumes: Sunday 6 February 2005

// This QGLWidget encapsulates an OpenGL shadow volumes example.
// It has been updated to make use of Qt's timer functions.

#ifndef GLSHADOWVOLUMES_H
#define GLSHADOWVOLUMES_H

#include <qgl.h>
#include <qdatetime.h> // QTime

class GLShadowVolumes : public QGLWidget
{
	Q_OBJECT

public:
	GLShadowVolumes(QWidget* parent, const char* name = NULL);
	~GLShadowVolumes();

public slots:
	/*virtual*/ void polish();

protected:
	void initializeGL();
	void paintGL();
	void resizeGL(int w, int h);

private:
	struct surface * new_surface(const float vertices[4][3]);
	void render_surface_shadow_volume(struct surface *surf, // offset from overall position for the vertices in this surface
                             const float *surf_pos, // spatial position of the surface "center"
							 const float *light_pos); // spatial position of the point light source
	struct cube * new_cube(float size);
	unsigned int generate_lightmap(const struct surface * const surf, const float * const position);
	void draw_shadow();
	void render_surface(const struct surface * const surf, const float * const position);
	void render_cube(const struct cube * const c);
	void render_cube_shadow(const struct cube * const c);

private slots:
	void scene_cycle();

private:
	QTime myTime; // for measuring intervals while moving light source

	float light_pos[3];
	/*const*/ float light_color[3];
	float sphere_pos[3];
};

#endif
