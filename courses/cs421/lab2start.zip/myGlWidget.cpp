/*!
   $Id: myGlWidget.cpp,v 1.2 2003/12/12 18:45:20 durant Exp durant $

   Original GLUT version: Thursday 19 December 2002

   Revised for Qt: Wednesday 3 December 2003, Monday 6 December 2004

   \author Dr. Eric Durant <durant@msoe.edu>
 */

#include "myGlWidget.h"

#if defined(Q_CC_MSVC)
#pragma warning(disable:4305) // init: truncation from const double to float
#endif

myGlWidget::myGlWidget( QWidget* parent, const char* name )
    : QGLWidget( parent, name )
{}

myGlWidget::~myGlWidget()
{
	makeCurrent();
	// Call glDeleteLists, if needed, here.
}

/// Analogous to display callback in GLUT - called whenever an exposure/redraw event occurs.  Paint the frame. The actual OpenGL commands for drawing are performed here. 
void myGlWidget::paintGL()
{
}

/// Analogous to init callback in GLUT
void myGlWidget::initializeGL()
// Utility initialization routine to set-up OpenGL projection
// and viewing modes, rendering state, and, if needed, display lists.
{
	printf("OpenGL Information...\n");
	printf("    Vendor: %s\n", glGetString(GL_VENDOR));
	printf("  Renderer: %s\n", glGetString(GL_RENDERER));
	printf("   Version: %s\n", glGetString(GL_VERSION));
/*	printf("Extensions: %s\n", glGetString(GL_EXTENSIONS)); */

	printf("Qt Information...\n");
	printf("   Version: %s\n", qVersion());

	// Now do the real work...
}

/// Analogous to reshape callback in GLUT.  Routine to be invoked whenever a reshape event occurs.  Set up the OpenGL view port, matrix mode, etc.
void myGlWidget::resizeGL( int w, int h )
{
	w = h; // avoid compiler warning; replace with real code ASAP
}
