/*!
   $Id: shell.cpp,v 1.2 2003/12/12 18:50:51 durant Exp durant $

   Original GLUT version: Thursday 19 December 2002

   Revised for Qt: Wednesday 3 December 2003, Monday 6 December 2004

   Some Qt revisions based on Qt globjwin.cpp sample code

   \author Dr. Eric Durant <durant@msoe.edu>
 */

#include <qlayout.h>
#include <qframe.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qapplication.h>
#include "shell.h"
#include "myGlWidget.h"

/// The constructor creates a shell with some Qt GUI elements and a myGlWidget for OpenGL drawing.
shell::shell( QWidget* parent, const char* name )
    : QWidget( parent, name )
{
    // Create a menu
    QPopupMenu *file = new QPopupMenu( this );
    file->insertItem( "Exit",  qApp, SLOT(quit()), CTRL+Key_Q );

    // Create a menu bar
    QMenuBar *pMenuBar = new QMenuBar( this );
    pMenuBar->setSeparator( QMenuBar::InWindowsStyle );
    pMenuBar->insertItem("&File", file );

    // Create a nice frame to put around the OpenGL widget
    QFrame* pFrame = new QFrame( this, "frame" );
    pFrame->setFrameStyle( QFrame::Sunken | QFrame::Panel );
    pFrame->setLineWidth( 2 );

    // Create our OpenGL widget
    myGlWidget* pMyGlWidget = new myGlWidget(pFrame, "My GL Widget");

    // set up any UI QWidgets (e.g., QSliders) here, connect their signals to
    // the needed slots.

    // Stack the widgets on top of each other (change if desired)
    // Put the sliders on top of each other
    QVBoxLayout* pVBoxLayout = new QVBoxLayout(20); // spacing
    // vlayout->addWidget(eachWidgetCreatedAbove);

    // Put the GL widget inside the frame
    QHBoxLayout* pLayoutInFrame = new QHBoxLayout(pFrame, 2, 2); // parent, margin, spacing
    pLayoutInFrame->addWidget(pMyGlWidget, 1); // stretch factor

    // Top level layout, puts the GUI widgets to the left of the frame/GL widget
    QHBoxLayout* pTopHBoxLayout = new QHBoxLayout(this, 20, 20);
    pTopHBoxLayout->setMenuBar(pMenuBar);
    pTopHBoxLayout->addLayout(pVBoxLayout);
    pTopHBoxLayout->addWidget(pFrame, 1);
}
