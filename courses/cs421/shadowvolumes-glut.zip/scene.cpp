// $Id: scene.cpp,v 1.2 2004/02/05 19:23:44 durant Exp durant $
// Shadow Volume Example
// Based heavily upon
//    http://www.3ddrome.com/articles/shadowvolumes.php
// updated by Dr. E. Durant <durant@msoe.edu>
//    Documented key sections, simplified

/*
 * Copyright (C) 2003-2004 Josh A. Beam
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <cstdio> // fprintf
#include <ctime>
#include <cmath>
#include <GL/glut.h>

#pragma warning(push, 4)

#define CUBE_FACES 6

struct surface
{
	float vertices[4][3]; // quadrilaterals in 3-D
	float matrix[9]; // for "lightmap" -- IGNORE this when studying how the shadows work

	float s_dist, t_dist; // for "lightmap"
};

struct cube
// To simplify some parts of the algorithm, a cube is stored as a center position with
// six faces stored RELATIVE to that center.
{
	struct surface *surfaces[CUBE_FACES];
	float position[3];
};

// 4 standard matrix/vector functions
static float dot_product(const float v1[3], const float v2[3])
{
	return (v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]);
}

static void normalize(float v[3])
{
	float f = 1.0f / sqrt(dot_product(v, v));
	v[0] *= f; v[1] *= f; v[2] *= f;
}

static void cross_product(const float * const v1, const float * const v2, float * const out)
{
	out[0] = v1[1] * v2[2] - v1[2] * v2[1];
	out[1] = v1[2] * v2[0] - v1[0] * v2[2];
	out[2] = v1[0] * v2[1] - v1[1] * v2[0];
}

static void multiply_vector_by_matrix(const float m[9], float v[3])
{
	float tmp[3];

	tmp[0] = v[0] * m[0] + v[1] * m[3] + v[2] * m[6];
	tmp[1] = v[0] * m[1] + v[1] * m[4] + v[2] * m[7];
	tmp[2] = v[0] * m[2] + v[1] * m[5] + v[2] * m[8];

	v[0] = tmp[0];
	v[1] = tmp[1];
	v[2] = tmp[2];
}

static struct surface * new_surface(const float vertices[4][3])
// create a surface given vertices -- most of this is for lightmapping
// unimportant for observing how shadows work
{
	struct surface* surf = new surface;
	if(!surf)
	{
		fprintf(stderr, "Error: Couldn't allocate memory for surface\n");
		return NULL;
	}

	for(unsigned int i = 0; i < 4; i++) // quadrilaterals
	{
		for(unsigned int j = 0; j < 3; j++) // dimensions
			surf->vertices[i][j] = vertices[i][j];
	}

	/* x axis of matrix points in world space direction of the s texture axis */
	for(i = 0; i < 3; i++) // dimensions
		surf->matrix[0 + i] = surf->vertices[3][i] - surf->vertices[0][i];
	surf->s_dist = sqrt(dot_product(surf->matrix, surf->matrix));
	normalize(surf->matrix);

	/* y axis of matrix points in world space direction of the t texture axis */
	for(i = 0; i < 3; i++) // dimensions
		surf->matrix[3 + i] = surf->vertices[1][i] - surf->vertices[0][i];
	surf->t_dist = sqrt(dot_product(surf->matrix + 3, surf->matrix + 3));
	normalize(surf->matrix + 3);

	/* z axis of matrix is the surface's normal */
	cross_product(surf->matrix, surf->matrix + 3, surf->matrix + 6);

	return surf;
}

static void render_surface_shadow_volume(struct surface *surf, // offset from overall position for the vertices in this surface
                             const float *surf_pos, // spatial position of the surface "center"
							 const float *light_pos) // spatial position of the point light source
// Given a 2-D quadrilateral surface (surf, the "front cap"), render the corresponding
// shadow volume.  This is the object casting the shadow.  The vertices in surf
// are relative to the provided position, so these quantities are added together
// to get the "absolute" surface position.
{
	static const float M_INFINITY = 50.0f;

 	float v[4][3];

	for(unsigned int i = 0; i < 4; i++)
	{
		surf->vertices[i][0] += surf_pos[0]; // absolute surface position
		surf->vertices[i][1] += surf_pos[1];
		surf->vertices[i][2] += surf_pos[2];

		v[i][0] = (surf->vertices[i][0] - light_pos[0]); // ray from light to
		v[i][1] = (surf->vertices[i][1] - light_pos[1]); // surface casting shadow
		v[i][2] = (surf->vertices[i][2] - light_pos[2]);
		normalize(v[i]);
		v[i][0] *= M_INFINITY; // Move vertex "far enough" out so that shadow volume is 
		v[i][1] *= M_INFINITY; // large enough to cover any shadowed objects.
		v[i][2] *= M_INFINITY;
	}

	/* back cap */
	glBegin(GL_QUADS);
		glVertex3fv(v[3]); // order used to determine front/back face
		glVertex3fv(v[2]); // (inside/outside of shadow volume)
		glVertex3fv(v[1]);
		glVertex3fv(v[0]);
	glEnd();

	/* front cap */
	glBegin(GL_QUADS);
		glVertex3fv(surf->vertices[0]);
		glVertex3fv(surf->vertices[1]);
		glVertex3fv(surf->vertices[2]);
		glVertex3fv(surf->vertices[3]);
	glEnd();

	glBegin(GL_QUAD_STRIP);
	glVertex3fv(surf->vertices[0]);
	glVertex3fv(v[0]);
	for(i = 1; i <= 4; i++)
	{
		glVertex3fv(surf->vertices[i % 4]);
		glVertex3fv(v[i % 4]);
	}
	glEnd();

	// Return the vertices to their original values
	for(i = 0; i < 4; i++)
	{
		surf->vertices[i][0] -= surf_pos[0];
		surf->vertices[i][1] -= surf_pos[1];
		surf->vertices[i][2] -= surf_pos[2];
	}
}

static struct cube * new_cube(float size)
// Create a cube with the given "inner radius" centered at (0,0,0).
{
	struct cube *c = new cube;
	if(!c)
		return NULL;

	c->position[0] = 0.0f;
	c->position[1] = 0.0f;
	c->position[2] = 0.0f;

	float v[4][3];

	v[0][0] = -size; v[0][1] = size; v[0][2] = size;
	v[1][0] = -size; v[1][1] = -size; v[1][2] = size;
	v[2][0] = size; v[2][1] = -size; v[2][2] = size;
	v[3][0] = size; v[3][1] = size; v[3][2] = size;
	c->surfaces[0] = new_surface(v);

	v[0][0] = size; v[0][1] = size; v[0][2] = -size;
	v[1][0] = size; v[1][1] = -size; v[1][2] = -size;
	v[2][0] = -size; v[2][1] = -size; v[2][2] = -size;
	v[3][0] = -size; v[3][1] = size; v[3][2] = -size;
	c->surfaces[1] = new_surface(v);

	v[0][0] = -size; v[0][1] = size; v[0][2] = -size;
	v[1][0] = -size; v[1][1] = size; v[1][2] = size;
	v[2][0] = size; v[2][1] = size; v[2][2] = size;
	v[3][0] = size; v[3][1] = size; v[3][2] = -size;
	c->surfaces[2] = new_surface(v);

	v[0][0] = size; v[0][1] = -size; v[0][2] = -size;
	v[1][0] = size; v[1][1] = -size; v[1][2] = size;
	v[2][0] = -size; v[2][1] = -size; v[2][2] = size;
	v[3][0] = -size; v[3][1] = -size; v[3][2] = -size;
	c->surfaces[3] = new_surface(v);

	v[0][0] = -size; v[0][1] = size; v[0][2] = size;
	v[1][0] = -size; v[1][1] = size; v[1][2] = -size;
	v[2][0] = -size; v[2][1] = -size; v[2][2] = -size;
	v[3][0] = -size; v[3][1] = -size; v[3][2] = size;
	c->surfaces[4] = new_surface(v);

	v[0][0] = size; v[0][1] = -size; v[0][2] = size;
	v[1][0] = size; v[1][1] = -size; v[1][2] = -size;
	v[2][0] = size; v[2][1] = size; v[2][2] = -size;
	v[3][0] = size; v[3][1] = size; v[3][2] = size;
	c->surfaces[5] = new_surface(v);

	bool error = false;

	for(unsigned int i = 0; i < CUBE_FACES; i++)
	{
		if(!c->surfaces[i])
			error = true;
	}

	if(error)
	{
		for(i = 0; i < CUBE_FACES; i++)
		{
			if(c->surfaces[i])
				delete c->surfaces[i];
		}

		delete c;
		return NULL;
	}

	return c;
}

static float light_pos[3] = { 10.0f, 0.0f, 8.0f };
static const float light_color[3] = { 1.0f, 1.0f, 1.0f };

static unsigned int generate_lightmap(const struct surface * const surf, const float * const position)
// Ignore this when studying shadow volume method.  This gives the "room" a simulated lighting effect.
{
	static const unsigned int LIGHTMAP_SIZE = 16;

	static unsigned char data[LIGHTMAP_SIZE * LIGHTMAP_SIZE * 3];
	static unsigned int lightmap_tex_num = 0;

	if(lightmap_tex_num == 0)
		glGenTextures(1, &lightmap_tex_num);

	float t = 0.0f;
	for(unsigned int i = 0; i < LIGHTMAP_SIZE; i++)
	{
		const float step = 1.0f / static_cast<float>(LIGHTMAP_SIZE);
		float s = 0.0f;
		for(unsigned int j = 0; j < LIGHTMAP_SIZE; j++)
		{
			const float light_scale = 0.1f;
			const float d_scale = 0.005f;
			float pos[3];

			pos[0] = surf->s_dist * s;
			pos[1] = surf->t_dist * t;
			pos[2] = 0.0f;
			multiply_vector_by_matrix(surf->matrix, pos);

			pos[0] += position[0] + surf->vertices[0][0];
			pos[1] += position[1] + surf->vertices[0][1];
			pos[2] += position[2] + surf->vertices[0][2];

			pos[0] -= light_pos[0] * light_scale;
			pos[1] -= light_pos[1] * light_scale;
			pos[2] -= light_pos[2] * light_scale;

			float d = dot_product(pos, pos) * d_scale;
			if(d < 1.0f)
				d = 1.0f;
			const float tmp = 1.0f / d;

			data[(i * LIGHTMAP_SIZE + j) * 3 + 0] = (unsigned char)(255.0f * tmp * light_color[0]);
			data[(i * LIGHTMAP_SIZE + j) * 3 + 1] = (unsigned char)(255.0f * tmp * light_color[1]);
			data[(i * LIGHTMAP_SIZE + j) * 3 + 2] = (unsigned char)(255.0f * tmp * light_color[2]);

			s += step;
		}
		t += step;
	}

	glBindTexture(GL_TEXTURE_2D, lightmap_tex_num);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, LIGHTMAP_SIZE, LIGHTMAP_SIZE, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	return lightmap_tex_num;
}

static void draw_shadow()
// Render "everything" black, as efficiently as possible.
// "everything" is typically what passes the stencil test.
{
	glPushMatrix();
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, 1, 1, 0, 0, 1);
	glDisable(GL_DEPTH_TEST);

	glColor4f(0.0f, 0.0f, 0.0f, 0.5f); // black, no blending enabled
	glBegin(GL_QUADS);
		glVertex2i(0, 0);
		glVertex2i(0, 1);
		glVertex2i(1, 1);
		glVertex2i(1, 0);
	glEnd();

	glEnable(GL_DEPTH_TEST);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

static void render_surface(const struct surface * const surf, const float * const position)
{
	glPushMatrix();
	glTranslatef(position[0], position[1], position[2]);

	glBindTexture(GL_TEXTURE_2D, generate_lightmap(surf, position));

	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3fv(surf->vertices[0]);

		glTexCoord2f(0.0f, 1.0f);
		glVertex3fv(surf->vertices[1]);

		glTexCoord2f(1.0f, 1.0f);
		glVertex3fv(surf->vertices[2]);

		glTexCoord2f(1.0f, 0.0f);
		glVertex3fv(surf->vertices[3]);
	glEnd();

	glPopMatrix();
}

static void render_cube(const struct cube * const c)
{
	for(unsigned int i = 0; i < CUBE_FACES; i++)
		render_surface(c->surfaces[i], c->position);
}

static void render_cube_shadow(const struct cube * const c)
{
	glEnable(GL_STENCIL_TEST);
	for(unsigned int i = 0; i < CUBE_FACES; i++)
	{
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // don't update any framebuffer channels
		glDepthMask(GL_FALSE); // don't update the depth buffer
		glEnable(GL_CULL_FACE);
		glEnable(GL_POLYGON_OFFSET_FILL);
		glPolygonOffset(0.0f, 100.0f); // constant offset, 100*"eps" to avoid roundoff issues in some implementations

		// Increment area in front of back shadow volume planes
		glCullFace(GL_FRONT); // "draw" (count in stencil) the backfaces, if the depth test succeeds
		glStencilFunc(GL_ALWAYS, 0x0, 0xff); // always pass test (args 2 and 3 don't matter) -- we're counting, not testing
		glStencilOp(GL_KEEP, GL_INCR, GL_KEEP); // do nothing (arg 1 and 3) unless (stencil test passes [always] AND depth test fails), then increment stencil
		render_surface_shadow_volume(c->surfaces[i], c->position, light_pos); // "draw" the shadow volume to affect the stencil buffer

		// Decrement area in front of front shadow volume planes
		glCullFace(GL_BACK);
		glStencilFunc(GL_ALWAYS, 0x0, 0xff);
		glStencilOp(GL_KEEP, GL_DECR, GL_KEEP);
		render_surface_shadow_volume(c->surfaces[i], c->position, light_pos);
		// Now, anything with a non-0 stencil value is in the shadow volume

		// Return to normal drawing modes
		glDisable(GL_POLYGON_OFFSET_FILL);
		glDisable(GL_CULL_FACE);
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
		glDepthMask(GL_TRUE);

		// Now, draw black in the areas that are non-0 in the stencil buffer
		glStencilFunc(GL_NOTEQUAL, 0x0, 0xff);
		glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);
		draw_shadow();

		// EAD: It might seem that we need to clear the stencil buffer here, but it turns out that that is not necessary.
		// The area will be in shadow if it is non-zero after ANY iteration, which is what is implemented here.  Not
		// clearing the stencil buffer may cause multiple shadows over the same pixel to be missed, but this doesn't matter
		// since we're applying an "all or nothing" false shadow algorithm.  Clearing the buffer won't give incorrect
		// results, but it tends to be an expensive operation.
		// glClear(GL_STENCIL_BUFFER_BIT); // EXPENSIVE - NOT NEEDED
	}
	glDisable(GL_STENCIL_TEST);
}

static float sphere_pos[3] = { -10.0f, -5.0f, -10.0f };

void scene_render()
{
	static const unsigned int CUBE_COUNT = 4;

	static const float cam_rot[3] = { 22.0f, 0.0f, 0.0f };
	static struct cube *cubes[CUBE_COUNT];
	static struct cube *room;
	static unsigned int surface_tex_num;
	static GLUquadricObj *sphere;

	if(!cubes[0]) // one-time initialization
	{
		/* load texture */
		glGenTextures(1, &surface_tex_num);
		glBindTexture(GL_TEXTURE_2D, surface_tex_num);
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		/* create objects */
		room = new_cube(15.0f);

		// a 2x2 grid of cubes...
		for (signed int index = 0; index < CUBE_COUNT; ++index) // signed to allow negative results below
		{
			cubes[index] = new_cube(1.0f);
			cubes[index]->position[0] = static_cast<float>((index/2)*4-2); // this really should depend upon CUBE_COUNT
			cubes[index]->position[1] = static_cast<float>((index%2)*4-2);
		}

		sphere = gluNewQuadric();
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -15.0f);
	glRotatef(cam_rot[0], 1.0f, 0.0f, 0.0f);
	glRotatef(cam_rot[1], 0.0f, 1.0f, 0.0f);
	glRotatef(cam_rot[2], 0.0f, 0.0f, 1.0f);

	glColor4f(0.75f, 0.0f, 0.0f, 1.0f); // red
	glPushMatrix();
	glTranslatef(sphere_pos[0], sphere_pos[1], sphere_pos[2]);
	gluSphere(sphere, 2.5f, 30, 30);
	glPopMatrix();

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, surface_tex_num);

	/* render each cube */
	for(unsigned int i = 0; i < CUBE_COUNT; i++)
	{
		if(!cubes[i])
			break;

		render_cube(cubes[i]);
	}

	render_cube(room);

	glDisable(GL_TEXTURE_2D);

	/* render shadows -- this must be done AFTER rendering the real surfaces so that the depth buffer is prepared */
	for(i = 0; i < CUBE_COUNT; i++)
		render_cube_shadow(cubes[i]);

	/* render light -- indicate the light location with a rectangle */
	glColor3fv(light_color);
	glBegin(GL_QUADS);
		glVertex3f(light_pos[0] - 0.1f, light_pos[1] + 0.1f, light_pos[2] + 0.1f);
		glVertex3f(light_pos[0] - 0.1f, light_pos[1] - 0.1f, light_pos[2] + 0.1f);
		glVertex3f(light_pos[0] + 0.1f, light_pos[1] - 0.1f, light_pos[2] + 0.1f);
		glVertex3f(light_pos[0] + 0.1f, light_pos[1] + 0.1f, light_pos[2] + 0.1f);
	glEnd();
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	glFlush();
	glutSwapBuffers();
}

static unsigned int get_ticks() // return value unit is milliseconds
{
	return clock() * 1000 / CLOCKS_PER_SEC;
}

void scene_cycle()
{
	static float light_rot = 0.0f;
	static float sphere_rot = 0.0f;
	static unsigned int prev_ticks = 0;

	if(!prev_ticks)
		prev_ticks = get_ticks();

	unsigned int ticks = get_ticks();
	float time = static_cast<float>(ticks - prev_ticks);
	prev_ticks = ticks;

	light_pos[0] = cosf(light_rot) * 5.0f;
	light_rot += 0.0005f * time;

	sphere_pos[0] = cosf(sphere_rot) * 10.0f;
	sphere_pos[1] = sinf(sphere_rot) * 5.0f;
	sphere_rot += 0.0001f * time;

	scene_render();
}

#pragma warning(pop)
