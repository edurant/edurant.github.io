// $Id: main.cpp,v 1.1 2004/02/05 10:10:07 durant Exp durant $
// Shadow Volume Example
// Based heavily upon
//    http://www.3ddrome.com/articles/shadowvolumes.php
// updated by Dr. E. Durant <durant@msoe.edu>
//    Documented key sections, simplified

/*
 * Copyright (C) 2003-2004 Josh A. Beam
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <cstdio>
#include <cstdlib> // EXIT_SUCCESS
#include <GL/glut.h>
#include "scene.h"

#pragma warning(push, 4)

#define WINWIDTH	640
#define WINHEIGHT	480

static int window;

#pragma warning(push)
#pragma warning(disable:4100) // unreferenced formal parameter
void key_press(unsigned char key, int x, int y)
{
	switch(key)
	{
		case 27: /* escape */
			glutDestroyWindow(window);
			exit(0);
			break;
	}
}
#pragma warning(pop)

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
	glutInitWindowSize(WINWIDTH, WINHEIGHT);

	window = glutCreateWindow(argv[0]);
#ifdef FULLSCREEN
	glutFullScreen();
#endif

	glutDisplayFunc(scene_render);
	glutIdleFunc(scene_cycle);
	glutKeyboardFunc(key_press);

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);

	glEnable(GL_DEPTH_TEST);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, static_cast<float>(WINWIDTH) / static_cast<float>(WINHEIGHT), 5.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);

	glutMainLoop();
	return EXIT_SUCCESS;
}

#pragma warning (pop)
