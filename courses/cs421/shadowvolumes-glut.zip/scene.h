// $Id: scene.h,v 1.1 2004/02/05 10:10:28 durant Exp durant $
// Shadow Volume Example
// Dr. E. Durant <durant@msoe.edu>

#ifndef _SCENE_H_
#define _SCENE_H_

void scene_render();
void scene_cycle();

#endif // _SCENE_H_