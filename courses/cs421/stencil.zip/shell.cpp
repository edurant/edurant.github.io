// $Id: shell.cpp,v 1.2 2003/12/12 18:50:51 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Some Qt revisions based on Qt globjwin.cpp sample code

#include <qlayout.h>
#include <qframe.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qapplication.h>
#include "shell.h"
#include "myGlWidget.h"

shell::shell( QWidget* parent, const char* name )
    : QWidget( parent, name )
{
    // Create a menu
    QPopupMenu *file = new QPopupMenu( this );
    file->insertItem( "Exit",  qApp, SLOT(quit()), CTRL+Key_Q );

    // Create a menu bar
    QMenuBar *pqmb = new QMenuBar( this );
    pqmb->setSeparator( QMenuBar::InWindowsStyle );
    pqmb->insertItem("&File", file );

    // Create a nice frame to put around the OpenGL widget
    QFrame* pqf = new QFrame( this, "frame" );
    pqf->setFrameStyle( QFrame::Sunken | QFrame::Panel );
    pqf->setLineWidth( 2 );

    // Create our OpenGL widget
    myGlWidget* pmglw = new myGlWidget(pqf, "My GL Widget");

    // set up any UI QWidgets (e.g., QSliders) here, connect their signals to
    // the needed slots.

    // Stack the widgets on top of each other (change if desired)
    // Put the sliders on top of each other
    QVBoxLayout* pqvbLayout = new QVBoxLayout( 20, "vlayout");
    // vlayout->addWidget(eachWidgetCreatedAbove);

    // Put the GL widget inside the frame
    QHBoxLayout* flayout = new QHBoxLayout(pqf, 2, 2, "flayout");
    flayout->addWidget(pmglw, 1);

    // Top level layout, puts the GUI widgets to the left of the frame/GL widget
    QHBoxLayout* pqhbLayout = new QHBoxLayout( this, 20, 20, "hlayout");
    pqhbLayout->setMenuBar(pqmb);
    pqhbLayout->addLayout(pqvbLayout);
    pqhbLayout->addWidget(pqf, 1);
}
