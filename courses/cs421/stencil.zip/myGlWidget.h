// $Id: myGlWidget.h,v 1.2 2003/12/12 18:45:40 durant Exp durant $

// Author: Dr. E. Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for Stencil example: Thursday 12 February 2004

// This QGLWidget encapsulates application specific OpenGL behavior in Qt.

#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <qgl.h>

class myGlWidget : public QGLWidget
{
    Q_OBJECT

public:
    myGlWidget(QWidget* parent, const char* name );
    ~myGlWidget();

public slots:
	void polish();

protected: // virtual functions replacing the basic GLUT callbacks and functions
	void initializeGL();
	void paintGL();
};

#endif // MYGLWIDGET_H
