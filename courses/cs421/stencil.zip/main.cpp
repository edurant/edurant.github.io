// $Id: main.cpp,v 1.1 2003/12/12 18:15:02 durant Exp durant $
// Branched from GLUT version:
// main.cpp,v 1.9 2003/12/03 21:59:15 durant Exp

// CS421 Stencil Demo Program
// Author: Dr. Eric Durant <durant@msoe.edu>
// Original version: Thursday 19 December 2002
// Revised: Wednesday 3 December 2003, Thursday 12 February 2004

#ifdef _WIN32
#include <windows.h>
#endif // _WIN32

#ifdef __GNUC__
#include <cstdlib> // EXIT_SUCCESS
#endif // __GNUC__

#include <qapplication.h>
#include <qgl.h> // QGLFormat

#include "shell.h"

int main (int argc, char** argv)
{
	QApplication::setColorSpec(QApplication::CustomColor);
	QApplication theApp(argc, argv);
	// check documentation if you wish to use command line arguments

	if (!QGLFormat::hasOpenGL())
	{
		qWarning("This system has no OpenGL support. Exiting.");
		return EXIT_FAILURE;
	}

	shell window(NULL, "CS421 Stencil Example"); // caption would normally be in glutCreateWindow Call
	window.resize(500, 500);
	theApp.setMainWidget(&window);
	window.show();

	return theApp.exec();
}
