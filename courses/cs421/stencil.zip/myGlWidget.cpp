// $Id: myGlWidget.cpp,v 1.2 2003/12/12 18:45:20 durant Exp durant $

// Author: Dr. E. Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Revised for Stencil example: Thursday 12 February 2004

#include "myGlWidget.h"

#if defined(Q_CC_MSVC)
#pragma warning(disable:4305) // init: truncation from const double to float
#endif

myGlWidget::myGlWidget(QWidget* parent, const char* name)
    : QGLWidget(QGLFormat(StencilBuffer), parent, name)
{
	if (!format().stencil())
		qWarning( "Could not get stencil buffer; may cause rendering problems");
}

myGlWidget::~myGlWidget()
{
	makeCurrent();
}

void myGlWidget::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT);

	// Use the stencil "plane0 == 0"	glStencilFunc(GL_EQUAL, 0, 0x1); // bitplane 0 (1<<0) stencil
	// Draw white square
	glColor3f(1.0,1.0,1.0);
	glBegin(GL_POLYGON);
		glVertex2f(0.25, 0.25);
		glVertex2f(0.75, 0.25);
		glVertex2f(0.75, 0.75);
		glVertex2f(0.25, 0.75);
	glEnd();
	
	// Use the stencil "plane0 != 0"
	glStencilFunc(GL_NOTEQUAL, 0, 0x1); // invert bitplane 0 stencil
	// Draw red triangle
	glColor3f(1.0,0.0,0.0);
	glBegin(GL_TRIANGLES);
		glVertex2f(0  , 0);
		glVertex2f(0.9, 0.4);
		glVertex2f(0.2, 0.85);
	glEnd();	
}

void myGlWidget::initializeGL()
{
	printf("OpenGL Information...\n");
	printf("    Vendor: %s\n", glGetString(GL_VENDOR));
	printf("  Renderer: %s\n", glGetString(GL_RENDERER));
	printf("   Version: %s\n", glGetString(GL_VERSION));
	printf("Extensions: %s\n", glGetString(GL_EXTENSIONS));

	printf("Qt Information...\n");
	printf("   Version: %s\n", qVersion());

	// Set-up basic 3D viewing with orthographic projection
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0,1.0, 0.0,1.0, -1.0,1.0);
}

void myGlWidget::polish()
{
	QGLWidget::polish(); // call base version

	// The rest of this code (at least most of it) MUST be in polish.
	// It will not work in initializeGL since the OpenGL context is not complete there.

	glEnable(GL_STENCIL_TEST); // enabled for the rest of the program
	glClear(GL_STENCIL_BUFFER_BIT);
	
	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // disable drawing to set up stencil
	glStencilMask(GL_TRUE); // make stencil buffer modifiable
	
	glStencilFunc(GL_ALWAYS, 0, 0x1); // Everything passes the stencil test, arg 2 and 3 have no effect
	glStencilOp(GL_KEEP, GL_KEEP, GL_INVERT); // Invert stencil buffer value when test passes
	
	glBegin(GL_POLYGON); // Lower left to upper right stripe
		glVertex2f(0  , 0);
		glVertex2f(0.1, 0);
		glVertex2f(1  , 0.9);
		glVertex2f(1  , 1);
		glVertex2f(0.9, 1);
		glVertex2f(0  , 0.1);
	glEnd();
	glBegin(GL_POLYGON); // Flipped stripe
		glVertex2f(0,   1);
		glVertex2f(0.1, 1);
		glVertex2f(1  , 0.1);
		glVertex2f(1  , 0);
		glVertex2f(0.9, 0);
		glVertex2f(0  , 0.9);
	glEnd();

	glStencilMask(GL_FALSE); // Starting now, the stencil buffer is read-only
	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // enable writing to color buffer
}
