// $Id: shell.h,v 1.2 2003/12/12 18:50:43 durant Exp durant $

// Author: Dr. Eric Durant <durant@msoe.edu>
// Original GLUT version: Thursday 19 December 2002
// Revised for Qt: Wednesday 3 December 2003
// Some Qt revisions based on Qt globjwin.h sample code

// This "shell" represents the GUI shell and contains a "myGlWidget".

// In a future version, user interface QWidgets (e.g., sliders) could be 
// created and connected to "myGlWidget" slots.

#ifndef SHELL_H
#define SHELL_H

#include <qwidget.h>

class shell : public QWidget
{
    Q_OBJECT
public:
    shell(QWidget* parent = 0, const char* name = 0);
};

#endif // SHELL_H
