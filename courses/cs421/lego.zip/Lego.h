// $Id: Lego.h,v 1.3 2005/01/16 19:33:48 durant Exp durant $
// Branched from GLUT version:
// Id: Lego.h,v 1.5 2003/01/12 07:59:31 durant Exp

// Lego class - OpenGL interface for drawing Lego pieces
// Author: Dr. Eric Durant <durant@msoe.edu>
// Original version: Thursday 19 December 2002
// Revised: Wednesday 3 December 2003, Sunday 16 January 2005

// Geometry and modeling hierarchy based on LDraw:
//	http://www.ldraw.org/

// The geometries are based on data downloadable from the above site.
// Data format specification:
//	http://www.ldraw.org/reference/specs/fileformat

// Further logical geometry documentation (may be useful in adapting
// geometries to take better advantage of OpenGL:
//	http://www.ldraw.org/community/memorial/archive/FAQ/Primitives_Reference

// One might argue that this utility class (all functions are static) should instead
// be a collection of functions in a "Lego" namespace.  That would not allow the
// public/protected/private protection mechanism to be used, however.

#ifndef _LEGO_H_
#define _LEGO_H_

#ifdef _MSC_VER
#pragma warning(push, 4)
#endif

class Lego
{
public: // ctor/dtor
	Lego(); // not used, avoids g++ compiler warning
	virtual ~Lego() = 0;
private: // prevent use of default members...
	Lego(const Lego& src); // not used
	virtual Lego& operator=(const Lego& rhs) = 0;
public: // member functions
	// A rectangular brick -- a very limited number of sizes (4x2x1 --
	// the "standard" brick) and colors are currently supported
	static void brick(const char* color = "red", unsigned short length = 4,
		unsigned short width = 2, unsigned short height = 1);
	// There are better ways to handle color.
public: // informational data members - signed so as to yield correct
	// results when multiplied with signed ints
	static const int heightUnit;
	static const int lengthUnit;
private: // member functions
	// "Building blocks" for the public shapes.  Names and hierarchy
	// are based on the LDraw libraries.  A "primitive" calls no other
	// member functions of this class.  Some functions take an invert
	// bool parameter to support the LDraw INVERTNEXT directive.

	// Non-primitive
	static void _3001(); // the 4x2x1 brick
	static void stud4();
	static void stud();

	// Primitive
	static void box5(const bool invert);
	static void _4_4disc();
	static void _4_4edge();
	static void _4_4cyli(const bool invert);
	static void ring3();
};

#ifdef _MSC_VER
#pragma warning(pop)
#endif

#endif // _LEGO_H_
