// $Id: Lego.cpp,v 1.4 2005/01/16 19:33:33 durant Exp durant $
// Branched from GLUT version:
// Id: Lego.cpp,v 1.8 2003/12/03 21:59:42 durant Exp

// Lego class - OpenGL interface for drawing Lego pieces
// Author: Dr. Eric Durant <durant@msoe.edu>
// Original version: Thursday 19 December 2002
// Revised: Wednesday 3 December 2003, Sunday 16 January 2005

#ifdef _WIN32
#include <windows.h>
#endif // _WIN32

#include <GL/gl.h>
#include <cstring> // C char* functions: strcmp, etc.
#include <cassert>
#include <cmath> // sin/cos
#include <cfloat> // floating point limits (DBL_MIN)
#include "Lego.h"

// Ignore objects of type 2 (lines) and 5 (conditional lines)
// since they are not needed by the OpenGL representation.

// Normal and culling discipline...
// Fundamentals: watch CW/CCW specification in data file for TWO reasons...
// 1. to get correct vertex order for normal calculation
// 2. to get correct value for glFrontFace
// Details: INVERTNEXT in Lego file requires that BOTH be reversed
// We pass a bool "invert" to invertible surfaces to allow this to be accomplished
// Discipline: public entry points should leave normal and front state unchanged
// Internal discipline: before actual drawing, set your front face and normal
//	...do not assume that internal private calls maintain these values
//  ...invertible routines must check their "invert" variable whenever setting normals or front face

#ifdef _MSC_VER
#pragma warning(push, 4)
#endif

// Initialize public class constants
const int Lego::heightUnit = 24;
const int Lego::lengthUnit = 20;

// Initialize private module constants
static const double PI_1_8 = atan(1) / 2.0; // corresponds to 22.5 degrees

void Lego::brick(const char* color /*= "red"*/, // there are better ways to handle color...
				 unsigned short length /*= 4*/,
				 unsigned short width /*= 2*/,
				 unsigned short height /*= 1*/)
{
	if (!strcmp(color, "red")) // 0 means equivalent
		glColor3f(1.0, 0.0, 0.0);
	else if (!strcmp(color, "blue"))
		glColor3f(0.0, 0.0, 1.0);
	else if (!strcmp(color, "yellow"))
		glColor3f(1.0, 1.0, 0.0);
	else if (!strcmp(color, "white"))
		glColor3f(1.0, 1.0, 1.0);
	else if (!strcmp(color, "brown"))
		glColor3ub(96, 57, 19);
	else
		assert(false); // other colors not yet implemented

	// Doing this after setting the color ensures that we avoid the problem on p. 134 of the Blue book
	glPushAttrib(GL_ENABLE_BIT // color_material
				| GL_LIGHTING // material tracking 
				| GL_CURRENT_BIT // color, normal
				| GL_POLYGON_BIT // front_face
				); 
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL); // Blue book says to call ColorMaterial before Enable

	glPushMatrix();
	glScalef(1, -1, 1); // compensate for upside-down model

	if (length == 4 && width == 2 && height == 1)
		_3001();
	else
		assert(false); // brick size not yet implemented

	glPopMatrix();

	glPopAttrib();
}

void Lego::_3001() // non-primitive
{
	// 0 Brick  2 x  4
	// 0 Name: 3001.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Part
	// 0 LDRAW_ORG Part UPDATE 2002-03

	// 0 BFC CERTIFY CCW

	// 0 2002-05-07 KJM BFC Certification

	// 1 16 20 4 0 1 0 0 0 -5 0 0 0 1 stud4.dat
	// 1 16 0 4 0 1 0 0 0 -5 0 0 0 1 stud4.dat
	// 1 16 -20 4 0 1 0 0 0 -5 0 0 0 1 stud4.dat
	{
		int xOffset;
		for (xOffset = 20; xOffset >= -20; xOffset -= 20)
		{
			glPushMatrix(); glTranslatef(xOffset, 4, 0); glScalef(1, -5, 1); stud4(); glPopMatrix();
		}
	}

	// 0 BFC INVERTNEXT
	// 1 16 0 24 0 36 0 0 0 -20 0 0 0 16 box5.dat
	glPushMatrix(); glTranslatef(0, 24, 0); glScalef(36, -20, 16); box5(true); glPopMatrix(); // inner box

	//       ---------  --------- ---------- ----------
	// 4 16  40 24  20  36 24  16 -36 24  16 -40 24  20   A B C D
	// 4 16 -40 24  20 -36 24  16 -36 24 -16 -40 24 -20   D C E F
	// 4 16 -40 24 -20 -36 24 -16  36 24 -16  40 24 -20   F E G H
	// 4 16  40 24 -20  36 24 -16  36 24  16  40 24  20   H G B A

	glFrontFace(GL_CW); // This seems wrong, but gives the correct viewing results.
	glNormal3f(0,1,0);
	glBegin(GL_QUADS); // this is not the best method...
	glVertex3i(40, 24, 20); // A
	glVertex3i(36, 24, 16); // B
	glVertex3i(-36, 24, 16); // C
	glVertex3i(-40, 24, 20); // D

	glVertex3i(-40, 24, 20); // D
	glVertex3i(-36, 24, 16); // C
	glVertex3i(-36, 24, -16); // E
	glVertex3i(-40, 24, -20); // F

	glVertex3i(-40, 24, -20); // F
	glVertex3i(-36, 24, -16); // E
	glVertex3i(36, 24, -16); // G
	glVertex3i(40, 24, -20); // H

	glVertex3i(40, 24, -20); // H
	glVertex3i(36, 24, -16); // G
	glVertex3i(36, 24, 16); // B
	glVertex3i(40, 24, 20); // A
	glEnd();

	// 1 16 0 24 0 40 0 0 0 -24 0 0 0 20 box5.dat
	glPushMatrix(); glTranslatef(0, 24, 0); glScalef(40, -24, 20); box5(false); glPopMatrix();

	// 1 16 30 0 10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 10 0 10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 -10 0 10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 -30 0 10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 30 0 -10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 10 0 -10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 -10 0 -10 1 0 0 0 1 0 0 0 1 stud.dat
	// 1 16 -30 0 -10 1 0 0 0 1 0 0 0 1 stud.dat
	{
		int zOffset, xOffset;
		for (zOffset = 10; zOffset >= -10; zOffset -= 20)
			for (xOffset = 30; xOffset >= -30; xOffset -= 20)
			{
				glPushMatrix();
					glTranslatef(static_cast<float>(xOffset), 0.0f, static_cast<float>(zOffset));
					stud();
				glPopMatrix();
			}
	}
	// 0
}

void Lego::stud4() // non-primitive
{
	// 0 Stud Tube Open
	// 0 Name: stud4.dat
	// 0 Author: James Jessiman
	// 0 Author: Chris Dee
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CW

	// 0 2002-04-04 SEB Modified for BFC compliance

	// 1 16 0 -4 0 6 0 0 0 1 0 0 0 6 4-4edge.dat
	// 1 16 0 -4 0 8 0 0 0 1 0 0 0 8 4-4edge.dat
	// 1 16 0 0 0 6 0 0 0 1 0 0 0 6 4-4edge.dat
	// 1 16 0 0 0 8 0 0 0 1 0 0 0 8 4-4edge.dat
	{
		int yOffset, xzOffset;
		for (yOffset = -4; yOffset <= 0; yOffset += 4)
			for(xzOffset = 6; xzOffset <= 8; xzOffset +=2)
			{
				glPushMatrix(); glTranslatef(0, yOffset, 0); glScalef(xzOffset, 0, xzOffset); _4_4edge(); glPopMatrix();
			}
	}

	// 0 BFC INVERTNEXT
	// 1 16 0 -4 0   6 0 0 0 4 0 0 0 6 4-4cyli.dat
	// 1 16 0 -4 0   8 0 0 0 4 0 0 0 8 4-4cyli.dat
	// 1 16 0 -4 0   2 0 0 0 1 0 0 0 2 ring3.dat
	// 0
	glPushMatrix(); glTranslatef(0, -4, 0);
		glPushMatrix(); glScalef(6,4,6); _4_4cyli(true);
		glPopMatrix();
		glPushMatrix(); glScalef(8,4,8); _4_4cyli(false);
		glPopMatrix();	glScalef(2,1,2); ring3();
	glPopMatrix();
}

void Lego::box5(const bool invert) // primitive
{
	// 0 Box 5 (five faces)
	// 0 Name: box5.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CW

	// 0 2002-04-03 SEB Modified for BFC compliance

	// Removed type 2 objects since they are not need in OpenGL version.

	//      -------  ------  ------ -------
	// 4 16 -1 1 -1  1 1 -1  1 1  1 -1 1  1 ABCD
	// 4 16  1 1  1  1 0  1 -1 0  1 -1 1  1 CEFD
	// 4 16 -1 1  1 -1 0  1 -1 0 -1 -1 1 -1 DFGA
	// 4 16 -1 1 -1 -1 0 -1  1 0 -1  1 1 -1 AGHB
	// 4 16  1 1 -1  1 0 -1  1 0  1  1 1  1 BHEC
	// 0

	glFrontFace(invert?GL_CCW:GL_CW);
	glBegin(GL_QUADS);
		glNormal3f(0.0, invert?-1.0f:1.0f, 0.0); // top, y==1
		glVertex3i(-1,1,-1); // A
		glVertex3i(1,1,-1); // B
		glVertex3i(1,1,1); // C
		glVertex3i(-1,1,1); // D

		glNormal3f(0.0, 0.0, invert?-1.0f:1.0f); // z==1
		glVertex3i(1,1,1); // C
		glVertex3i(1,0,1); // E
		glVertex3i(-1,0,1); // F
		glVertex3i(-1,1,1); // D

		glNormal3f(invert?1.0f:-1.0f, 0.0, 0.0); // x==-1
		glVertex3i(-1,1,1); // D
		glVertex3i(-1,0,1); // F
		glVertex3i(-1,0,-1); // G
		glVertex3i(-1,1,-1); // A
		
		glNormal3f(0.0, 0.0, invert?1.0f:-1.0f); // z==-1
		glVertex3i(-1,1,-1); // A
		glVertex3i(-1,0,-1); // G
		glVertex3i(1,0,-1); // H
		glVertex3i(1,1,-1); // B

		glNormal3f(invert?-1.0f:1.0f, 0.0, 0.0); // x==1
		glVertex3i(1,1,-1); // B
		glVertex3i(1,0,-1); // H
		glVertex3i(1,0,1); // E
		glVertex3i(1,1,1); // C
	glEnd();
}

void Lego::stud() // non-primitive
{
	// 0 Stud
	// 0 Name: stud.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CW

	// 0 2002-04-04 SEB Modified for BFC compliance

	// 1 16 0 0 0 6 0 0 0 1 0 0 0 6 4-4edge.dat
	// 1 16 0 -4 0 6 0 0 0 1 0 0 0 6 4-4edge.dat
	// 1 16 0 0 0 6 0 0 0 -4 0 0 0 6 4-4cyli.dat
	// 1 16 0 -4 0 6 0 0 0 1 0 0 0 6 4-4disc.dat
	// 0
	glPushMatrix(); glScalef(6, 1, 6); _4_4edge(); glPopMatrix();
	glPushMatrix(); glTranslatef(0, -4, 0); glScalef(6, 1, 6); _4_4edge(); glPopMatrix();
	glPushMatrix(); glScalef(6, -4, 6); _4_4cyli(false); glPopMatrix();
	glPushMatrix(); glTranslatef(0, -4, 0); glScalef(6, 1, 6); _4_4disc(); glPopMatrix();
}

void Lego::_4_4disc() // primitive
{
	// 0 Disc 1.0
	// 0 Name: 4-4disc.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CCW

	// 0 2002-03-23 SEB Added BFC statement

 	// 3 16 0 0 0 1 0 0 0.9239 0 0.3827
 	// 3 16 0 0 0 0.9239 0 0.3827 0.7071 0 0.7071
 	// 3 16 0 0 0 0.7071 0 0.7071 0.3827 0 0.9239
 	// 3 16 0 0 0 0.3827 0 0.9239 0 0 1
 	// 3 16 0 0 0 0 0 1 -0.3827 0 0.9239
 	// 3 16 0 0 0 -0.3827 0 0.9239 -0.7071 0 0.7071
 	// 3 16 0 0 0 -0.7071 0 0.7071 -0.9239 0 0.3827
 	// 3 16 0 0 0 -0.9239 0 0.3827 -1 0 -0
 	// 3 16 0 0 0 -1 0 -0 -0.9239 0 -0.3827
 	// 3 16 0 0 0 -0.9239 0 -0.3827 -0.7071 0 -0.7071
 	// 3 16 0 0 0 -0.7071 0 -0.7071 -0.3827 0 -0.9239
 	// 3 16 0 0 0 -0.3827 0 -0.9239 0 0 -1
 	// 3 16 0 0 0 0 0 -1 0.3827 0 -0.9239
 	// 3 16 0 0 0 0.3827 0 -0.9239 0.7071 0 -0.7071
 	// 3 16 0 0 0 0.7071 0 -0.7071 0.9239 0 -0.3827
 	// 3 16 0 0 0 0.9239 0 -0.3827 1 0 0
	// 0

	glFrontFace(GL_CW); // EAD: specification of CCW above seems wrong!  Perhaps they mis-applied the axis transposition rule
	glNormal3f(0.0f, -1.0f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex3i(0,0,0); // center of canopy
		for(unsigned int i = 0; i < 16; i++)
		{
			double theta = i * PI_1_8;
			glVertex3d(cos(theta), 0, sin(theta));
		}
		glVertex3i(1,0,0); // repeat first base vertex to close canopy
	glEnd();
}

void Lego::_4_4edge() // primitive
{}	// Removed type 2 objects since they are not need in OpenGL version.

void Lego::_4_4cyli(const bool invert) // primitive
{
	// 0 Cylinder 1.0
	// 0 Name: 4-4cyli.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CW

	// 0 2002-03-23 SEB Added BFC statement; merged headers from files in distributions 
	// 0            LDraw 0.27 and Complete.

	// Removed type 5 objects since they are not need in OpenGL version.

	//  4 16 1 0 0 0.9239 0 0.3827 0.9239 1 0.3827 1 1 0
	//  4 16 0.9239 0 0.3827 0.7071 0 0.7071 0.7071 1 0.7071 0.9239 1 0.3827
	//  4 16 0.7071 0 0.7071 0.3827 0 0.9239 0.3827 1 0.9239 0.7071 1 0.7071
	//  4 16 0.3827 0 0.9239 0 0 1 0 1 1 0.3827 1 0.9239
	//  4 16 0 0 1 -0.3827 0 0.9239 -0.3827 1 0.9239 0 1 1
	//  4 16 -0.3827 0 0.9239 -0.7071 0 0.7071 -0.7071 1 0.7071 -0.3827 1 0.9239
	//  4 16 -0.7071 0 0.7071 -0.9239 0 0.3827 -0.9239 1 0.3827 -0.7071 1 0.7071
	//  4 16 -0.9239 0 0.3827 -1 0 -0 -1 1 -0 -0.9239 1 0.3827
	//  4 16 -1 0 -0 -0.9239 0 -0.3827 -0.9239 1 -0.3827 -1 1 -0
	//  4 16 -0.9239 0 -0.3827 -0.7071 0 -0.7071 -0.7071 1 -0.7071 -0.9239 1 -0.3827
	//  4 16 -0.7071 0 -0.7071 -0.3827 0 -0.9239 -0.3827 1 -0.9239 -0.7071 1 -0.7071
	//  4 16 -0.3827 0 -0.9239 0 0 -1 0 1 -1 -0.3827 1 -0.9239
	//  4 16 0 0 -1 0.3827 0 -0.9239 0.3827 1 -0.9239 0 1 -1
	//  4 16 0.3827 0 -0.9239 0.7071 0 -0.7071 0.7071 1 -0.7071 0.3827 1 -0.9239
	//  4 16 0.7071 0 -0.7071 0.9239 0 -0.3827 0.9239 1 -0.3827 0.7071 1 -0.7071
	//  4 16 0.9239 0 -0.3827 1 0 0 1 1 0 0.9239 1 -0.3827
	// 0

	// this gets the job done more elegantly for the type 4 objects (quads), but we could do even better...
	glFrontFace(invert?GL_CCW:GL_CW);
	glBegin(GL_QUADS);
	{
		unsigned int idx; // for portability, force modern scoping rules even in non-compliant compilers, such as MSVC6
		for (idx = 0; idx < 16; idx++)
		{
			double theta = idx * PI_1_8;
			double a = cos(theta);
			double b = sin(theta);
			double c = cos(theta + PI_1_8);
			double d = sin(theta + PI_1_8);

			if (invert)
				glNormal3d(+b-d, 0,-a+c);
			else
				glNormal3d(-b+d, 0, a-c);
			glVertex3d(a, 0, b);
			glVertex3d(c, 0, d);
			glVertex3d(c, 1, d);
			glVertex3d(a, 1, b);
		}
	}
	glEnd();
}

void Lego::ring3() // primitive
{
	// 0 Ring  3 x 1.0
	// 0 Name: ring3.dat
	// 0 Author: James Jessiman
	// 0 Original LDraw Primitive
	// 0 LDRAW_ORG Primitive UPDATE 2002-02

	// 0 BFC CERTIFY CW

	// 0 2002-4-5: TH: Added BFC statement

 	// 4 16 0 0 3 -1.1481 0 2.7717 -1.5308 0 3.6956 0 0 4
 	// 4 16 -1.1481 0 2.7717 -2.1213 0 2.1213 -2.8284 0 2.8284 -1.5308 0 3.6956
 	// 4 16 -2.1213 0 2.1213 -2.7717 0 1.1481 -3.6956 0 1.5308 -2.8284 0 2.8284
 	// 4 16 -2.7717 0 1.1481 -3 0 0 -4 0 0 -3.6956 0 1.5308
 	// 4 16 -3 0 0 -2.7717 0 -1.1481 -3.6956 0 -1.5308 -4 0 0
 	// 4 16 -2.7717 0 -1.1481 -2.1213 0 -2.1213 -2.8284 0 -2.8284 -3.6956 0 -1.5308
 	// 4 16 -2.1213 0 -2.1213 -1.1481 0 -2.7717 -1.5308 0 -3.6956 -2.8284 0 -2.8284
 	// 4 16 -1.1481 0 -2.7717 0 0 -3 0 0 -4 -1.5308 0 -3.6956
 	// 4 16 0 0 -3 1.1481 0 -2.7717 1.5308 0 -3.6956 0 0 -4
 	// 4 16 1.1481 0 -2.7717 2.1213 0 -2.1213 2.8284 0 -2.8284 1.5308 0 -3.6956
 	// 4 16 2.1213 0 -2.1213 2.7717 0 -1.1481 3.6956 0 -1.5308 2.8284 0 -2.8284
 	// 4 16 2.7717 0 -1.1481 3 0 0 4 0 0 3.6956 0 -1.5308
 	// 4 16 3 0 0 2.7717 0 1.1481 3.6956 0 1.5308 4 0 0
 	// 4 16 2.7717 0 1.1481 2.1213 0 2.1213 2.8284 0 2.8284 3.6956 0 1.5308
 	// 4 16 2.1213 0 2.1213 1.1481 0 2.7717 1.5308 0 3.6956 2.8284 0 2.8284
 	// 4 16 1.1481 0 2.7717 0 0 3 0 0 4 1.5308 0 3.6956
	// 0

	// this gets the job done more elegantly, but we could do even better...
	glFrontFace(GL_CW);
	glNormal3f(0.0f, -1.0f, 0.0f);
	glBegin(GL_QUADS);
	{
		unsigned int idx; // for portability, force modern scoping rules even in non-compliant compilers, such as MSVC6
		for (idx = 0; idx < 16; idx++)
		{
			double theta = idx * PI_1_8;
			double a = cos(theta);
			double b = sin(theta);
			double c = cos(theta + PI_1_8);
			double d = sin(theta + PI_1_8);

			glVertex3d(-3*b, 0, 3*a);
			glVertex3d(-3*d, 0, 3*c);
			glVertex3d(-4*d, 0, 4*c);
			glVertex3d(-4*b, 0, 4*a);
		}
	}
	glEnd();
}

#ifdef _MSC_VER
#pragma warning(pop)
#endif
