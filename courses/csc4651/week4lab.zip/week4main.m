% This is the main code from the following tutorial:
% https://www.mathworks.com/help/deeplearning/ug/deep-learning-using-bayesian-optimization.htm
% A few modifications have been made (comments included) to make it work for the CS4981 week 4 lab.

% A diary saves MATLAB command window contents to a text file. doc diary for more details
diary week4.log

datadir = "~"; % standard directory name "cifar-10-batches-mat" is assumed by the custom load function
% the custom load function requires this directory to be on the path:
oldpath = addpath(fullfile(matlabroot,'examples','nnet','main'));
[XTrain,YTrain,XTest,YTest] = loadCIFARData(datadir);
path(oldpath); % remove the extra directory from the path

size(XTrain) % to see the size of the data

idx = randperm(numel(YTest),5000);
XValidation = XTest(:,:,:,idx);
XTest(:,:,:,idx) = [];
YValidation = YTest(idx);
YTest(idx) = [];

figure
idx = randperm(numel(YTrain),20); % select 20 random elements
for i = 1:numel(idx)
    subplot(4,5,i) % 4x5 grid
    imshow(XTrain(:,:,:,idx(i)))
end

optimVars = [
    optimizableVariable('SectionDepth',[1 3],'Type','integer')
    optimizableVariable('InitialLearnRate',[1e-2 1],'Transform','log')
    optimizableVariable('Momentum',[0.8 0.98])
    optimizableVariable('L2Regularization',[1e-10 1e-2],'Transform','log')];

ObjFcn = makeObjFcn(XTrain,YTrain,XValidation,YValidation);

whos % show dimensions and memory footprint, etc. of all variables

BayesObject = bayesopt(ObjFcn,optimVars, ...
    'MaxTime',14*60*60, ...
    'IsObjectiveDeterministic',false, ...
    'UseParallel',false);

% Uncomment the following `save` command so that your results are saved to a file when optimization
% is complete and not lost if your Rosie session ends before you have a chance to do so. The
% filename is a constant so this will overwrite previous results. In production code, a better
% solution would be to ensure a unique filename is generated for subsequent runs.
% save successfulBayesianTraining
