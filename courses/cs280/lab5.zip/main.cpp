// $Id: main.cpp,v 1.6 2006/04/09 23:51:46 durant Exp durant $
// main() for lab 5: secure door lock application with various displays
// Windows console, HC11 + 4-character LED, HC11 + 16x2 LCD

#include "DoorLock.h"
#include <stdlib.h> // EXIT_SUCCESS

// only include 1 of the following...
#if 1
    #include "ConsoleDisplay.h" // Console display for Windows
    #define THEDISPLAYCLASS ConsoleDisplay
#elif 0
    #include "LCDDisplay_Fox11.h" // Fox11 configuration (2x16 display, 4 data bits)
    #define THEDISPLAYCLASS LCDDisplay_Fox11
#elif 0
    #include "LCDDisplay.h" // Hitachi-style 2x16 display (Microtips, Optrex, ...) - recommended briefcase/Wookie configuration - 8 data bits
    #define THEDISPLAYCLASS LCDDisplay
#else
    #error "No display class selected - cannot continue"
#endif

// To compile for the HC11, use NMAKE and the included Makefile.
// To compile for Windows, build a Visual Studio project as directed on the course website.

// Setting INTERACTIVE to 0 allows code to be built (in either MSVC or
// for the HC11 briefcase/Wookie, or Fox11) that simulates a sequence of key presses
// to quickly test the project.
// Setting INTERACTIVE to 1 enables normal user input (keypad on HC11,
// keyboard in MSVC Windows console app.).
#define INTERACTIVE 0
// 1 for keyboard/keypad
// 0 for test sequence

// set up wait(), getkey(), etc. according to target/compiler (MSVC or GNU 3.3.5 for HC11)...
#ifdef _MSC_VER // building in MSVC
    // wait is a "no op" on the PC console application...
    #define wait(exp) ((void)0)
	#include <cstdio> // getchar
	#define getkey getchar // Simulate matrix keypad using getchar() under Windows
#else
  #include <msoe/display.h> // digit2ascii() for briefcase or Fox11 build
  #if INTERACTIVE==0
    #include <msoe/time.h> // wait(int msec) [delay subroutine]
  #endif
    extern "C" {       // disables mangling so that function labels are straightforward, but causes problems with overloads and class member functions
        char getkey(); // get a key from the matrix keypad, implemented in "getkey.s" with global label "getkey"
        void init_keypad(); // initialize the keypad hardware on the Fox11
    }
#endif


int main()
{
    DoorLock theDoorLock; // Create a single door-lock object
    THEDISPLAYCLASS theDisplay; // ConsoleDisplay or LCDDisplay_Fox11 - don't change variable name

#ifndef _MSC_VER
 #if INTERACTIVE==1
    init_keypad();
 #endif
#endif

#if INTERACTIVE==0
    const char testKeys[] = // Key press sequence for testing (in both MSVC and Wookie/briefcase)
    //   User 612 tries to check in with wrong password
    //   |       612 checks in successfully
    //   |       |       Enter supervisor mode, display stats for 612, exit super. mode
    //   |       |       |        612 Tries to check in while already checked in
    //   |       |       |        |       612 Checks out
    //   |       |       |        |       |       Enter super. mode, display stats. for 612, exit super. mode
    //  (......)(......)(.......)(......)(......)(.......)
       "612A659A612A654A952F612EF612A654A612B654B952F612EF";
    for (int i = 0; testKeys[i]; ++i) // go through string until null terminator (\0)
#elif INTERACTIVE==1
    while(true) // endless input loop in interactive mode
#else
#error INTERACTIVE must be 0 or 1
#endif
    {
        theDisplay.showString(theDoorLock.getDisplay(), 0); // Will display "RDY " or the current numeric input
#if INTERACTIVE==0
        wait(500); // ms delay
        theDisplay.showString(theDoorLock.pressKey(testKeys[i]), 1); // press the next key in the test sequence
#else
        char key = getkey(); // input key from user (keyboard/keypad)
	#ifndef _MSC_VER
        key = digit2ascii(key); // convert to ASCII on briefcase (already got ASCII on PC)
	#endif
        theDisplay.showString(theDoorLock.pressKey(key), 1); // send the user keypress to the DoorLock object
#endif
    }

    return EXIT_SUCCESS;
}
