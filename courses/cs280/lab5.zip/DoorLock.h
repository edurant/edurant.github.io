// $Id: DoorLock.h,v 1.1 2004/04/14 03:07:33 durant Exp durant $
// Declaration of DoorLock class

#ifndef _DOORLOCK_H
#define _DOORLOCK_H

#include "Employee.h"

class DoorLock
{
public: // methods
    DoorLock();
    /*virtual*/ ~DoorLock(); // GCC 3.0.4 for HC11 does not support virtual functions

    const char* pressKey (char k); // k is ASCII representation of key pressed
    // Returns: pointer to detailed status message, or NULL if there is none
    // General idea: numbers for data, letters for actions
    // Legal keys (from the MSOE briefcase matrix keypad):
    //  0-9 for numbers (employee number or code)
    //  A - Accept employee # and code for check-in
    //  B - Accept employee # and code for check-out
    //  C - (ignored)
    //  D - (ignored)
    //  E - Supervisor: Display whether employee is in or out, followed by number of successful checkouts
    //  F - Enter (valid code required) or leave supervisor mode
    // Notes:
    //  If any code or input is invalid, the lock will briefly display an error message and then return to "RDY " (ready).
    //  The employee in slot 0 is the supervisor.
    //  For multipart entries (e.g,. check-in requires <empl no.><A><code><A>), the employee number is only validated after the 2nd part.
    //  The supervisor does not need to be checked in to make use of supervisor mode.

    const char* getDisplay(); // Returns current input in progress, or "RDY " if no input is in progress

private: // attributes
    enum classConst // define class constants
    {
        NUM_EMPLOYEES = 5,  // number of employees
        BUF_SIZE = 10,      // input buffer size
        MSG_SIZE = 4		// characters in the brief display message
    };

    enum // for keeping track of state for multi-part inputs
    {
        ready,                  // displaying ready message
        checkInNumAccepted,     // for check-in, employee number accepted and awaiting code
        checkOutNumAccepted,    // for check-out, employee number accepted and awaiting code
    } state; // state will always be one of these 4 items.

    bool supervisorMode; // true if supervisor mode is active

    unsigned int activeEmployee; // holds active employee when input is in progress (state != ready)

    char inputBuffer[BUF_SIZE+1]; // holding space for input in progress
    unsigned char inputBufferOffset; // keeps track of current character being input
    Employee employee[NUM_EMPLOYEES]; // array of Employee objects (containing statistics, codes, etc.)
    char display[MSG_SIZE+1]; // holding space used by getDisplay()
	char buf[BUF_SIZE]; // holding space for dynamic error messages

private: // methods
    DoorLock(const DoorLock& rhs);       // leave undefined
    bool operator<(const DoorLock& rhs); // leave undefined

    int lookupEmployee(unsigned int employeeId) const; // returns -1 if not found
    // input: employeeID (e.g., 612, 952) -- output: employeeIndex (e.g., 3, 0)

    const char* handleError(const char* errmsg); // handle common state transition out of error state (return to ready state)
};

#endif // _DOORLOCK_H
