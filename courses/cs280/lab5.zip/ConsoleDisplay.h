// $Id: ConsoleDisplay.h,v 1.3 2004/04/22 14:25:46 durant Exp durant $

// This class represents a console-based display (e.g., text display under Windows)

#include "Display.h" // Abstract base class

class ConsoleDisplay : public Display
{
public:
	ConsoleDisplay();
	void showString(const char* sin, unsigned char line = 0);
	void putChar(char c, unsigned char row, unsigned char col);

#if _MSC_VER <= 1200
	// MSVC 6.0 is == 1200
	enum ClassConst { DISP_SIZE = 40 };
#else // gcc and newer Microsoft compilers
	static const unsigned int DISP_SIZE = 40;
#endif

private:
	// No private member functions are needed for this type of display due to its simplicity.
};
