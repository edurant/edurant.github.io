/* $Id: atoi.h,v 1.4 2004/04/14 03:10:22 durant Exp durant $
 * Convert a string to an integer.
 * Handles only base 10 inputs (no octal or hex)
 */

#ifndef _ATOI_H
#define _ATOI_H

int atoi(const char* str);

#endif // _ATOI_H
