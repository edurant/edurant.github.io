// $Id: atoi.cpp,v 1.6 2004/04/14 03:09:38 durant Exp durant $
// Convert a string to an integer.
// Handles only base 10 inputs (no octal or hex)

int atoi(const char* str)
{
    // skip leading space
    char c;
    do
    {
        c = *str++;
    } while (c == ' ' || c == '\t'); // use isspace() if available

    // handle +/- sign
    bool neg = false;
    if (c == '-')
    {
        neg = true;
        c = *str++;
    } else if (c == '+')
        c = *str++;

    // process the digits
    int r = 0;
    do
    {
        if (c >= '0' && c <= '9') // use isdigit() if available
            r = r * 10 + c - '0';
        else
            break; // invalid character, stop converting
        c = *str++;
    } while (c);

    return neg ? -r : r;
}
