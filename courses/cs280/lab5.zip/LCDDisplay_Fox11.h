// $Id: LCDDisplay_Fox11.h,v 1.4 2006/04/09 23:03:41 durant Exp durant $

// This class represents a 16x2 display that uses the Hitachi chipset as
// connected to a Fox11 board (4-bit interface) using the Wytec monitor routines.

#include "Display.h" // Abstract base class

// LCD2.LST on the Fox11 sample CD shows how to work with the display at a low level (sending data and command bytes)

// See getting_started_fox11.pdf for an overview of how the display is connected to the Fox11.

#ifdef _MSC_VER // building in MSVC
	#define wait(exp) ((void)0) // make wait() do nothing on Windows
#else
	#include "ports.h" // PORTB, etc.
	#include <msoe/common.h> // byte
#endif

class LCDDisplay_Fox11 : public Display
// This is a utility class (no instance data members) since it encapsulates
// the Fox11 Wytec routines for interfacing with a display and these are coded
// to manage a single hardware resource, the display mapped at 0x1401 (Port F).
{
public:  // Layer 3: Application level interface to the LCD display, specified by abstract base class.
	static const unsigned int DISP_WIDTH = 16;

	LCDDisplay_Fox11(); // I/O configuration

	void putChar(char c, unsigned char row, unsigned char col);
	// Rows are numbered 0 and 1, and columns are 0-15

	void showString(const char* sin, unsigned char line = 0);
	// This function should scroll the string with a reasonable delay if it is longer than DISP_WIDTH

private: // Layer 2: Wrap simple hardware commands around BIOS interface
	void functionSet(/*bool dl, bool n, bool f*/);
	// no arguments -- always use same values for our hardware

	void clear();
	void setMode(bool display, bool cursor, bool blinkingcursor);

private: // Layer 1: BIOS interface
	// The following provide an interface to the Wytec ROM routines.  See page 12 of the Fox11 "Getting Started" document.

	static void initialize();

	enum HitachiRegister {Instruction = 0, Data = 1};
	static void registerSelect(HitachiRegister reg);

	static void writePulse(byte message);
};
