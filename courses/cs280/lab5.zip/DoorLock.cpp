// $Id: DoorLock.cpp,v 1.2 2004/04/14 23:19:03 durant Exp durant $
// Implementation of DoorLock class

#include "DoorLock.h"

#ifdef _MSC_VER
    #include <string.h> // strcpy, itoa
    #include <stdlib.h> // atoi
    #include <cassert>
    // wait is a "no op" on the PC console application...
    #define wait(exp) ((void)0)
#else // assume 3.0.4 GNU for HC11
    #include <msoe/string.h> // itos
    #include "atoi.h"
    // assert is a "no op" on the HC11 hardware...
    #define assert(exp) ((void)0)
    #include <msoe/time.h> // wait
#endif // _MSC_VER

DoorLock::DoorLock() : state(ready), supervisorMode(false), inputBufferOffset(0)
{
    // Set up IDs and codes for testing...
    employee[0].setId(952); employee[0].setCode(952);
    employee[1].setId(321); employee[1].setCode(123);
    employee[2].setId(734); employee[2].setCode(347);
    employee[3].setId(612); employee[3].setCode(654);
    employee[4].setId(608); employee[4].setCode(860);
}

DoorLock::~DoorLock() {} // nothing to do

const char* DoorLock::pressKey (char k)
{
	const char* retval = static_cast<const char *>(NULL);
    switch(k)
    {
        // Number entry...
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
            if (inputBufferOffset < BUF_SIZE)
                inputBuffer[inputBufferOffset++] = k;
            break;

        case 'A': // A - Accept employee # and code for check-in
        case 'B': // B - Accept employee # and code for check-out
            inputBuffer[inputBufferOffset++] = '\0'; // terminate string; space for \0 was reserved
            if (state == ready) // then record employee number and whether a check-in or -out is in progress
            {
                activeEmployee = atoi(inputBuffer);
                state = (k == 'A') ? checkInNumAccepted : checkOutNumAccepted;
            }
            else if (k == 'A' && state == checkInNumAccepted || k == 'B' && state == checkOutNumAccepted)
            // just entered code for check-in or -out
            {
                int employeeIndex = lookupEmployee(activeEmployee);
                if (employeeIndex == -1)
                    retval = handleError("Bad employee number"); // user entered invalid employee number
                else if (employeeIndex < NUM_EMPLOYEES)
                // user entered valid employee number
                {
                    if (k == 'A')
                    {
                        if (employee[employeeIndex].checkIn(atoi(inputBuffer)))
                        // Employee object acknowledged successful check-in
                        {
                            retval = "Okay - in";
                            wait(250);
                            state = ready;
                        }
                        else
                            retval = handleError("Can't check in"); // user entered invalid code, or tried to check in while checked in
                    }
                    else if (k == 'B')
                    {
                        if (employee[employeeIndex].checkOut(atoi(inputBuffer)))
                        // Employee object acknowledged successful check-out
                        {
                            retval = "Okay - out";
                            wait(250);
                            state = ready;
                        }
                        else
                            retval = handleError("Can't check out");
                    }
                }
                else
                    assert(false); // should never happen if lookupEmpoyee() is implemented correctly
            }
            else // User is mixing check-in/check-out codes (A and B)
                retval = handleError("Error - mixed codes");
            inputBufferOffset = 0; // No matter what happens, clear the pending input number
            break;

        case 'E': // E - Supervisor: Display whether employee is in or out, followed by number of successful checkouts
            if (supervisorMode) // only works if supervisor mode is enabled
            {
                inputBuffer[inputBufferOffset++] = '\0';
                int employeeIndex = lookupEmployee(atoi(inputBuffer));
                if (employeeIndex == -1)
                    retval = handleError("Bad employee number"); // supervisor requested nonexistent employee
                else if (employeeIndex < NUM_EMPLOYEES) // good employee index
                {
                    retval = (employee[employeeIndex].isCheckedIn() ? "In  " : "Out ");
                    wait(500);
                    
#ifdef _MSC_VER
                    itoa(employee[employeeIndex].getCheckOuts(), buf, 10); // convert int (number of check outs) to ASCII, base 10
#else
                    itos(employee[employeeIndex].getCheckOuts(), buf, 128 | MSG_SIZE); // on HC11, right justify with ' ' for padding
#endif
                    retval = buf;
                    wait(500);
                    state = ready;
                }
                else
                    assert(false);
                inputBufferOffset = 0;
            }
            else
                retval = handleError("Not supervisor"); // supervisor mode was not enabled

            break;

        case 'F': // F - Enter (with valid code) or leave supervisor mode
            inputBuffer[inputBufferOffset++] = '\0';
            if (supervisorMode) // already in supervisor mode, so leave it (no password needed)
            {
                supervisorMode = false;
                retval = "Normal";
                wait(1000);
            }
            else if (employee[0].validateCode(atoi(inputBuffer))) // not in supervisor mode, so enter if password is valid
            {
                supervisorMode = true;
                retval = "Supervisor";
                wait(1000);
            }
            else
                retval = handleError("Bad code"); // invalid supervisor password
            inputBufferOffset = 0;
            break;

        default:
            break;
    }
    return retval;
}

const char* DoorLock::getDisplay()
{
    if (inputBufferOffset == 0)
        strcpy(display, "RDY "); // nothing is being entered, so indicate that lock is ready
    else // display the pending entry, right justified
    {
        int displayOffset;
        for (displayOffset = 0; displayOffset < MSG_SIZE-inputBufferOffset; ++displayOffset)
            display[displayOffset] = ' '; // padding on left, if needed
        for (int i = 0 ; displayOffset < MSG_SIZE; ++displayOffset, ++i)
            display[displayOffset] = inputBuffer[i]; // rightmost characters (max of DISP_SIZE)
        display[displayOffset++] = '\0'; // terminate the string
    }
    return display; // allow the caller to read the private data member
}

int DoorLock::lookupEmployee(unsigned int employeeId) const
// Convert employeeId (612, 952, etc.) to employeeIndex (3, 0, etc.)
// Return -1 if employeeId is not found
{
    for (int employeeIndex = 0; employeeIndex < NUM_EMPLOYEES; ++employeeIndex)
        if (employee[employeeIndex].getId() == employeeId)
            return employeeIndex;
    return -1;
}

const char* DoorLock::handleError(const char* errmsg)
// Display error message, pause, clear input, and return to "ready" state
{
    wait(250);
    inputBufferOffset = 0;
    state = ready; // main will call getDisplay, which will put "RDY " on display
    return errmsg; // notational convenience -- we don't do anything with the message here
}
