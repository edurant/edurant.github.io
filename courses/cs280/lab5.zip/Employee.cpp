// $Id: Employee.cpp,v 1.1 2004/04/14 23:23:37 durant Exp durant $
// Implementation of Employee class for DoorLock application

#include "Employee.h"

// Complete all functions...

Employee::Employee()
{}

Employee::~Employee() {} // nothing to do

bool Employee::checkIn(unsigned int codein)
{
}

bool Employee::checkOut(unsigned int codein)
{
}

void Employee::setCode(unsigned int codein)
{
}


bool Employee::validateCode(unsigned int codein) const
{
}

bool Employee::isCheckedIn() const
{
}

unsigned int Employee::getCheckOuts() const
{
}

void Employee::setId(unsigned int idin)
{
}

unsigned int Employee::getId() const
{
}
