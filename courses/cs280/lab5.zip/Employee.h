// $Id: Employee.h,v 1.1 2004/04/14 03:07:43 durant Exp durant $
// Declaration of Employee class for DoorLock application

#ifndef _EMPLOYEE_H
#define _EMPLOYEE_H

class Employee
{
public: // methods
    Employee(); // Creates employee who has never checked-in and has id and code of 0
    /*virtual*/ ~Employee(); // EAD: GCC 3.0.4 for HC11 seems to have vtable problems

    unsigned int getId() const; // return employee ID number
    unsigned int getCheckOuts() const; // return number of successful checkouts

    bool isCheckedIn() const; // determine whether employee is checked in
    bool validateCode(unsigned int codein) const; // check if entered

    void setCode(unsigned int codein); // set the access code
    void setId(unsigned int idin); // set the employee ID

    bool checkIn(unsigned int codein);
    // returns true for successful check-in (requires valid code)
    // otherwise false
    // Note: An employee cannot check-in again if he is already checked in.

    bool checkOut(unsigned int codein);
    // returns true for successful check-out (requires valid code)
    // otherwise false
    // Note: An employee cannot check-out unless she is checked-in.

private: // attributes
    unsigned int id; // employee ID code
    bool checkedIn; // true if employee is checked in, false otherwise
    unsigned int checkOuts; // number of successful checkouts
    unsigned int code; // code for checking in and out

private: // methods
    Employee(const Employee& rhs); // do not implement
    bool operator<(const Employee& rhs); // do not implement
};

#endif // _EMPLOYEE_H
