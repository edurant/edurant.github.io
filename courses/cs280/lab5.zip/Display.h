// $Id: Display.h,v 1.1 2004/04/14 03:07:28 durant Exp durant $

// Abstract base class representing a character-based display.

class Display
// We'd like these functions to be pure virtual, but virtual functions are not supported in GCC 3.0.4 for the HC11.
// For our purposes in CS-280, this will not affect functionality (since we are not using base pointers), but
// it does eliminate some checks that the compiler could otherwise perform.
{
public:
	/*virtual*/ void putChar(char c, unsigned char row, unsigned char col) /*= 0*/;	
	/*virtual*/ void showString(const char* sin, unsigned char line = 0) /*= 0*/;
};
