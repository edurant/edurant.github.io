// $Id: ConsoleDisplay.cpp,v 1.1 2004/04/14 03:08:54 durant Exp durant $

#include "ConsoleDisplay.h"
#include <iostream> // cout, endl

ConsoleDisplay::ConsoleDisplay() {}

void ConsoleDisplay::showString(const char* sin, unsigned char line)
{
	std::cout << '['
		<< static_cast<unsigned short>(line)
		<< "]: "
		<< (sin ? sin : "(null)" )
		<< std::endl;
}

void ConsoleDisplay::putChar(char c, unsigned char row, unsigned char col)
{
	std::cout << '[' << row << ',' << col << "]: " << c << std::endl;
}
