// $Id: LCDDisplay_Fox11-skel.cpp,v 1.3 2006/04/09 23:34:05 durant Exp durant $
// Skeleton version by Dr. E. Durant 4/10/2005

#include "LCDDisplay_Fox11.h"

#ifdef _MSC_VER // building in MSVC
	typedef unsigned char byte;
#else
  #if INTERACTIVE==0
    #include <msoe/time.h> // wait(int msec) [delay subroutine]
  #endif
	#include <msoe/common.h> // byte
#endif

LCDDisplay_Fox11::LCDDisplay_Fox11()
{
	initialize(); // This is all that's needed on the Fox11 -- no need to call functionSet, clear, etc.
}

void LCDDisplay_Fox11::clear()
{
	registerSelect(Instruction);
	writePulse(0x01);
    //wait(2); // execution time is 1.53 ms (don't try to read busy flag)
}

void LCDDisplay_Fox11::setMode(bool display, bool cursor, bool blinkingcursor)
{
    registerSelect(Instruction);

    byte command = 0x08; // command prefix is 0000 1xxx

    if (display)        command |= 0x04;
    if (cursor)         command |= 0x02;
    if (blinkingcursor) command |= 0x01;

    writePulse(command);
    // execution time is 39 us
}

void LCDDisplay_Fox11::functionSet(/*bool dl, bool n, bool f*/) // command 00 | 0001[DL]NF**
// no arguments -- always use same values for our hardware
{
    registerSelect(Instruction);

    byte command = 0x20; // command prefix 001x xxxx
    command &= ~0x10; // data length is 4, not 8
    command |= 0x08; // always 2-line display in our interface
    command &= ~0x04; // 1111 1011 -> clear bit 2 = F -- 5x8 dots, not 5x11 dots (always true for our hardware?)
    // 2 LSBs are don't cares

    writePulse(command);
    // execution time is 39 us
}

void LCDDisplay_Fox11::putChar(char c, unsigned char row, unsigned char col)
{
    // PLEASE FINISH ME -- SEE INSTRUCTIONS ON LAB WEBPAGE

    // in our program, rows are 0 and 1, and cols are 0-15

}

void LCDDisplay_Fox11::showString(const char* sin, unsigned char line)
{
    // PLEASE FINISH ME -- SEE INSTRUCTIONS ON LAB WEBPAGE

    // Build this by calling putChar() repeatedly
    // Output the string to the display, watching for NUL at end.
    // If the string is very long, you only need to display enough characters to fill the display.
    // An extra feature would be to scroll the string -- that will required a call to wait between outputting each line of characters.
}

// The following functions are implemented directly in ASM...
// initialize
// registerSelect
// writePulse
