// SetBreak.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "SetBreak.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetBreak dialog


CSetBreak::CSetBreak(CWnd* pParent /*=NULL*/)
	: CDialog(CSetBreak::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetBreak)
	m_strAddress = _T("");
	//}}AFX_DATA_INIT
}


void CSetBreak::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetBreak)
	DDX_Text(pDX, IDC_ADDRESS, m_strAddress);
	DDV_MaxChars(pDX, m_strAddress, 17);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetBreak, CDialog)
	//{{AFX_MSG_MAP(CSetBreak)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetBreak message handlers
