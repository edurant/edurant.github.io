// BreakList.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "BreakList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBreakList dialog


CBreakList::CBreakList(CWnd* pParent /*=NULL*/)
	: CDialog(CBreakList::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBreakList)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBreakList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBreakList)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBreakList, CDialog)
	//{{AFX_MSG_MAP(CBreakList)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBreakList message handlers

void CBreakList::OnClose() 
{
	ShowWindow(SW_HIDE);
}

void CBreakList::OnCancel() 
{
	ShowWindow(SW_HIDE);
}

void CBreakList::OnOK()
{
}
