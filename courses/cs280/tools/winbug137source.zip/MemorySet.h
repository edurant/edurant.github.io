// MemorySet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMemorySet dialog

class CMemorySet : public CDialog
{
// Construction
public:
	CMemorySet(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMemorySet)
	enum { IDD = IDD_SET_LOCATION };
	CString	m_strAddress;
	CString	m_strValue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemorySet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMemorySet)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
