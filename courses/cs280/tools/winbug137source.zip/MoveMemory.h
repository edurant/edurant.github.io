// MoveMemory.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMoveMemory dialog

class CMoveMemory : public CDialog
{
// Construction
public:
	CMoveMemory(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMoveMemory)
	enum { IDD = IDD_MOVE_MEMORY };
	CString	m_strDestAddr;
	CString	m_strSrcEndAddr;
	CString	m_strSrcStartAddr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMoveMemory)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMoveMemory)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
