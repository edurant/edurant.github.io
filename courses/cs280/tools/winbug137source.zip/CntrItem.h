// CntrItem.h : interface of the CWinBug11CntrItem class
//

#pragma warning(push, 4)

class CWinBug11Doc;
class CWinBug11View;

class CWinBug11CntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CWinBug11CntrItem)

// Constructors
public:
	CWinBug11CntrItem(REOBJECT* preo = NULL, CWinBug11Doc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	const CWinBug11Doc* GetDocument();
	const CWinBug11View* GetActiveView();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinBug11CntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CWinBug11CntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

#pragma warning(pop)

/////////////////////////////////////////////////////////////////////////////
