// ExecSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ExecSub dialog

class CExecSub : public CDialog
{
// Construction
public:
	CExecSub(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ExecSub)
	enum { IDD = IDD_EXEC_SUB };
	CString	m_strAddress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ExecSub)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ExecSub)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
