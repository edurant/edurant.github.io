// FindByte.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindByte dialog

class CFindByte : public CDialog
{
// Construction
public:
	CFindByte(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFindByte)
	enum { IDD = IDD_FIND_BYTE };
	CString	m_strEndAddr;
	CString	m_strStartAddr;
	CString	m_strValue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindByte)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindByte)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
