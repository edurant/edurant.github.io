// MemChildFrame.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "MemChildFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemChildFrame

IMPLEMENT_DYNCREATE(CMemChildFrame, CMDIChildWnd)

CMemChildFrame::CMemChildFrame()
{
}

CMemChildFrame::~CMemChildFrame()
{
}


BEGIN_MESSAGE_MAP(CMemChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CMemChildFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemChildFrame message handlers

BOOL CMemChildFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style&=~(LONG)FWS_ADDTOTITLE;
	if(CMDIChildWnd::PreCreateWindow(cs)==0) return FALSE;

	return TRUE;
}

int CMemChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	CMenu* pSystemMenu = GetSystemMenu(FALSE);
	pSystemMenu->DeleteMenu(SC_CLOSE, MF_BYCOMMAND);

	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}
