//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinBug11.rc
//
#define IDR_WINBUGTYPE_CNTR_IP          6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDB_SPLASH                      104
#define IDR_MAINFRAME                   128
#define IDR_WINBUGTYPE                  129
#define IDD_PROPERTIES                  133
#define IDD_REGISTERS                   135
#define IDD_DUMP_MEMORY                 136
#define IDD_FILL_MEMORY                 137
#define IDD_SET_LOCATION                138
#define IDD_MOVE_MEMORY                 139
#define IDD_FIND_BYTE                   140
#define IDD_EXEC_PGM                    141
#define IDD_EXEC_SUB                    142
#define IDD_BREAK_LIST                  143
#define IDD_SET_BREAK                   144
#define IDD_TRACE_DLG                   146
#define IDB_BITMAP1                     148
#define IDC_COMMPORT                    1013
#define IDC_WORDLENGTH                  1014
#define IDC_SPIN_WORDLENGTH             1015
#define IDC_PARITY                      1016
#define IDC_RADIO2                      1017
#define IDC_RADIO3                      1018
#define IDC_STOP_BITS                   1019
#define IDC_RADIO5                      1020
#define IDC_RADIO6                      1021
#define IDC_TALKER                      1022
#define IDC_RADIO8                      1023
#define IDC_RADIO9                      1024
#define IDC_TALKERNAME                  1025
#define IDC_TALKER_BROWSE               1026
#define IDC_ACCA                        1027
#define IDC_ACCB                        1028
#define IDC_INDEXX                      1029
#define IDC_INDEXY                      1030
#define IDC_PC                          1031
#define IDC_STACK_PTR                   1032
#define IDC_CCR                         1033
#define IDC_UPDATE                      1034
#define IDC_READ_REGS                   1034
#define IDC_SAVE_REGS                   1035
#define IDC_WRITE_REGS                  1035
#define IDC_EEPROM                      1036
#define IDC_START_ADDRESS               1037
#define IDC_END_ADDRESS                 1038
#define IDC_BYTE                        1041
#define IDC_ADDRESS                     1042
#define IDC_VALUE                       1043
#define IDC_CHIPMODE                    1044
#define IDC_START_ADDR                  1045
#define IDC_END_ADDR                    1046
#define IDC_DEST_ADDR                   1047
#define IDC_BREAKLIST                   1050
#define IDC_DELAY_TIME                  1055
#define IDC_SPIN1                       1056
#define IDC_DEFAULT_BASE                1058
#define IDC_DEFAULT_BASE2               1059
#define IDC_DEFAULT_BASE3               1060
#define IDC_VERSION                     1061
#define IDC_ORIGINAL_DESIGN             1062
#define IDC_PROG_NAME                   1063
#define IDC_RELEASE_DATE                1064
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_MEMORY_BLOCK_FILL            32771
#define ID_MEMORY_FIND_BYTE             32772
#define ID_MEMORY_MEMORY_DISPLAY        32773
#define ID_MEMORY_MOVE_MEMORY           32774
#define ID_MEMORY_SET_MEMORY            32775
#define ID_MEMORY_REGISTERS             32776
#define ID_BREAKPOINT_SET               32777
#define ID_BREAKPOINT_CLEAR             32778
#define ID_BREAKPOINT_LIST              32779
#define ID_BREAKPOINT_TRACE             32780
#define ID_PROGRAM_CALL_SUB             32781
#define ID_PROGRAM_EXECUTE              32782
#define ID_PROGRAM_STOP                 32783
#define ID_EEPROM_EEPROM                32784
#define ID_EEPROM_DELAY                 32785
#define ID_FILE_PROPS                   32786
#define ID_FILE_VERIFY                  32791
#define ID_MEMORY_CLEAR                 32792
#define ID_BREAKPOINT_CLEAR_ALL         32793
#define ID_BREAKPOINT_CONTTRACE         32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
