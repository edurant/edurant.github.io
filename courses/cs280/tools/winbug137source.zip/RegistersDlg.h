// RegistersDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRegistersDlg dialog

class CRegistersDlg : public CDialog
{
private:
	CView* m_pView;
	// Construction
public:
	CRegistersDlg(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CRegistersDlg)
	enum { IDD = IDD_REGISTERS };
	CString	m_strAccA;
	CString	m_strAccB;
	CString	m_strCCR;
	CString	m_strIndexX;
	CString	m_strIndexY;
	CString	m_strProgCntr;
	CString	m_strStackPtr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegistersDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:

	// Generated message map functions
	//{{AFX_MSG(CRegistersDlg)
	afx_msg void OnReadRegs();
	afx_msg void OnWriteRegs();
	virtual void OnCancel();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
