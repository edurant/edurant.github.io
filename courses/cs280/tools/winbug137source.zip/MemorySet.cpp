// MemorySet.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "MemorySet.h"
#include "ConvToULong.h"
#include "CMemory.h"
#include "errcodes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMemory memory;

/////////////////////////////////////////////////////////////////////////////
// CMemorySet dialog


CMemorySet::CMemorySet(CWnd* pParent /*=NULL*/)
	: CDialog(CMemorySet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMemorySet)
	m_strAddress = _T("");
	m_strValue = _T("");
	//}}AFX_DATA_INIT
}


void CMemorySet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemorySet)
	DDX_Text(pDX, IDC_ADDRESS, m_strAddress);
	DDX_Text(pDX, IDC_VALUE, m_strValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMemorySet, CDialog)
	//{{AFX_MSG_MAP(CMemorySet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemorySet message handlers

