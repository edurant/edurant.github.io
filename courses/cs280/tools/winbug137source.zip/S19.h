// S19.cpp - Interface of S19 class (memory image based on an S19 file)
//
// Author: Dr. Eric Durant <durant@msoe.edu>
// Date: Sunday 27 April 2003

#ifndef _S19_H_
#define _S19_H_

#pragma warning (push, 3) // STL complains severely at level 4, disables seem to be ignored
//#pragma warning (disable : 4018)
//#pragma warning (disable : 4100)
//#pragma warning (disable : 4245)
//#pragma warning (disable : 4663)
#pragma warning (disable : 4786)

#include "stdafx.h"	// BYTE
#include <vector>

// Memory image based on an S19 file
// Most of this should really be in a "MemoryImage" class, with an S19 facet or specialization for loading data.
class S19
{
public:
	// Construct an empty memory image
    S19();
	// Copy a memory image, including cursor position
    S19(const S19& src);
    virtual ~S19();
	// Copy a memory image, including cursor position
    S19& operator=(const S19& rhs);

	// Read a memory image from an S19 string
    UINT read(const CString& cstr);

	// Set the cursor to the beginning of the image
	void resetCursor();

	// Is the cursor past the end of the initialized data?
	bool hasMoreData() const;

	// Attempt to get the next chunk. Advances the cursor.
	bool getNextChunk(short unsigned int& addressOut, std::vector<BYTE>& dataOut, short unsigned int maxSize);

	// Is a byte of memory initialized?
	bool memoryInitialized(short unsigned int addr) const;

	// Use heuristics to guess the program start address.
	unsigned short int guessProgramBegin() const;

private:
    // Ideally, the address/data combination would be in a "MemorySegment"
    // class, but they combined with this class in the current version.
	std::vector<unsigned short int> address;
	std::vector< std::vector<BYTE> > data;
	unsigned int nextAddress; // cursor - may go up to 1<<16 if there is a byte at address 0xFFFF
};

#pragma warning (pop)

#endif
