// FindByte.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "FindByte.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindByte dialog


CFindByte::CFindByte(CWnd* pParent /*=NULL*/)
	: CDialog(CFindByte::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindByte)
	m_strEndAddr = _T("");
	m_strStartAddr = _T("");
	m_strValue = _T("");
	//}}AFX_DATA_INIT
}


void CFindByte::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindByte)
	DDX_Text(pDX, IDC_END_ADDR, m_strEndAddr);
	DDV_MaxChars(pDX, m_strEndAddr, 17);
	DDX_Text(pDX, IDC_START_ADDR, m_strStartAddr);
	DDV_MaxChars(pDX, m_strStartAddr, 17);
	DDX_Text(pDX, IDC_VALUE, m_strValue);
	DDV_MaxChars(pDX, m_strValue, 9);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindByte, CDialog)
	//{{AFX_MSG_MAP(CFindByte)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindByte message handlers
