// MemoryDump.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMemoryDump dialog

class CMemoryDump : public CDialog
{
// Construction
public:
	CMemoryDump(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMemoryDump)
	enum { IDD = IDD_DUMP_MEMORY };
	CString	m_strEndAddress;
	CString	m_strStartAddress;
	//}}AFX_DATA

	CWinBug11Doc* pDoc;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemoryDump)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMemoryDump)
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
