// AsmChildFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAsmChildFrame frame

class CAsmChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CAsmChildFrame)
protected:
	CAsmChildFrame();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAsmChildFrame)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CAsmChildFrame();

	// Generated message map functions
	//{{AFX_MSG(CAsmChildFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
