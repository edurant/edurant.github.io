// MemChildFrame.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMemChildFrame frame

class CMemChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CMemChildFrame)
protected:
	CMemChildFrame();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemChildFrame)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMemChildFrame();

	// Generated message map functions
	//{{AFX_MSG(CMemChildFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
