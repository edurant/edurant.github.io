// BlockFill.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "BlockFill.h"
#include "ConvToULong.h"
#include "CMemory.h"
#include "assert.h"
#include "errcodes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMemory memory;

/////////////////////////////////////////////////////////////////////////////
// CBlockFill dialog


CBlockFill::CBlockFill(CWnd* pParent /*=NULL*/)
	: CDialog(CBlockFill::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBlockFill)
	m_strValue = _T("");
	m_strEndAddress = _T("");
	m_strStartAddress = _T("");
	//}}AFX_DATA_INIT
}


void CBlockFill::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBlockFill)
	DDX_Text(pDX, IDC_BYTE, m_strValue);
	DDX_Text(pDX, IDC_END_ADDRESS, m_strEndAddress);
	DDX_Text(pDX, IDC_START_ADDRESS, m_strStartAddress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBlockFill, CDialog)
	//{{AFX_MSG_MAP(CBlockFill)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBlockFill message handlers
