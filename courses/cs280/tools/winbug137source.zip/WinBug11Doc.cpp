// WinBug11Doc.cpp : implementation of the CWinBug11Doc class
//

#include "stdafx.h"
#include "WinBug11.h"

#include "MemoryDump.h"
#include "TraceDlg.h"
#include "SetBreak.h"
#include "BreakList.h"
#include "RegistersDlg.h"
#include "WinBug11Doc.h"
#include "CntrItem.h"
#include "ExecuteProgram.h"
#include "ExecSub.h"
#include "CProgram.h"
#include "CMemory.h"
#include "CSerial.h"
#include "ConvToULong.h"
#include "errcodes.h"
#include "BugProps.h"
#include "FindByte.h"
#include "MoveMemory.h"
#include "BlockFill.h"
#include "MemorySet.h"
#include "MainFrm.h"

#include <cassert>
#include <sstream>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CProgram program;
extern CSerial serial;
extern CMemory memory;

/////////////////////////////////////////////////////////////////////////////
// CWinBug11Doc

IMPLEMENT_DYNCREATE(CWinBug11Doc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CWinBug11Doc, CRichEditDoc)
	//{{AFX_MSG_MAP(CWinBug11Doc)
	ON_COMMAND(ID_PROGRAM_EXECUTE, OnProgramExecute)
	ON_COMMAND(ID_PROGRAM_STOP, OnProgramStop)
	ON_COMMAND(ID_PROGRAM_CALL_SUB, OnProgramCallSub)
	ON_COMMAND(ID_FILE_PROPS, OnFileProps)
	ON_COMMAND(ID_MEMORY_FIND_BYTE, OnMemoryFindByte)
	ON_COMMAND(ID_MEMORY_MOVE_MEMORY, OnMemoryMoveMemory)
	ON_COMMAND(ID_FILE_VERIFY, OnFileVerify)
	ON_COMMAND(ID_MEMORY_REGISTERS, OnMemoryRegisters)
	ON_UPDATE_COMMAND_UI(ID_MEMORY_REGISTERS, OnUpdateMemoryRegisters)
	ON_COMMAND(ID_MEMORY_BLOCK_FILL, OnMemoryBlockFill)
	ON_COMMAND(ID_MEMORY_SET_MEMORY, OnMemorySetMemory)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_MEMORY_MEMORY_DISPLAY, OnMemoryMemoryDisplay)
	ON_COMMAND(ID_MEMORY_CLEAR, OnMemoryClear)
	ON_COMMAND(ID_BREAKPOINT_LIST, OnBreakpointList)
	ON_UPDATE_COMMAND_UI(ID_BREAKPOINT_LIST, OnUpdateBreakpointList)
	ON_COMMAND(ID_BREAKPOINT_CLEAR, OnBreakpointClear)
	ON_COMMAND(ID_BREAKPOINT_SET, OnBreakpointSet)
	ON_COMMAND(ID_BREAKPOINT_CLEAR_ALL, OnBreakpointClearAll)
	ON_UPDATE_COMMAND_UI(ID_BREAKPOINT_CLEAR, OnUpdateBreakpointClear)
	ON_COMMAND(ID_BREAKPOINT_TRACE, OnBreakpointTrace)
	ON_COMMAND(ID_BREAKPOINT_CONTTRACE, OnBreakpointConttrace)
	ON_UPDATE_COMMAND_UI(ID_MEMORY_MEMORY_DISPLAY, OnUpdateMemoryMemoryDisplay)
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, CRichEditDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, CRichEditDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI(ID_OLE_VERB_FIRST, CRichEditDoc::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinBug11Doc construction/destruction

#pragma warning (push, 4)

extern CWinBug11App theApp;

CWinBug11Doc::CWinBug11Doc()
: m_pRegDlg(new CRegistersDlg),
  m_pBreakList(new CBreakList),
  m_pMemDlg(new CMemoryDump)
{
	m_pRegDlg->Create(IDD_REGISTERS);
	m_pRegDlg->ShowWindow(SW_HIDE);

	m_pBreakList->Create(IDD_BREAK_LIST);
	m_pBreakList->ShowWindow(SW_HIDE);

	m_pMemDlg->Create(IDD_DUMP_MEMORY);
	m_pMemDlg->ShowWindow(SW_HIDE);
	m_pMemDlg->pDoc = this;

	{
		CMainFrame* pFrame = dynamic_cast<CMainFrame*>(AfxGetApp()->m_pMainWnd);
		if(pFrame)
			pStatus = &pFrame->m_wndStatusBar;
	}
	bAsmViewCreated = FALSE;
	theApp.m_pDoc = this;
}

CWinBug11Doc::~CWinBug11Doc()
{
	m_pRegDlg->DestroyWindow();
	m_pBreakList->DestroyWindow();
	m_pMemDlg->DestroyWindow();
	
	delete m_pMemDlg;
	delete m_pRegDlg;
	delete m_pBreakList;
	
	// Clean up the CStringArray straMemory

	straMemory.RemoveAt(0, straMemory.GetSize());

	// Clean up the CStringArray straAsmFile
	straAsmFile.RemoveAt(0, straAsmFile.GetSize());
}

BOOL CWinBug11Doc::OnNewDocument()
{
	if (!CRichEditDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

CRichEditCntrItem* CWinBug11Doc::CreateClientItem(REOBJECT* preo) const
{
	return new CWinBug11CntrItem(preo, const_cast<CWinBug11Doc*>(this));
}

/////////////////////////////////////////////////////////////////////////////
// CWinBug11Doc serialization

void CWinBug11Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}

	// Calling the base class CRichEditDoc enables serialization
	//  of the container document's COleClientItem objects.
	CRichEditDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CWinBug11Doc diagnostics

#ifdef _DEBUG
void CWinBug11Doc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CWinBug11Doc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWinBug11Doc commands

void CWinBug11Doc::OnProgramExecute() 
{
	CExecuteProgram dlg;
	
	dlg.m_strAddress.Format("$%04x", program.m_uiProgramExecution);

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		SetStatusMessage("Beginning program execution");
		UINT uiAddress = (UINT)ConvToULong(dlg.m_strAddress);
		UINT rc = program.ExecuteProgram(uiAddress, TRUE);
		if(rc == SUCCESS)
			SetStatusMessage("Executing program");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnProgramStop() 
{
	BeginWaitCursor();
	Sleep(0);

	SetStatusMessage("Stopping execution");
	UINT rc = program.StopExecution();
	if(rc == SUCCESS)
		SetStatusMessage("Execution stopped");
	else
		SetStatusMessage(rc);
	EndWaitCursor();
}

void CWinBug11Doc::OnProgramCallSub() 
{
	CExecSub dlg;
	
	dlg.m_strAddress.Format("$%04x", program.m_uiProgramExecution);

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		SetStatusMessage("Calling Subroutine");
		UINT uiAddress = (UINT)ConvToULong(dlg.m_strAddress);
		UINT rc = program.ExecuteSubroutine(uiAddress);
		if(rc == SUCCESS)
			SetStatusMessage("Calling Subroutine");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnFileProps() 
{
	CBugProps dlg;

	if(dlg.DoModal() == IDOK)
	{
		AfxMessageBox("Please press the 68HC11 RESET button...");
		BeginWaitCursor();
		serial.m_uiDelay = dlg.m_uiDelayTime;
		{
			CWinBug11App* pApp = dynamic_cast<CWinBug11App*>(AfxGetApp());
			assert(pApp);
			if(pApp)
				pApp->SetDefaultBase(dlg.m_nDefaultBase);
		}
		UINT rc = program.Init(dlg.m_strPort,
				static_cast<BYTE>(dlg.m_nTalkerType),
				dlg.m_strTalkerFileName,
				static_cast<BYTE>(dlg.m_nMode),
				dlg.m_flEeprom);
		if(rc == SUCCESS)
			SetStatusMessage("Talker download successful");
		else
			SetStatusMessage(rc);
		EndWaitCursor();

	}
}

void CWinBug11Doc::OnMemoryFindByte() 
{
	CFindByte dlg;

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiStartAddr = (UINT)ConvToULong(dlg.m_strStartAddr);
		UINT uiEndAddr = (UINT)ConvToULong(dlg.m_strEndAddr);
		UINT uiValue = (UINT)ConvToULong(dlg.m_strValue);

		CString str;
		str.Format("Searching for $%02x starting at $%04x...", uiValue, uiStartAddr);
		SetStatusMessage(str);

		UINT uiByteCount = (uiEndAddr - uiStartAddr) + 1;

		UINT uiSearchLocation = 0;
		unsigned int & uiLocation = uiSearchLocation;

		UINT rc = memory.FindFirstByte(uiStartAddr,
								uiByteCount,
								static_cast<unsigned char>(uiValue),
								uiLocation);
		if(rc == SUCCESS)
		{
			str.Empty();
			str.Format("Value %02x found at location $%04x", uiValue, uiLocation);
			SetStatusMessage(str);
		}
		else
			SetStatusMessage(rc);
		EndWaitCursor();

	}
}

void CWinBug11Doc::OnMemoryMoveMemory() 
{
	CMoveMemory dlg;

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiSrcStartAddr = (UINT)ConvToULong(dlg.m_strSrcStartAddr);
		UINT uiSrcEndAddr = (UINT)ConvToULong(dlg.m_strSrcEndAddr);
		UINT uiDestAddr = (UINT)ConvToULong(dlg.m_strDestAddr);

		CString str;

		str.Format("Moving block - source $%04x-$%04x - dest $%04x\n", uiSrcStartAddr, uiSrcEndAddr, uiDestAddr);
		SetStatusMessage(str);

		UINT uiByteCount = (uiSrcEndAddr - uiSrcStartAddr) + 1;

		UINT rc = memory.MoveBlock(uiSrcStartAddr,
							uiByteCount,
							uiDestAddr);
		if(rc == SUCCESS)
			SetStatusMessage("Memory move successful.");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnFileVerify() 
{
	char szFilters[] = "S19 Records (.S19)|*.S19|All Files (*.*)|*.*||";
	CFileDialog filedlg(TRUE, "S19", "*.s19",
						OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
						szFilters);
	if(filedlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		CString strS19FileName = filedlg.GetPathName();
		CString str;
		str.Format("Verifying S19 File: %s", strS19FileName);
		SetStatusMessage(str);

		// Call routine to load the file on the HC11

		UINT rc = program.VerifySRecordFile(strS19FileName);
		if(rc == SUCCESS)
			SetStatusMessage("S19 Memory Image Verified");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnMemoryRegisters() 
{
	m_pRegDlg->ShowWindow(m_pRegDlg->IsWindowVisible() ? SW_HIDE : SW_SHOW);
}

void CWinBug11Doc::OnUpdateMemoryRegisters(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((int)m_pRegDlg->IsWindowVisible());
}

void CWinBug11Doc::OnMemoryBlockFill() 
{
	CBlockFill dlg;

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiStartAddress = ConvToULong(dlg.m_strStartAddress);
		UINT uiEndAddress = ConvToULong(dlg.m_strEndAddress);
		BYTE byByte = (BYTE) ConvToULong(dlg.m_strValue);

		// Sanity check:  uiStartAddress < uiEndAddress
		if(uiStartAddress > uiEndAddress)
		{
			AfxMessageBox("Start Address cannot be greater than End Address");
			return;
		}
		CString str;
		str.Format("Filling block $%04x to $%04x with $%02x", uiStartAddress, uiEndAddress, byByte);
		SetStatusMessage(str);	
		UINT uiByteCount = (uiEndAddress - uiStartAddress) + 1;
		UINT rc = memory.FillBlock(uiStartAddress, uiByteCount, byByte);
		if(rc == SUCCESS)
			SetStatusMessage("Block Fill successful");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnMemorySetMemory() 
{
	CMemorySet dlg;

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiAddress = (UINT) ConvToULong(dlg.m_strAddress);
		BYTE byValue = (BYTE) ConvToULong(dlg.m_strValue);
		CString str;
		str.Format("Setting location $%04x to $%02x", uiAddress, byValue);
		UINT rc = memory.WriteMemory(uiAddress, 1, &byValue);
		if(rc == SUCCESS)
			SetStatusMessage("Memory set successful");
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnFileOpen() 
{
	char szFilters[] = "S19 Records (.S19)|*.S19|All Files (*.*)|*.*||";
	CFileDialog filedlg(TRUE, "S19", "*.s19",
						OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
						szFilters);
	if(filedlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		CString strS19FileName = filedlg.GetPathName();
		CString str;
		str.Format("Loading S19 record %s into memory...", strS19FileName);
		SetStatusMessage(str);
		// Call routine to load the file on the HC11
		UINT rc = program.LoadSRecordFile(strS19FileName);
		if(rc != SUCCESS)
		{
			SetStatusMessage(rc);
			return;
		}

		// Build the filename for the listing (RST or LST) file
		int iPeriodPos = strS19FileName.ReverseFind('.');
		CString strLstFileBaseName = (iPeriodPos != -1) ? strS19FileName.Left(iPeriodPos) : strS19FileName;

		CStdioFile sfilLstFile;
		if(		sfilLstFile.Open( strLstFileBaseName + ".rst", CFile::modeRead)
			||	sfilLstFile.Open( strLstFileBaseName + ".lst", CFile::modeRead) )
		{
			if(!bAsmViewCreated)
			{
				CWinBug11App* pWBA = dynamic_cast<CWinBug11App*>(AfxGetApp());
				assert(pWBA);
				if(pWBA)
				{
					pWBA->m_pMainWindow->AddAsmWindow();
					bAsmViewCreated = TRUE;
				}
			}
			else
				straAsmFile.RemoveAll();

			// OK was selected.

			while(sfilLstFile.ReadString(str))
				straAsmFile.Add( str );
			sfilLstFile.Close();
		}
		else
			AfxMessageBox("Unable to open RST/LST file, S19 loaded successfully");
		// Update the view
		SetStatusMessage("S19 record loaded successfully");
		UpdateAllViews(NULL);
		EndWaitCursor();
	}
}

void CWinBug11Doc::AlignMemoryValues(UINT* puiStart,
									  UINT* puiEnd)
{
	// Alignment of the memory addresses on 16 byte boundaries
	// First, get the values into strings.

	char szStart[6];
	sprintf(szStart, "$%04x", *puiStart);
	char szEnd[6];
	sprintf(szEnd, "$%04x", *puiEnd);

	// Now, convert the last character to 0 or f to align
	szStart[4] = '0';
	szEnd[4] = 'f';

	// Convert back
	*puiStart = (UINT)ConvToULong(szStart);
	*puiEnd = (UINT)ConvToULong(szEnd);
}

void CWinBug11Doc::OnMemoryMemoryDisplay() 
{
	m_pMemDlg->ShowWindow(m_pMemDlg->IsWindowVisible() ? SW_HIDE : SW_SHOW);
}

void CWinBug11Doc::SetStatusMessage(UINT uiMessage)
{
	switch(uiMessage)
	{
	case SUCCESS:
		pStatus->SetPaneText(0, "Operation was successful");
		break;
	case COMM_ERROR:
		AfxMessageBox("Error - Unknown Comm Error");
		break;
	case PORT_NOT_OPEN:
		AfxMessageBox("Communications port is not open");
		break;
	case OPEN_PORT_FAIL:
		AfxMessageBox("Unable to open communications port");
		break;
	case OPEN_TALKER_FAIL:
		AfxMessageBox("Unable to open talker file");
		break;
	case INVALID_TALKER:
		AfxMessageBox("Invalid talker file detected");
		break;
	case INVALID_TALKER_TYPE:
		AfxMessageBox("Invalid talker type specified");
		break;
	case READ_TALKER_FAIL:
		AfxMessageBox("Reading talker failed");
		break;
	case READ_MAP_FAIL:
		AfxMessageBox("Reading map file failed");
		break;
	case READ_S19_FAIL:
		AfxMessageBox("Reading S19 failed");
		break;
	case TALKER_TIMEOUT:
		AfxMessageBox("Talker did not respond");
		break;
	case TALKER_ECHO_ERROR:
		AfxMessageBox("Echo not received properly from talker");
		break;
	case RESET_FAIL:
		AfxMessageBox("Reset operation unsuccessful");
		break;
	case REGISTER_WRITE_FAIL:
		AfxMessageBox("Register write failed");
		break;
	case FIND_BYTE_FAIL:
		AfxMessageBox("The search byte was not found in the range");
		break;
	case EEPROGRAM_FAIL:
		AfxMessageBox("Programming EEPROM failed");
		break;
	case OPEN_S19_FAIL:
		AfxMessageBox("Opening S19 file failed");
		break;
	case INVALID_S19:
		AfxMessageBox("Invalid S19 file");
		break;
	case INVALID_S19_LARGE:
		AfxMessageBox("S19 file is too large");
		break;
	case INVALID_S19_MEMORY:
		AfxMessageBox("S19 file does not match memory");
		break;
	case BREAKPOINT_LIMIT:
		AfxMessageBox("Breakpoint limit already met");
		break;
	case BREAKPOINT_SET:
		AfxMessageBox("Breakpoint set at location");
		break;
	case BREAKPOINT_NOT_FOUND:
		AfxMessageBox("Breakpoint not in table");
		break;
	case INVALID_OPCODE:
		AfxMessageBox("Invalid opcode found at specified address");
		break;
	case TRACE_FAILED:
		AfxMessageBox("Trace instruction command failed");
		break;
	case READMEM_CMD_ECHO_FAIL:
		AfxMessageBox("ReadMemory command byte echo not received");
		break;
	case READMEM_CMD_ECHO_BAD:
		AfxMessageBox("ReadMemory command byte echo incorrect");
		break;
	case WRITEMEM_CMD_ECHO_FAIL:
		AfxMessageBox("WriteMemory command byte echo not received");
		break;
	case WRITEMEM_CMD_ECHO_BAD:
		AfxMessageBox("WriteMemory command byte echo incorrect");
		break;	
	default:
		{
			std::ostringstream os;
			os << "Unknown Error Number: " << uiMessage;
			AfxMessageBox(os.str().c_str());
		}
	}

	MSG msg;
	while(::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		AfxGetApp()->PumpMessage();

}

void CWinBug11Doc::SetStatusMessage(const char* pszMessage)
{
	pStatus->SetPaneText(0, pszMessage);
	MSG msg;
	while(::PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		AfxGetApp()->PumpMessage();

}

void CWinBug11Doc::OnMemoryClear() 
{
	BeginWaitCursor();
	Sleep(0);

	straMemory.RemoveAt(0, straMemory.GetSize());
	UpdateAllViews(NULL);
	EndWaitCursor();
}

void CWinBug11Doc::OnBreakpointList() 
{
	m_pBreakList->ShowWindow(m_pBreakList->IsWindowVisible() ? SW_HIDE : SW_SHOW);
}

void CWinBug11Doc::OnUpdateBreakpointList(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((int)m_pBreakList->IsWindowVisible());
}

void CWinBug11Doc::OnBreakpointClear() 
{
	BeginWaitCursor();
	Sleep(0);
	CListBox* listbox = dynamic_cast<CListBox*>(m_pBreakList->GetDlgItem(IDC_BREAKLIST));
	assert(listbox);
	if(listbox)
	{
	
		int iItem = listbox->GetCurSel();
		if(iItem != LB_ERR)
		{
			CString str;
			listbox->GetText(iItem, str);
			UINT uiAddress = (UINT)ConvToULong(str);
			str.Empty();
			if(program.RemoveBreakpoint(uiAddress) == SUCCESS)
			{
				listbox->DeleteString(iItem);
				str.Format("Breakpoint $%04x Removed", uiAddress);
				SetStatusMessage(str);
			}
			else
			{
				str.Format("Unable to remove breakpoint $%04x", uiAddress);
				AfxMessageBox(str);
			}
		}
	}
	EndWaitCursor();
}

void CWinBug11Doc::OnBreakpointSet() 
{
	CSetBreak dlg;

	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiAddress = (UINT)ConvToULong(dlg.m_strAddress);
		UINT rc = program.SetBreakpoint(uiAddress);
		if(rc == SUCCESS)
		{
			CString str;
			str.Format("$%04x", uiAddress);
			CListBox* listbox = dynamic_cast<CListBox*>(m_pBreakList->GetDlgItem(IDC_BREAKLIST));
			assert(listbox);
			if(listbox)
			{
				listbox->AddString(str);
				str.Empty();
				str.Format("Breakpoint set at $%04x", uiAddress);
				SetStatusMessage(str);
			}
		}
		else
			SetStatusMessage(rc);

		EndWaitCursor();
	}
}

void CWinBug11Doc::OnBreakpointClearAll() 
{
	CListBox* listbox = dynamic_cast<CListBox*>(m_pBreakList->GetDlgItem(IDC_BREAKLIST));
	assert(listbox);
	if(listbox)
	{
		BeginWaitCursor();
		Sleep(0);

		SetStatusMessage("Removing all breakpoints");	
		UINT uiBreakpoints[MAXBREAKPOINTS];
		unsigned int iNumBreaks = (unsigned int)program.ListBreakpoints(uiBreakpoints);
		for(unsigned int iCounter = 0; iCounter < iNumBreaks; iCounter++)
			if(uiBreakpoints[iCounter] != 0)
				program.RemoveBreakpoint(uiBreakpoints[iCounter]);

		listbox->ResetContent();
		SetStatusMessage("Breakpoint list cleared");
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnUpdateBreakpointClear(CCmdUI* pCmdUI) 
{
	CListBox* listbox = dynamic_cast<CListBox*>(m_pBreakList->GetDlgItem(IDC_BREAKLIST));
	// Do not assert(listbox) here.  The meaning of NULL should be determined, but it does occur under normal circumstances.
	// GetLastError may be helpful in determining this.  A possible cause is that the referenced dialog is not showing/active.
	if(listbox)
		pCmdUI->Enable((int)listbox->GetCurSel() != LB_ERR);	
}

void CWinBug11Doc::OnBreakpointTrace() 
{
	CTraceDlg dlg;
	dlg.m_strAddress.Format("$%04x", program.m_uiProgramExecution);
	if(dlg.DoModal() == IDOK)
	{
		BeginWaitCursor();
		Sleep(0);

		UINT uiAddress = (UINT)ConvToULong(dlg.m_strAddress);
		CString str;
		str.Format("Beginning trace at $%04x", uiAddress);
		SetStatusMessage(str);
		UINT rc = program.TraceInstruction(uiAddress);
		if(rc == SUCCESS)
		{
			m_pRegDlg->OnReadRegs();
			m_pRegDlg->m_strProgCntr.Empty();
			m_pRegDlg->m_strProgCntr.Format("$%04x", program.m_uiProgramExecution);
			m_pRegDlg->UpdateData(FALSE);
			str.Empty();
			str.Format("Trace completed at $%04x", program.m_uiProgramExecution);
			SetStatusMessage(str);
		}
		else
			SetStatusMessage(rc);
		EndWaitCursor();
	}
}

void CWinBug11Doc::OnBreakpointConttrace() 
{
	BeginWaitCursor();
	Sleep(0);

	CString str;
	str.Format("Continuing trace at $%04x", program.m_uiProgramExecution);
	SetStatusMessage(str);
	UINT rc = program.TraceInstruction(program.m_uiProgramExecution);
	if(rc == SUCCESS)
	{
		m_pRegDlg->OnReadRegs();
		m_pRegDlg->m_strProgCntr.Empty();
		m_pRegDlg->m_strProgCntr.Format("$%04x", program.m_uiProgramExecution);
		m_pRegDlg->UpdateData(FALSE);
		str.Empty();
		str.Format("Trace completed at $%04x", program.m_uiProgramExecution);
		SetStatusMessage(str);
	}
	else
		SetStatusMessage(rc);
	EndWaitCursor();
}

void CWinBug11Doc::OnUpdateMemoryMemoryDisplay(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((int)m_pMemDlg->IsWindowVisible());
}

#pragma warning (pop)
