// ExecuteProgram.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ExecuteProgram dialog

class CExecuteProgram : public CDialog
{
// Construction
public:
	CExecuteProgram(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ExecuteProgram)
	enum { IDD = IDD_EXEC_PGM };
	CString	m_strAddress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ExecuteProgram)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ExecuteProgram)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
