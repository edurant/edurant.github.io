// WinBug11View.h : interface of the CWinBug11View class
//
/////////////////////////////////////////////////////////////////////////////

#include <cassert>

class CWinBug11CntrItem;
class CRegistersDlg;		// Forward Declaration

class CWinBug11View : public CRichEditView
{
private:
protected: // create from serialization only
	CWinBug11View();
	DECLARE_DYNCREATE(CWinBug11View)

// Attributes
public:
	CWinBug11Doc* GetDocument();
	
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinBug11View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinBug11View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWinBug11View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in WinBug11View.cpp
inline CWinBug11Doc* CWinBug11View::GetDocument()
{
	CWinBug11Doc* retval = dynamic_cast<CWinBug11Doc*>(m_pDocument);
	assert(retval);
	return retval;
}
#endif

/////////////////////////////////////////////////////////////////////////////
//////////////////////////
