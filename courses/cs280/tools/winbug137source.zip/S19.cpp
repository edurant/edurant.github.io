// S19.cpp - Implementation of S19 class (memory image based on an S19 file)
//
// Author: Dr. Eric Durant <durant@msoe.edu>
// Date: Sunday 27 April 2003

#include "S19.h"
#include "Errcodes.h" // SUCCESS
#include <cassert>

#pragma warning (push, 4)
#pragma warning (disable : 4786)

static const unsigned int ADDRESS_BITS = 16;
static const size_t MEMORY_BUFFER_SIZE = 60;

S19::S19()
{}

S19::S19(const S19& src) : address(src.address), data(src.data), nextAddress(src.nextAddress)
{}

S19::~S19()
{}

S19& S19::operator=(const S19& rhs)
{
    address = rhs.address;
    data = rhs.data;
	nextAddress = rhs.nextAddress;
	return *this;
}

UINT S19::read(const CString& strBuffer)
{
    BYTE memory[1<<ADDRESS_BITS];
	std::vector<bool> initialized(1<<ADDRESS_BITS, false); // efficient specialization

    // Parse loop based on WinBug11 code
    int iIndex = 0; // index into S19 file CString buffer
	// EAD: This is a incorrect implementation that survives from the original code, but in a different form.
	// A proper parser shall ensure (at least) that the S is at the beginning of a line, and not in a debugging symbol.
	// Contrast the objdump srec and symbolsref formats.
    while ((iIndex = strBuffer.Find('S', iIndex)) != -1) // iterate over lines (find next 'S')
    {
		switch(strBuffer[iIndex+1])
		{
		case '0': // object metadata record
		case '9': // end of send
			iIndex += (2 + 2 + 0 + 0 + 2); // skip 'Sn', 2 bytes for record length byte, 0 bytes for address (it might be okay to skip more), 0 bytes for payload (could check payload size), and 2 bytes for checksum
			break; // do nothing with these
		case '1': // data to load
			{
				// read number of data bytes on current line
				unsigned int byLineBytes = strtoul(strBuffer.Mid(iIndex+2, 2), NULL, 16);
				// high char of line byte count, low char of line byte count

				// read memory address of data bytes (on 68HC11)
				UINT uiAddress = static_cast<UINT>(strtoul(strBuffer.Mid(iIndex+4, 4), NULL, 16));
				// high char of high byte, low char of high byte, high char of low byte, low char of low byte

				// process each data byte (two character pair)
				byLineBytes -= 3;   // ignore address bytes (2) & checksum (1)
				// SEBERN 4/8/97 Buffer not big enough before.
				// Increased size and added test.
				BYTE memoryBuffer[MEMORY_BUFFER_SIZE];              // byte array for reading one line (of S19)
				assert (byLineBytes <= sizeof memoryBuffer);
				iIndex += 8;        // advance pointer to first data char
				for(unsigned int byCounter=0; byCounter<byLineBytes; byCounter++)
				{
					// read data byte (two chars)
					memoryBuffer[byCounter] = static_cast<BYTE>(strtoul(strBuffer.Mid(iIndex + 2 * byCounter, 2), NULL, 16));
				}

				// write S19 line to 68HC11 memory image
				for(unsigned int offset = 0; offset < byLineBytes; ++offset)
				{
					memory[uiAddress+offset] = memoryBuffer[offset]; // rewrite with memcpy to make more efficient
					initialized[uiAddress+offset] = true; // there are more efficient
					// data structures, but they are nontrivial and the extra overhead of
					// the vector<bool> is small compared with the rest of the program
				}
			}
			break;
		default:
			return INVALID_S19;
		}
    }

    // Now parse the memory image into loadable chunks...
    address.clear();
    data.clear();

    unsigned int addr = 0;
    for (;;) // while(true) generates warnings in MSVC6
    {
        while((addr < 1<<ADDRESS_BITS) && !initialized[addr])
            ++addr;
		if(addr == 1<<ADDRESS_BITS)
			break;
		address.push_back(static_cast<unsigned short int>(addr));
		data.push_back(std::vector<BYTE>());
		while((addr < 1<<ADDRESS_BITS) && initialized[addr])
			data.back().push_back(memory[addr++]);
    }
	nextAddress = 0;
	return SUCCESS;
}

void S19::resetCursor()
{
	nextAddress = 0;
}

bool S19::hasMoreData() const
{
	if (data.empty() || address.empty())
		return false;
	else
		return (nextAddress < address.back() + data.back().size());
}

bool S19::getNextChunk(short unsigned int& addressOut, std::vector<BYTE>& dataOut, short unsigned int maxSize)
{
	if (hasMoreData())
	{
		for (unsigned int chunk = 0; chunk < address.size(); chunk++)
		{
			if (address[chunk] > nextAddress)
				break;
		}
		unsigned short int offset; // never goes past last element, therefore 16 bits suffice
		if (chunk == 0 || address[chunk-1] + data[chunk-1].size() <= nextAddress) // time to begin "chunk"
		{
			assert(chunk != address.size()); // guaranteed by hasMoreData()
			offset = 0;
		}
		else // somewhere inside previous chunk
		{
			--chunk;
			offset = static_cast<unsigned short int>(nextAddress - address[chunk]);
		}
		unsigned short int size = static_cast<unsigned short int>(data[chunk].size() - offset);
		if (size > maxSize)
			size = maxSize;

		addressOut = static_cast<unsigned short int>(address[chunk] + offset);
		std::vector<BYTE>::const_iterator start = data[chunk].begin() + offset;
		dataOut.assign(start, start + size);
		nextAddress = addressOut + size;
		return true;
	}
	else
		return false;
}

bool S19::memoryInitialized(short unsigned int addr) const
{
	if (data.empty() || address.empty() || (addr >= address.back() + data.back().size()))
		return false;
	else
	{
		for (unsigned int chunk = 0; chunk < address.size(); chunk++)
		{
			if (address[chunk] > addr)
				break;
		}
		return (chunk != 0) && (address[chunk-1] + data[chunk-1].size() > addr);
	}
}

unsigned short int S19::guessProgramBegin() const
{
	// common starting addresses in order of preference
	// If one of these is in the memory map, it will be the starting address guess.
	static const unsigned short int commonAddresses[] = {0xC000, 0xE000, 0xD000, 0xF000, 0x0100, 0xC800, 0xF800};
	static const unsigned short int * const end = commonAddresses + sizeof(commonAddresses);
	const unsigned short int * here = commonAddresses;
	while (here != end)
		if (memoryInitialized(*here))
			return *here;
		else
			++here;
	// If we got this far, no common addresses are in the map, so choose the first address (unless S19 is empty).
	return address.empty() ? commonAddresses[0] : address.front();
}

#pragma warning (pop)
