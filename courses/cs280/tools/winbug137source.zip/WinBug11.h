// WinBug11.h : main header file for the WINBUG11 application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CWinBug11App:
// See WinBug11.cpp for the implementation of this class
//

#define DEFAULT_BASE_DEC	0
#define DEFAULT_BASE_HEX	1
#define DEFAULT_BASE_BIN	2

class CMainFrame;
class CWinBug11Doc;

class CWinBug11App : public CWinApp
{
protected:
	UINT m_uiDefaultBase;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CWinBug11App();
	CMultiDocTemplate* m_pAsmTemplate;
	CMainFrame* m_pMainWindow;
	CWinBug11Doc* m_pDoc;
	int ExitInstance();
	void SetDefaultBase(UINT uiBase);
	UINT GetDefaultBase(void);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinBug11App)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWinBug11App)
	afx_msg void OnAppAbout();
	afx_msg void OnHelp();
	afx_msg void OnHelpIndex();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
