// WinBug11View.h : interface of the CWinBugAsmView class
//
/////////////////////////////////////////////////////////////////////////////

#pragma warning(push, 4)

class CWinBug11CntrItem;
class CRegistersDlg;		// Forward Declaration
class CWinBug11Doc;

class CWinBugAsmView : public CRichEditView
{
private:
protected: // create from serialization only
	CWinBugAsmView();
	DECLARE_DYNCREATE(CWinBugAsmView)

// Attributes
public:
	CWinBug11Doc* GetDocument();
	
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinBugAsmView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinBugAsmView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWinBugAsmView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//////////////////////////

#pragma warning(pop)
