// AsmChildFrame.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "AsmChildFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAsmChildFrame

IMPLEMENT_DYNCREATE(CAsmChildFrame, CMDIChildWnd)

CAsmChildFrame::CAsmChildFrame()
{
}

CAsmChildFrame::~CAsmChildFrame()
{
}


BEGIN_MESSAGE_MAP(CAsmChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CAsmChildFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAsmChildFrame message handlers

BOOL CAsmChildFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style&=~(LONG)FWS_ADDTOTITLE;
	if(CMDIChildWnd::PreCreateWindow(cs)==0) return FALSE;
	return TRUE;
}

int CAsmChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}
