// MoveMemory.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "MoveMemory.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMoveMemory dialog


CMoveMemory::CMoveMemory(CWnd* pParent /*=NULL*/)
	: CDialog(CMoveMemory::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMoveMemory)
	m_strDestAddr = _T("");
	m_strSrcEndAddr = _T("");
	m_strSrcStartAddr = _T("");
	//}}AFX_DATA_INIT
}


void CMoveMemory::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMoveMemory)
	DDX_Text(pDX, IDC_DEST_ADDR, m_strDestAddr);
	DDX_Text(pDX, IDC_END_ADDR, m_strSrcEndAddr);
	DDX_Text(pDX, IDC_START_ADDR, m_strSrcStartAddr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMoveMemory, CDialog)
	//{{AFX_MSG_MAP(CMoveMemory)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMoveMemory message handlers
