// CntrItem.cpp : implementation of the CWinBug11CntrItem class
//

#include "stdafx.h"
#include "WinBug11.h"

#include "WinBug11Doc.h"
#include "WinBug11View.h"
#include "CntrItem.h"

#include <cassert>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinBug11CntrItem implementation

IMPLEMENT_SERIAL(CWinBug11CntrItem, CRichEditCntrItem, 0)

#pragma warning(push, 4)

CWinBug11CntrItem::CWinBug11CntrItem(REOBJECT* preo, CWinBug11Doc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
}

const CWinBug11Doc* CWinBug11CntrItem::GetDocument()
{
	CWinBug11Doc* retval = dynamic_cast<CWinBug11Doc*>(CRichEditCntrItem::GetDocument());
	assert(retval);
	return retval;
}

const CWinBug11View* CWinBug11CntrItem::GetActiveView()
{
	CWinBug11View* retval = dynamic_cast<CWinBug11View*>(CRichEditCntrItem::GetActiveView());
	assert(retval);
	return retval;
}

CWinBug11CntrItem::~CWinBug11CntrItem()
{
	// TODO: add cleanup code here
}

/////////////////////////////////////////////////////////////////////////////
// CWinBug11CntrItem diagnostics

#ifdef _DEBUG
void CWinBug11CntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CWinBug11CntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////

#pragma warning(pop)