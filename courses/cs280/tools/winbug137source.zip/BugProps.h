// BugProps.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBugProps dialog
#include "stdafx.h"

class CBugProps : public CDialog
{
// Construction
public:
	CBugProps(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBugProps)
	enum { IDD = IDD_PROPERTIES };
	CString	m_strPort;
	int		m_nTalkerType;
	CString	m_strTalkerFileName;
	BOOL	m_flEeprom;
	int		m_nMode;
	UINT	m_uiDelayTime;
	int		m_nDefaultBase;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBugProps)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBugProps)
	afx_msg void OnTalkerBrowse();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
