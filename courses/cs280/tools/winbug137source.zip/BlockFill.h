// BlockFill.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBlockFill dialog

class CBlockFill : public CDialog
{
// Construction
public:
	CBlockFill(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBlockFill)
	enum { IDD = IDD_FILL_MEMORY };
	CString	m_strValue;
	CString	m_strEndAddress;
	CString	m_strStartAddress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBlockFill)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBlockFill)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
