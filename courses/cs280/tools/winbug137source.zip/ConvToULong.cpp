/////////////////////////////////////////////////
//
// ConvToULong:  Convert NULL terminated strings to unsigned longs.
//
// Arguments:
//				pszString -	pointer to NULL terminated string
//							containing the data to convert.
//							Refer to the NOTES section below.
//
// Return Value:
//				The data as a ULONG if successful, 0 otherwise.
//				This may cause some problems if the string passed.
//				converts to a 0 normally.
//
// Example Usage:
//				ulData = ConvToULong(pszData);
//
// Notes:
//				The first character of the string determines
//				the conversion type.  $ converts from hex,
//				% converts from binary, and # converts
//				from decimal.
//
// Author:		Phil VanHelden
// Reviewer:
//
// Version 1.0 - 12/15/96
//

#include <cstdlib>
#include <cstring>
#include <cassert>
#include "stdafx.h"
#include "winbug11.h"
#include "ConvToULong.h"

unsigned long ConvToULong(const char* pszData)
{
	unsigned long ulResult = 0;
	char* cpEndPos = NULL;
	bool cInvalidData(false);

	switch(pszData[0])
	{
	case '$':
		if(strlen(pszData) < 6)		// Max HEX is 5 chars
			ulResult = strtoul(&pszData[1], &cpEndPos, 16);
		else
			cInvalidData = true;
		break;
	case '%':
		if(strlen(pszData) < 17)		// Max BIN is 17 chars
			ulResult = strtoul(&pszData[1], &cpEndPos, 2);
		else
			cInvalidData = true;
		break;
	case '#':
		if(strlen(pszData) < 5)		// Max DEC is 65535 (5 chars)
			ulResult = strtoul(pszData, &cpEndPos, 10);
		else
			cInvalidData = true;
		break;
	default:
		{
			CWinBug11App* pApp = dynamic_cast<CWinBug11App*>(AfxGetApp());
			assert(pApp);
			if(pApp)
			{
				switch(pApp->GetDefaultBase())
				{
				case DEFAULT_BASE_HEX:
					if(strlen(pszData) < 6)		// Max HEX is 5 chars
						ulResult = strtoul(pszData, &cpEndPos, 16);
					else
						cInvalidData = true;
					break;
				case DEFAULT_BASE_BIN:
					if(strlen(pszData) < 17)		// Max BIN is 17 chars
						ulResult = strtoul(pszData, &cpEndPos, 2);
					else
						cInvalidData = true;
					break;
				case DEFAULT_BASE_DEC:
				default:
					if(strlen(pszData) < 5)		// Max DEC is 65535 (5 chars)
						ulResult = strtoul(pszData, &cpEndPos, 10);
					else
						cInvalidData = true;
					break;
				}
			}
		}
	}
	if((cInvalidData) || (*cpEndPos != NULL))
		return 0L;
	else if(ulResult > 65535)		// Max 16-bit value is 65535
		return 65535L;				// Return max value
	else
		return ulResult;
}