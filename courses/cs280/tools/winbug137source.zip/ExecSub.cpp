// ExecSub.cpp : implementation file
//

#include "stdafx.h"
#include "WinBug11.h"
#include "ExecSub.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ExecSub dialog


CExecSub::CExecSub(CWnd* pParent /*=NULL*/)
	: CDialog(CExecSub::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExecSub)
	m_strAddress = _T("");
	//}}AFX_DATA_INIT
}


void CExecSub::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ExecSub)
	DDX_Text(pDX, IDC_ADDRESS, m_strAddress);
	DDV_MaxChars(pDX, m_strAddress, 17);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExecSub, CDialog)
	//{{AFX_MSG_MAP(CExecSub)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ExecSub message handlers
