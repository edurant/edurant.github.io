////////////////////////////////////////////////////////////////////////////////
// File Name:       hprio_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:48:28
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "hprio_c.h"

void HPRIO_C::Write(byte_t val)
{
    byte = val;
}
