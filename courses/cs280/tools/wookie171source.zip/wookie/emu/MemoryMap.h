#if !defined(MEMORYMAP_H)
#define MEMORYMAP_H


#include "basetypes.h"
#include "MemoryRegister.h"
#include "ByteRegister.h"
#include "WordRegister.h"

#include "MemoryObject.h"

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: MemoryMap
//
// Author: Kalle Anderson
//
// Purpose: This class maps all the different MemoryObjects into a
//          contiguous address space.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class MemoryMap into its own header
//  12/17/2000  BPF and ILK     Changed #include "register.h" to 
//									include MemoryRegister.h, ByteRegister.h,
//									and WordRegister.h
//          
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099D0282
class MemoryMap
{	
private:
	//##ModelId=3A3D099D02A0
    list<MemoryObject*> map;
	//##ModelId=3A3D099D02C0
	MemoryObject *GetObject(word_t address);

	//##ModelId=3A3D099D028E
    MemoryObject *mo_cache;

public:	
	//##ModelId=3A3D099D02BF
	 ~MemoryMap();
	//##ModelId=3A3D099D02BE
	 MemoryMap();

	//##ModelId=3A3D099D02B7
	byte_t Read(word_t address);
	//##ModelId=3A3D099D02B4
	void Write(word_t address, byte_t data);
    // the order of objects added will determine there priority
    // if they overlap
	//##ModelId=3A3D099D02AC
	void AddMemoryObject(MemoryObject *mo);    
	//##ModelId=3A3D099D02AA
    bool RemoveMemoryObject(MemoryObject *mo);
	//##ModelId=3A3D099D02A3
    byte_t operator[](word_t address){return(Read(address));};
};

#endif //!defined(MEMORYMAP_H)
