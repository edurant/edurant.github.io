////////////////////////////////////////////////////////////////////////////////
// File Name:       PORTCLRegister.h
// Description:     This is the PORTCL register on the M68HC11
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented class
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_PORTCLREGISTER_3A6B479F01CC_INCLUDED
#define _INC_PORTCLREGISTER_3A6B479F01CC_INCLUDED

#include "ByteRegister.h"

class PORTCLRegister 
: public ByteRegister
{
public:
	~PORTCLRegister();

	PORTCLRegister& operator=(const PORTCLRegister& rhs);

	PORTCLRegister();

	PORTCLRegister(const PORTCLRegister& rhs);

};

#endif /* _INC_PORTCLREGISTER_3A6B479F01CC_INCLUDED */

