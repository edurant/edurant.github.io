////////////////////////////////////////////////
//   Opbasic.cpp
//   Purpose: The basic operations that are done
//            the opcodes
////////////////////////////////////////////////
#include "stdafx.h"
#include "hc11.h"

////////////////////////////////////////////////
//  addbyte - this function adds an accumulator and a Byte,
//	      setting the flags are specified to be set if
//            they need to be set.
//
//  Parameters: *hc11 - pointer to the hc11 class
//		 acc - the accumulator to put result in
//		 num - the Byte to add to the accumulator
//		 flag - if any flag bit in here is a one,
//		        that flag bit in the CCR is set if needed
//		carryinflag - true if the first bit is to
//   			      be added to bit 0
//
//  Author: Jason Buttron
//
//  Last Updated: December 14, 1997
////////////////////////////////////////////////

Byte addbyte(HC11 *hc11,Byte acc,Byte num,CCRReg flag,bit_t carryinflag)
{
	Byte result;
	
	result=acc + num + carryinflag;
	
		if(flag.N())
		if(result.bit7())  //Negative
			hc11->CCR.N(1);
		else
			hc11->CCR.N(0);
	
	if(flag.Z())
		if(!(result))   //Zero  
			hc11->CCR.Z(1);
		else	
			hc11->CCR.Z(0);
	
	if(flag.V())
		if((acc.bit7()&num.bit7()&!(result.bit7())) | (!(acc.bit7())&!(num.bit7())&result.bit7()))	//Overflow
			hc11->CCR.V(1);
		else
			hc11->CCR.V(0);
	
	if(flag.C()==1)
	{
		if((acc.bit7()&num.bit7()) | (num.bit7()&!(result.bit7())) | (!(result.bit7())&acc.bit7())) 
			hc11->CCR.C(1);
		else
			hc11->CCR.C(0);
	}

	if(flag.H())
		if((acc.bit3()&num.bit3()) | (num.bit3()&!(result.bit3())) | (!(result.bit3())&acc.bit3()))  
			hc11->CCR.H(1);
		else	
			hc11->CCR.H(0);

	return(result);
}

////////////////////////////////////////////////
//  addword - this function adds an accumulator and a Byte,
//	      setting the flags are specified to be set if
//            they need to be set.
//
//  Parameters: *hc11 - pointer to the hc11 class
//		 acc - the accumulator to put result in
//		 num - the Word to add to the accumulator
//		 flag - if any flag bit in here is a one,
//		        that flag bit in the CCR is set if needed
//		carryinflag - true if the first bit is to
//   			      be added to bit 0
//
//  Author: Jason Buttron
//
//  Last Updated: December 14, 1997
////////////////////////////////////////////////

Word addword(HC11* hc11,Word acc,Word num,CCRReg flag, bit_t carryinflag)
{
	flag.H(0);	
	Word result;
	result.low(addbyte(hc11,acc.low(),num.low(),1,carryinflag));  //1 sets the carry flag
	result.high(addbyte(hc11,acc.high(),num.high(),flag,hc11->CCR.C()));
	
	return(result);
}


////////////////////////////////////////////////
//  subbyte - this function subtracts a Byte from an accumulator,
//	      setting the flags are specified to be set if
//            they need to be set.
//
//  Parameters: *hc11 - pointer to the hc11 class
//		 acc - the accumulator to put result in
//		 num - the Byte to subtract from the accumulator
//		 flag - if any flag bit in here is a one,
//		        that flag bit in the CCR is set if needed
//
//  Author: Jason Buttron
//
//  Last Updated: December 14, 1997
////////////////////////////////////////////////

Byte subbyte(HC11* hc11,Byte acc,Byte num,CCRReg flag)
{
	Byte result;

	result=acc - num;

	if(flag.N())
		if(result.bit7())  //Negative
			hc11->CCR.N(1);
		else
			hc11->CCR.N(0);
	
	if(flag.Z())
		if(result==0)   //Zero
			hc11->CCR.Z(1);
		else	
			hc11->CCR.Z(0);
	
	if(flag.V())
		if((acc.bit7()&!(num.bit7())&!(result.bit7())) | (!(acc.bit7())&num.bit7()&result.bit7()))	//Overflow
			hc11->CCR.V(1);
		else
			hc11->CCR.V(0);
	
	if(flag.C()==1)
	{
		if((!(acc.bit7())&num.bit7()) | (num.bit7()&result.bit7()) | (result.bit7()&!(acc.bit7()))) 
			hc11->CCR.C(1);
		else
			hc11->CCR.C(0);
	}
	return(result);
}

////////////////////////////////////////////////
//  subword - this function subtracts a Word from an accumulator,
//	      setting the flags are specified to be set if
//            they need to be set.
//
//  Parameters: *hc11 - pointer to the hc11 class
//		 acc - the accumulator to put result in
//		 num - the Word to subtract from the accumulator
//		 flag - if any flag bit in here is a one,
//		        that flag bit in the CCR is set if needed
//
//  Author: Jason Buttron
//
//  Last Updated: December 14, 1997
////////////////////////////////////////////////

Word subword(HC11* hc11,Word acc,Word num,CCRReg flag)
{
	Word result;
	Byte highX;
	Byte highM;
	Byte highR;
	
	result=acc-num;
	highR=result.high();
	highX=acc.high();
	highM=num.high();


	if(flag.N())
		if(highR.bit7())  //Negative
			hc11->CCR.N(1);
		else
			hc11->CCR.N(0);
	
	if(flag.Z())
		if(result == 0)   //Zero //!(highR)
			hc11->CCR.Z(1);
		else	
			hc11->CCR.Z(0);
	//
	// fixed C and V defects.  Original code used num.bit7() rather than highM.bit7(), so the if was looking at 
	//   bit 7 of the word rather than bit 15
	//   SLB, 3/1/2002
	//

	if(flag.V())
		if((highX.bit7() & !(highM.bit7()) & !(highR.bit7())) | (!(highX.bit7()) & highM.bit7() & highR.bit7()))	//Overflow
			hc11->CCR.V(1);
		else
			hc11->CCR.V(0);
			
	if(flag.C()==1)
	{
		if(( !(highX.bit7()) & highM.bit7()) | (highM.bit7() & highR.bit7()) | (highR.bit7() & !(highX.bit7()))) 
			hc11->CCR.C(1);
		else
			hc11->CCR.C(0);
	}

	return(result);
}

////////////////////////////////////////////////
//  round - round the number passsed
//
//  Parameters: num - the number to round
//
//  Author: Jason Buttron
//
//  Last Updated: January 11, 1998
////////////////////////////////////////////////
int round(double num)
{
	return((int)(num+0.5));
}
