#include "stdafx.h"
#include "hc11.h"

////////////////////////////////////////////
//
//  BRA - Branch Always
//  
//  Addr. Mode: REL
//  
//  Opcodes: 20h
//
//  Clocks: 3
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_20h(HC11 *hc11)
{
    signed char offset;
 	
    hc11->_clock();	
    offset = (signed)hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->_clock();	
    hc11->PC = hc11->PC + offset;
}

/////////////////////////////////////////////////
//
//  CLC - Set Carry Flag
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0C
//
//  Clocks: 2
//
//  Flags: C
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Ch(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.C(0);
}

/////////////////////////////////////////////////
//
//  CLI - Set Interrupt Mask
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0E
//
//  Clocks: 2
//
//  Flags: I
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Eh(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.I(0);
}


/////////////////////////////////////////////////
//
//  CLV - Clear Twos Complement Overflow Bit
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0A
//
//  Clocks: 2
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Ah(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.V(0);
}


/////////////////////////////////////////////////
//
//  CPX - Compare Index Register X
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 8C
//
//  Clocks: 4
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_8Ch(HC11 *hc11)
{	    
    Word data;
    Word result;

	hc11->_clock();	
    data.high(hc11->memory[hc11->PC]);
    hc11->PC++;
    
    hc11->_clock();	
    data.low(hc11->memory[hc11->PC]);
    hc11->PC++;
  
    result = hc11->IX - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IX.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IX.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IX.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IX.bit15()));
}

/////////////////////////////////////////////////
//
//  CPX - Compare Index Register X
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 9C
//
//  Clocks: 5
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_9Ch(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = DirAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IX - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IX.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IX.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IX.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IX.bit15()));
}

/////////////////////////////////////////////////
//
//  CPX - Compare Index Register X
//  
//  Addr. Mode:Ext
//  
//  Opcodes: BC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_BCh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = ExtAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IX - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IX.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IX.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IX.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IX.bit15()));
}


/////////////////////////////////////////////////
//
//  CPX - Compare Index Register X
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: AC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_ACh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = IndXAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IX - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IX.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IX.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IX.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IX.bit15()));
}

/////////////////////////////////////////////////
//
//  CPX - Compare Index Register X
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: AC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opCD_ACh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = IndYAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IX - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IX.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IX.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IX.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IX.bit15()));
}

/////////////////////////////////////////////////
//
//  CPY - Compare Index Register Y
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 18h
//           8C
//
//  Clocks: 4
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_8Ch(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;

	hc11->_clock();	
    data.high(hc11->memory[hc11->PC]);
	hc11->PC++;    
    hc11->_clock();	
    data.low(hc11->memory[hc11->PC]);
	hc11->PC++;    

    result = hc11->IY - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IY.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IY.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IY.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IY.bit15()));
}

/////////////////////////////////////////////////
//
//  CPY - Compare Index Register Y
//  
//  Addr. Mode: DIR
//  
//  Opcodes:18 
//          9C
//
//  Clocks: 5
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_9Ch(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = DirAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IY - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IY.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IY.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IY.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IY.bit15()));
}

/////////////////////////////////////////////////
//
//  CPY - Compare Index Register Y
//  
//  Addr. Mode:Ext
//  
//  Opcodes: BC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_BCh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = ExtAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IY - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IY.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IY.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IY.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IY.bit15()));
}


/////////////////////////////////////////////////
//
//  CPY - Compare Index Register Y
//  
//  Addr. Mode: IND, X
//  
//  Opcodes:1Ah 
//          AC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op1A_ACh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;

    address = IndXAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IY - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IY.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IY.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IY.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IY.bit15()));
}

/////////////////////////////////////////////////
//
//  CPY - Compare Index Register Y
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           AC
//
//  Clocks: 6
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_ACh(HC11 *hc11)
{	
    CCRReg mask;    
    Word data;
    Word result;
    word_t address;


    address = IndYAddr(hc11);

	hc11->_clock();	
    data.high(hc11->memory[address]);
    hc11->_clock();	
    data.low(hc11->memory[address+1]);

    result = hc11->IY - data;    
    hc11->CCR.N(result.bit15());
    hc11->CCR.Z(result == 0);
    hc11->CCR.V(hc11->IY.bit15() && !data.bit15() && !result.bit15() ||
                !hc11->IY.bit15() && data.bit15() && result.bit15());                
    hc11->CCR.C((!hc11->IY.bit15()) && data.bit15() ||
                data.bit15() && result.bit15() ||
                result.bit15() && (!hc11->IY.bit15()));
}


/////////////////////////////////////////////////
//
//  JMP - Jump
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           6Eh
//
//  Clocks:4
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_6Eh(HC11 *hc11)
{	
    byte_t offset;    
    
    hc11->_clock();	
    offset = hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->_clock();
    hc11->PC = hc11->IY + offset;
}

/////////////////////////////////////////////////
//
//  JMP - Jump
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 6E
//
//  Clocks: 3
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_6Eh(HC11 *hc11)
{	
    byte_t offset;            
    hc11->_clock();	
    offset = hc11->memory[hc11->PC];
    hc11->PC++;
 
    hc11->_clock();
    hc11->PC = hc11->IX + offset;
}

/////////////////////////////////////////////////
//
//  JMP - Jump 
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 7E
//
//  Clocks: 3
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_7Eh(HC11 *hc11)
{	
    byte_t data;
    
    hc11->_clock();	
    data = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->_clock();	
    hc11->PC.low(hc11->memory[hc11->PC]);
    hc11->PC.high(data);    
}

/////////////////////////////////////////////////
//
//  JSR - Jump to subroutine
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           ADh
//
//  Clocks:7
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_ADh(HC11 *hc11)
{	
    byte_t offset;    
    
    hc11->_clock();	
    offset = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->Push(hc11->PC.low());
    hc11->Push(hc11->PC.high());

    hc11->_clock();	
    hc11->_clock();
    hc11->PC = hc11->IY + offset;
}

/////////////////////////////////////////////////
//
//  JSR - Jump to subroutine
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: AD
//
//  Clocks: 6
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_ADh(HC11 *hc11)
{	
    byte_t offset;    
    
    hc11->_clock();	
    offset = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->Push(hc11->PC.low());
    hc11->Push(hc11->PC.high());

    hc11->_clock();	
    hc11->_clock();
    hc11->PC = hc11->IX + offset;
}

/////////////////////////////////////////////////
//
//  JSR - Jump to subroutine
//  
//  Addr. Mode: EXT
//  
//  Opcodes: BD
//
//  Clocks: 6
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_BDh(HC11 *hc11)
{	
    Word address;
    
    hc11->_clock();	
    address.high(hc11->memory[hc11->PC]);
    hc11->PC++;
    
    hc11->_clock();	
    address.low(hc11->memory[hc11->PC]);
    hc11->PC++;

    hc11->Push(hc11->PC.low());
    hc11->Push(hc11->PC.high());
    
    hc11->_clock();	
    hc11->PC = address;
}

/////////////////////////////////////////////////
//
//  JSR - Jump to subroutine
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 9D
//
//  Clocks: 5
//
//  Flags:
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_9Dh(HC11 *hc11)
{	
    byte_t address;
    
    hc11->_clock();	
    address = hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->Push(hc11->PC.low());
    hc11->Push(hc11->PC.high());
    
    hc11->_clock();	
    hc11->PC = (word_t)address;
}

/////////////////////////////////////////////////
//
//  LDAA - load ACCA
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           A6h
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_A6h(HC11 *hc11)
{	
    word_t address;    
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];    

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDAA - load ACCA
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: A6h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_A6h(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDAA - load ACCA
//  
//  Addr. Mode: EXT
//  
//  Opcodes: B6h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_B6h(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];    

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDAA - load ACCA
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 96
//
//  Clocks: 3
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_96h(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);    

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDAA - Load ACCA
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 86
//
//  Clocks: 2
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_86h(HC11 *hc11)
{	
    hc11->_clock();	
    hc11->ACCA = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  LDAB - load ACCB
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           E6h
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_E6h(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11); 

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  LDAB - load ACCB
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: E6h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_E6h(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  LDAB - load ACCB
//  
//  Addr. Mode: EXT
//  
//  Opcodes: F6h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_F6h(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  LDAB - load ACCB
//  
//  Addr. Mode: DIR
//  
//  Opcodes: D6
//
//  Clocks: 3
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_D6h(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->ACCB = hc11->memory[(word_t)address];

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  LDAB - Load ACCB
//  
//  Addr. Mode: IMM
//  
//  Opcodes: C6
//
//  Clocks: 2
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_C6h(HC11 *hc11)
{	
    hc11->_clock();	
    hc11->ACCB = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  LDD - load ACCD
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           ECh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_ECh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address+1];

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDD - load ACCD
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: ECh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_ECh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address+1];

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDD - load ACCD
//  
//  Addr. Mode: EXT
//  
//  Opcodes: FCh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_FCh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->ACCA = hc11->memory[address];

    hc11->_clock();	
    hc11->ACCB = hc11->memory[address+1];

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDD - load ACCD
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DC
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_DCh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);
    
    hc11->_clock();	
    hc11->ACCA = hc11->memory[(word_t)address];

    hc11->_clock();	
    hc11->ACCB = hc11->memory[(word_t)address+1];

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  LDD - Load ACCD
//  
//  Addr. Mode: IMM
//  
//  Opcodes: CC
//
//  Clocks: 3
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_CCh(HC11 *hc11)
{	
    hc11->_clock();	
    hc11->ACCA = hc11->memory[hc11->PC];
    hc11->PC++;
    
    hc11->_clock();	
    hc11->ACCB = hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  LDS - Load SP
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           AEh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_AEh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->SP.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->SP.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->SP == 0);
    hc11->CCR.N((hc11->SP & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDS - load SP
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: EEh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_AEh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->SP.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->SP.low(hc11->memory[address+1]);
    
    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->SP == 0);
    hc11->CCR.N((hc11->SP & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDS - load SP
//  
//  Addr. Mode: EXT
//  
//  Opcodes: BEh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_BEh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->SP.high(hc11->memory[address]);    

    hc11->_clock();	
    hc11->SP.low(hc11->memory[address+1]);    

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->SP == 0);
    hc11->CCR.N((hc11->SP & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDS - Load SP
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 9E
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_9Eh(HC11 *hc11)
{	
    byte_t address;    
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->SP.high(hc11->memory[(word_t)address]);

    hc11->_clock();	
    hc11->SP.low(hc11->memory[(word_t)address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->SP == 0);
    hc11->CCR.N((hc11->SP & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDS - Load SP
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 8E
//
//  Clocks: 3
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_8Eh(HC11 *hc11)
{	
    hc11->_clock();	
    hc11->SP.high(hc11->memory[hc11->PC]);
    hc11->PC++;
    
    hc11->_clock();	
    hc11->SP.low(hc11->memory[hc11->PC]);
    hc11->PC++;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->SP == 0);
    hc11->CCR.N((hc11->SP & 0x8000)>>15);
}

////////////////////////////////////////////////
//
//  LDX - Load IX
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: CDh
//           EEh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opCD_EEh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->IX.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IX.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IX == 0);
    hc11->CCR.N((hc11->IX & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDX - load X
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: EEh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_EEh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->IX.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IX.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IX == 0);
    hc11->CCR.N((hc11->IX & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDX - load IX
//  
//  Addr. Mode: EXT
//  
//  Opcodes: FEh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_FEh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->IX.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IX.low(hc11->memory[address+1]);    

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IX == 0);
    hc11->CCR.N((hc11->IX & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDX - Load IX
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DE
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_DEh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->IX.high(hc11->memory[(word_t)address]);

    hc11->_clock();	
    hc11->IX.low(hc11->memory[(word_t)address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IX == 0);
    hc11->CCR.N((hc11->IX & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDX - Load IX
//  
//  Addr. Mode: IMM
//  
//  Opcodes: CE
//
//  Clocks: 3
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_CEh(HC11 *hc11)
{	
    hc11->_clock();	
    hc11->IX.high(hc11->memory[hc11->PC]);
    hc11->PC++;
    
    hc11->_clock();	
    hc11->IX.low(hc11->memory[hc11->PC]);
    hc11->PC++;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IX == 0);
    hc11->CCR.N((hc11->IX & 0x8000)>>15);
}

////////////////////////////////////////////////
//
//  LDY - Load IY
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           EEh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_EEh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->IY.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IY.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDY - Load IY
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 1Ah
//           EEh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op1A_EEh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->IY.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IY.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000)>>15);
}


/////////////////////////////////////////////////
//
//  LDY - Load IY
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 18h
//           FE
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_FEh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->IY.high(hc11->memory[address]);

    hc11->_clock();	
    hc11->IY.low(hc11->memory[address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDY - Load IY
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 18h
//           DE
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_DEh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->IY.high(hc11->memory[(word_t)address]);

    hc11->_clock();	
    hc11->IY.low(hc11->memory[(word_t)address+1]);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000)>>15);
}

/////////////////////////////////////////////////
//
//  LDY - Load IY
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 18h
//           CE
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_CEh(HC11 *hc11)
{	    
    hc11->_clock();	
    hc11->IY.high(hc11->memory[hc11->PC]);
    hc11->PC++;
    
    hc11->_clock();	
    hc11->IY.low(hc11->memory[hc11->PC]);
    hc11->PC++;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000)>>15);
}


/////////////////////////////////////////////////
//
//  NEG - Negate Memory Byte
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 70h
//           
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_70h(HC11 *hc11)
{
    byte_t data;
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();
    data = hc11->memory[address];
    hc11->CCR.V(data==0x80);                

    hc11->CCR.C(data != 0); 

    hc11->_clock();
    data = ~data + 1;    

    hc11->_clock();
    hc11->memory.Write(address, data);
            
    hc11->CCR.Z(data == 0);
    hc11->CCR.N((data & 0x80) ? 1 : 0);
}

/////////////////////////////////////////////////
//
//  NEG - Negate Memory Byte
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 60h
//           
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//  Reviewed:  Jason Buttron
//
//	Review: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_60h(HC11 *hc11)
{
    byte_t data;
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();
    data = hc11->memory[address];

    hc11->CCR.V(data==0x80);                
    hc11->CCR.C(data != 0);

    hc11->_clock();
    data = ~data + 1;    

    hc11->_clock();
    hc11->memory.Write(address, data);
    
    hc11->CCR.Z(data == 0);
    hc11->CCR.N((data & 0x80) ? 1 : 0);
}

/////////////////////////////////////////////////
//
//  NEG - Negate Memory Byte
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           60h
//           
//  Clocks: 7
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Review: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_60h(HC11 *hc11)
{
    byte_t data;
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();
    data = hc11->memory[address];

    hc11->CCR.V(data==0x80);                
	hc11->CCR.C(data != 0);

    hc11->_clock();
    data = ~data + 1;    

    hc11->_clock();
    hc11->memory.Write(address, data);
    
    hc11->CCR.Z(data == 0);    
    hc11->CCR.N((data & 0x80) ? 1 : 0);
}

/////////////////////////////////////////////////
//
//  NEGA - Negate ACCA
//  
//  Addr. Mode: INH
//  
//  Opcodes: 40h
//           
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Review: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_40h(HC11 *hc11)
{         
    hc11->_clock();

    hc11->CCR.C(hc11->ACCA != 0);
    hc11->CCR.V(hc11->ACCA==0x80);                

    hc11->ACCA = ~(hc11->ACCA) + 1;
    
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7() ? 1 : 0);
}

/////////////////////////////////////////////////
//
//  NEGB - Negate ACCB
//  
//  Addr. Mode: INH
//  
//  Opcodes: 50h
//           
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Review: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_50h(HC11 *hc11)
{         
    hc11->_clock();

    hc11->CCR.C(hc11->ACCB != 0);
    hc11->CCR.V(hc11->ACCB==0x80);                

    hc11->ACCB = ~(hc11->ACCB) + 1;
    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7() ? 1 : 0);
}


/////////////////////////////////////////////////
//
//  NOP - no operation
//  
//  Addr. Mode: INH
//  
//  Opcodes: 01h
//           
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Review: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_1h(HC11 *hc11)
{
    hc11->_clock();    
}

/////////////////////////////////////////////////
//
//  ORAA - Inclusive OR
//  
//  Addr. Mode: IMM
//  
//  Opcodes: 8Ah
//           
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_8Ah(HC11 *hc11)
{
    byte_t data;
    hc11->_clock();  
    data = hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->ACCA = hc11->ACCA | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.N(hc11->ACCA.bit7());

}

/////////////////////////////////////////////////
//
//  ORAA - Inclusize OR
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 9Ah
//           
//  Clocks: 3
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_9Ah(HC11 *hc11)
{
    byte_t data;
    byte_t address;

    address = DirAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[(word_t)address];

    hc11->ACCA = hc11->ACCA | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  ORAA - Inclusize OR
//  
//  Addr. Mode: EXT
//  
//  Opcodes: BAh
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_BAh(HC11 *hc11)
{
    byte_t data;
    word_t address;
    
    address = ExtAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCA = hc11->ACCA | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  ORAA - Inclusize OR
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: AAh
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_AAh(HC11 *hc11)
{
    byte_t data;
    word_t address;

    address = IndXAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCA = hc11->ACCA | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  ORAA - Inclusize OR
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h 
//           AAh
//           
//  Clocks: 5
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_AAh(HC11 *hc11)
{
    byte_t data;
    word_t address;    
    address = IndYAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCA = hc11->ACCA | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  ORAB - Inclusize OR
//  
//  Addr. Mode: IMM
//  
//  Opcodes: CAh
//           
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_CAh(HC11 *hc11)
{
    byte_t data;
    hc11->_clock();  
    data = hc11->memory[hc11->PC];
    hc11->PC++;

    hc11->ACCB = hc11->ACCB | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  ORAB - Inclusize OR
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DAh
//           
//  Clocks: 3
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_DAh(HC11 *hc11)
{
    byte_t data;
    byte_t address;

    address = DirAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[(word_t)address];

    hc11->ACCB = hc11->ACCB | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  ORAB - Inclusize OR
//  
//  Addr. Mode: EXT
//  
//  Opcodes: FAh
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_FAh(HC11 *hc11)
{
    byte_t data;
    word_t address;    
    address = ExtAddr(hc11);    

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCB = hc11->ACCB | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  ORAB - Inclusize OR
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: AAh
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_EAh(HC11 *hc11)
{
    byte_t data;
    word_t address;

    address = IndXAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCB = hc11->ACCB | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7());
}


/////////////////////////////////////////////////
//
//  ORAB - Inclusize OR
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h 
//           EAh
//           
//  Clocks: 5
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_EAh(HC11 *hc11)
{
    byte_t data;    
    word_t address;
    
    address = IndYAddr(hc11);

    hc11->_clock();  
    data = hc11->memory[address];    

    hc11->ACCB = hc11->ACCB | data;

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  PSHA - push ACCA to stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 36h
//           
//  Clocks: 3
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_36h(HC11 *hc11)
{
    hc11->_clock();
    hc11->Push(hc11->ACCA);        
}

/////////////////////////////////////////////////
//
//  PSHB - push ACCB to stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 37h
//           
//  Clocks: 3
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_37h(HC11 *hc11)
{
    hc11->_clock();
    hc11->Push(hc11->ACCB);        
}

/////////////////////////////////////////////////
//
//  PSHX - push IX to stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 3Ch
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_3Ch(HC11 *hc11)
{
    hc11->_clock();
    hc11->Push(hc11->IX.low());        
    hc11->Push(hc11->IX.high());        
}

/////////////////////////////////////////////////
//
//  PSHY - push IY to stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 18h
//           3Ch
//           
//  Clocks: 5
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_3Ch(HC11 *hc11)
{
    hc11->_clock();
    hc11->Push(hc11->IY.low());        
    hc11->Push(hc11->IY.high());        
}


/////////////////////////////////////////////////
//
//  PULA - pull ACCA from stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 32h
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_32h(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->ACCA = hc11->Pull();    
}

/////////////////////////////////////////////////
//
//  PULB - pull ACCB from stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 33h
//           
//  Clocks: 4
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_33h(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->ACCB = hc11->Pull();    
}


/////////////////////////////////////////////////
//
//  PULX - pull IX from stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 38h
//           
//  Clocks: 5
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_38h(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->IX.high(hc11->Pull());
    hc11->IX.low(hc11->Pull());        
}


/////////////////////////////////////////////////
//
//  PULY - pull IY from stack
//  
//  Addr. Mode: INH
//  
//  Opcodes: 18h
//           38h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_38h(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->IY.high(hc11->Pull());
    hc11->IY.low(hc11->Pull());        
}



/////////////////////////////////////////////////
//
//  ROLA - rotate left
//  
//  Addr. Mode: INH
//  
//  Opcodes: 49h
//
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_49h(HC11 *hc11)
{    
	byte_t carry;

	carry=hc11->CCR.C();
    hc11->_clock();               

    hc11->CCR.C(hc11->ACCA.bit7());                    
    
    hc11->ACCA = (hc11->ACCA << 1) | carry;
    
    hc11->CCR.Z(hc11->ACCA == 0);                        
    hc11->CCR.N(hc11->ACCA.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
}

/////////////////////////////////////////////////
//
//  ROLB - rotate left
//  
//  Addr. Mode: INH
//  
//  Opcodes: 59h
//
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_59h(HC11 *hc11)
{    
    hc11->_clock();               
    
    byte_t carry;

	carry=hc11->CCR.C();
    hc11->CCR.C(hc11->ACCB.bit7());                    

    hc11->ACCB = (hc11->ACCB << 1) | carry;

    hc11->CCR.Z(hc11->ACCB == 0);                        
    hc11->CCR.N(hc11->ACCB.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
}


/////////////////////////////////////////////////
//
//  ROL - rotate left
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 79h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_79h(HC11 *hc11)
{   
    word_t address;
    Byte data;
	byte_t carry;

	carry=hc11->CCR.C();
    
    address = ExtAddr(hc11);    

    hc11->_clock();               
    data = hc11->memory[address];

    hc11->CCR.C(data.bit7());                    

    hc11->_clock();               
    data = (data << 1) | carry;

    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                

    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////
//
//  ROL - rotate left
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 69h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_69h(HC11 *hc11)
{   
    word_t address;
    Byte data;
	byte_t carry;

	carry=hc11->CCR.C();

    address = IndXAddr(hc11);
    
    hc11->_clock();               
    data = hc11->memory[address];

    hc11->CCR.C(data.bit7());                    

    hc11->_clock();               
    data = (data << 1) | carry;
           
    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////
//
//  ROL - rotate left
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes:18h 
//          69h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_69h(HC11 *hc11)
{   
    word_t address;
    Byte data;
	byte_t carry;

	carry=hc11->CCR.C();

    address = IndYAddr(hc11);
    
    hc11->_clock();               
    data = hc11->memory[address];
    
    hc11->CCR.C(data.bit7());                    

    hc11->_clock();               
    data = (data << 1) | carry;
        
    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////
//
//  RORA - rotate right
//  
//  Addr. Mode: INH
//  
//  Opcodes: 46h
//
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//	Reviewed by: Paul Clarke 1/22/98
//		The old carry bit rotates into the high
//		bit instead of the bit zero
//
////////////////////////////////////////////////

void HC11::op_46h(HC11 *hc11)
{    
    hc11->_clock();               

		// Save the current carry bit
		bit_t carry_old = hc11->CCR.C();

    hc11->CCR.C(hc11->ACCA.bit0());    

    hc11->ACCA = (hc11->ACCA >> 1);
        
		hc11->ACCA.bit7(carry_old);

    hc11->CCR.Z(hc11->ACCA == 0);                    
    hc11->CCR.N(hc11->ACCA.bit7());                    
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                                
}

/////////////////////////////////////////////////
//
//  RORB - rotate right
//  
//  Addr. Mode: INH
//  
//  Opcodes: 56h
//
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//	Reviewed by: Paul Clarke (see RORA)
//
////////////////////////////////////////////////

void HC11::op_56h(HC11 *hc11)
{    
    hc11->_clock();               
    
//		hc11->Lock();
		// Save the current carry bit
		bit_t carry_old = hc11->CCR.C();
  			
		hc11->CCR.C(hc11->ACCB.bit0());    
		
		hc11->ACCB = (hc11->ACCB >> 1);

		hc11->ACCB.bit7(carry_old);
        
    hc11->CCR.Z(hc11->ACCB == 0);                    
    hc11->CCR.N(hc11->ACCB.bit7());                    
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                                
//		hc11->Unlock();
}


/////////////////////////////////////////////////
//
//  ROR - rotate right
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 76h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//	Reviewed by: Paul Clarke (see RORA)
//
////////////////////////////////////////////////

void HC11::op_76h(HC11 *hc11)
{   
    word_t address;
    Byte data;

    address = ExtAddr(hc11);
    
    hc11->_clock();               
    data = hc11->memory[address];
    
		// Save the current carry bit
		bit_t carry_old = hc11->CCR.C();

    hc11->CCR.C(data.bit0());                    

    hc11->_clock();               
    data = (data >> 1) | (carry_old << 7);
    
    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////
//
//  ROR - rotate right
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 66h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//	Reviewed by: Paul Clarke (see RORA)
//
////////////////////////////////////////////////

void HC11::op_66h(HC11 *hc11)
{   
    word_t address;
    Byte data;

    address = IndXAddr(hc11);
    
    hc11->_clock();               
    data = hc11->memory[address];
    
		// Save the current carry bit
		bit_t carry_old = hc11->CCR.C();

    hc11->CCR.C(data.bit0());                    

    hc11->_clock();               
    data = (data >> 1) | (carry_old << 7);
    
    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////
//
//  ROR - rotate right
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes:18h 
//          66h
//
//  Clocks: 6
//
//  Flags: 
//
//  Author: Kalle Anderson 
//	Reviewed by: Paul Clarke (see RORA)
//
////////////////////////////////////////////////

void HC11::opIY_66h(HC11 *hc11)
{   
    word_t address;
    Byte data;

    address = IndYAddr(hc11);
    
    hc11->_clock();               
    data = hc11->memory[address];

		// Save the current carry bit
		bit_t carry_old = hc11->CCR.C();

    hc11->CCR.C(data.bit0());                    

    hc11->_clock();               
    data = (data >> 1) | (carry_old << 7);
        
    hc11->CCR.Z(data == 0);                        
    hc11->CCR.N(data.bit7());                        
    hc11->CCR.V(hc11->CCR.C() ^ hc11->CCR.N());                
    
    hc11->_clock();               
    hc11->memory.Write(address, data);
}

/////////////////////////////////////////////////
//
//  RTI - return from interrupt
//  
//  Addr. Mode: INH
//  
//  Opcodes: 3bh
//
//  Clocks: 12
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
////////////////////////////////////////////////

void HC11::op_3Bh(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->UnStackRegisters();
    if(hc11->xbit_cleared)
      hc11->CCR.X(0);          
    else if(!hc11->CCR.X())
      hc11->xbit_cleared=true;

    //    log("rti\n",0);
}


/////////////////////////////////////////////////
//
//  RTS - return from interrupt
//  
//  Addr. Mode: INH
//  
//  Opcodes: 39h
//
//  Clocks: 5
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
////////////////////////////////////////////////

void HC11::op_39h(HC11 *hc11)
{
    hc11->_clock();
    hc11->_clock();
    hc11->PC.high(hc11->Pull());
    hc11->PC.low(hc11->Pull());    
}


/////////////////////////////////////////////////
//
//  SEC - Set Carry Flag
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0D
//
//  Clocks: 2
//
//  Flags: C
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Dh(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.C(1);
}

/////////////////////////////////////////////////
//
//  SEI - Set Interrupt Mask
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0F
//
//  Clocks: 2
//
//  Flags: I
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Fh(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.I(1);
}



/////////////////////////////////////////////////
//
//  SEV - Set Twos Complement Overflow Bit
//  
//  Addr. Mode: INH
//  
//  Opcodes: 0B
//
//  Clocks: 2
//
//  Flags: V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_Bh(HC11 *hc11)
{	
	hc11->_clock();	
    hc11->CCR.V(1);
}



/////////////////////////////////////////////////
//
//  STAA - Store ACCA
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           A7h
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_A7h(HC11 *hc11)
{	
    word_t address;

    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  STAA - Store ACCA
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: A7h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_A7h(HC11 *hc11)
{	
    word_t address;

    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  STAA - Store ACCA
//  
//  Addr. Mode: EXT
//  
//  Opcodes: B7h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_B7h(HC11 *hc11)
{	
    word_t address;

    address = ExtAddr(hc11);
    
	hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  STAA - Store ACCA
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 97h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_97h(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->ACCA);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCA == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  STAB - Store ACCB
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           E7h
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_E7h(HC11 *hc11)
{	
    word_t address;

    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}

/////////////////////////////////////////////////
//
//  STAB - Store ACCB
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: E7h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_E7h(HC11 *hc11)
{	
    word_t address;

    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}


/////////////////////////////////////////////////
//
//  STAB - Store ACCB
//  
//  Addr. Mode: EXT
//  
//  Opcodes: F7h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_F7h(HC11 *hc11)
{	
    word_t address;

    address = ExtAddr(hc11);
    
    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}


/////////////////////////////////////////////////
//
//  STAB - Store ACCB
//  
//  Addr. Mode: DIR
//  
//  Opcodes: D7h
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_D7h(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->ACCB);

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->ACCB == 0);    
    hc11->CCR.N(hc11->ACCB.bit7());
}



/////////////////////////////////////////////////
//
//  STD - Store ACCD
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           EDh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_EDh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  STD - Store ACCD
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: EDh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_EDh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}


/////////////////////////////////////////////////
//
//  STD - Store ACCD
//  
//  Addr. Mode: EXT
//  
//  Opcodes: FDh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_FDh(HC11 *hc11)
{	
    word_t address;

    address = ExtAddr(hc11);
    
    hc11->_clock();	
    hc11->memory.Write(address, hc11->ACCA);
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
}

/////////////////////////////////////////////////
//
//  STD - Store ACCD
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DDh
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_DDh(HC11 *hc11)
{	
    byte_t address;

    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->ACCA);    
    hc11->_clock();	
	hc11->memory.Write((word_t)address+1, hc11->ACCB);

    hc11->CCR.V(0);
    hc11->CCR.Z((hc11->ACCB | hc11->ACCA) == 0);    
    hc11->CCR.N(hc11->ACCA.bit7());
};



/////////////////////////////////////////////////
//
//  STOP - Stop Processing
//  
//  Addr. Mode:INH
//  
//  Opcodes: CFh
//
//  Clocks: 2
//
//  Flags: 
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_CFh(HC11 *hc11)
{	
    static CCRReg real_CCR;

    if(!hc11->stopped)
    {   
        if(!hc11->CCR.S())
	    {	        
            hc11->stopped = true;
            real_CCR = hc11->CCR;                    
    
            hc11->CCR.I(1);
            hc11->CCR.X(1);                        
        }    
    } 
    
    if(!hc11->XIRQLevel() || (!hc11->CCR.I() && !hc11->IRQLevel()))
    {
        hc11->stopped = false;
        hc11->CCR = real_CCR;
        
    }
    else
    {
        hc11->timer_system->main_clock_divider--;
        hc11->PC--;
    }
    
}


/////////////////////////////////////////////////
//
//  STS - Store SP
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           AFh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_AFh(HC11 *hc11)
{	
    word_t address;

    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->SP.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->SP.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->SP == 0);    
    hc11->CCR.N((hc11->SP & 0x8000)?1:0);
}


/////////////////////////////////////////////////
//
//  STS - Store SP
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: AFh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_AFh(HC11 *hc11)
{	
    word_t address;

    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->SP.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->SP.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->SP == 0);    
    hc11->CCR.N((hc11->SP & 0x8000)?1:0);
}


/////////////////////////////////////////////////
//
//  STS - Store SP
//  
//  Addr. Mode: EXT
//  
//  Opcodes: BFh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_BFh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->SP.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->SP.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->SP == 0);    
    hc11->CCR.N((hc11->SP & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STS - Store SP
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DFh
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_9Fh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->SP.high());    
    hc11->_clock();	
	hc11->memory.Write((word_t)address+1, hc11->SP.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->SP == 0);    
    hc11->CCR.N((hc11->SP & 0x8000)?1:0);
}


/////////////////////////////////////////////////
//
//  STX - Store IX
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: CDh
//           EFh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opCD_EFh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IX.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IX.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IX == 0);    
    hc11->CCR.N((hc11->IX & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STX - Store IX
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: EFh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_EFh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IX.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IX.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IX == 0);    
    hc11->CCR.N((hc11->IX & 0x8000)?1:0);
}


/////////////////////////////////////////////////
//
//  STX - Store X
//  
//  Addr. Mode: EXT
//  
//  Opcodes: FFh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_FFh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IX.high());
    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IX.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IX == 0);    
    hc11->CCR.N((hc11->IX & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STX - Store X
//  
//  Addr. Mode: DIR
//  
//  Opcodes: DFh
//
//  Clocks: 4
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_DFh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->IX.high());    
    hc11->_clock();	
	hc11->memory.Write((word_t)address+1, hc11->IX.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IX == 0);    
    hc11->CCR.N((hc11->IX & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STY - Store Y
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 18h
//           EFh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_EFh(HC11 *hc11)
{	
    word_t address;
    address = IndYAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IY.high());    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IY.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IY == 0);    
    hc11->CCR.N((hc11->IY & 0x8000)?1:0);

}


/////////////////////////////////////////////////
//
//  STY - Store Y
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 1Ah
//           EFh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op1A_EFh(HC11 *hc11)
{	
    word_t address;
    address = IndXAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IY.high());    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IY.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IY == 0);    
    hc11->CCR.N((hc11->IY & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STY - Store Y
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 18h
//           FFh
//
//  Clocks: 6
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_FFh(HC11 *hc11)
{	
    word_t address;
    address = ExtAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write(address, hc11->IY.high());    
    hc11->_clock();	
    hc11->memory.Write(address+1, hc11->IY.low());

    hc11->CCR.V(0);    
    hc11->CCR.Z(hc11->IY == 0);    
    hc11->CCR.N((hc11->IY & 0x8000)?1:0);
}

/////////////////////////////////////////////////
//
//  STY - Store Y
//  
//  Addr. Mode: DIR
//  
//  Opcodes: 18h
//           DFh
//
//  Clocks: 5
//
//  Flags: N, Z, V
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_DFh(HC11 *hc11)
{	
    byte_t address;
    address = DirAddr(hc11);

    hc11->_clock();	
    hc11->memory.Write((word_t)address, hc11->IY.high());
    
    hc11->_clock();	
	hc11->memory.Write((word_t)address+1, hc11->IY.low());

    hc11->CCR.V(0);
    hc11->CCR.Z(hc11->IY == 0);
    hc11->CCR.N((hc11->IY & 0x8000) ? 1 : 0);
}


/////////////////////////////////////////////////
//
//  SWI - Software Interrupt
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 3fh
//
//  Clocks: 14
//
//  Flags: I
//
//  Author: Kalle Anderson 
//
////////////////////////////////////////////////

void HC11::op_3Fh(HC11 *hc11)
{	
	hc11->_clock();	

	hc11->StackRegisters();
	hc11->CCR.I(1);
	hc11->FetchVector(SWIVector);
};

/////////////////////////////////////////////////
//
//  TAB - Transfer ACCA to ACCB
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 16h
//
//  Clocks: 2
//
//  Flags:  N, Z
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_16h(HC11 *hc11)
{	
	hc11->_clock();	
	hc11->ACCB = hc11->ACCA;

	if(hc11->ACCB == 0)
		hc11->CCR.Z(1);

	if(hc11->ACCB.bit7())
		hc11->CCR.N(1);		
	
	hc11->CCR.V(0);
};

/////////////////////////////////////////////////
//
//  TAP - Transfer ACCA to CCR
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 06h
//
//  Clocks: 2
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_6h(HC11 *hc11)
{	
	hc11->_clock();
	if(!hc11->CCR.X())	//cannot set the X bit in CCR
		hc11->CCR = hc11->ACCA & 0xBF;
	else
  {
		hc11->CCR = hc11->ACCA;
    if (hc11->CCR.X() == 0)
      hc11->xbit_cleared = true;
  }
};

/////////////////////////////////////////////////
//
//  TBA - Transfer ACCB to ACCA
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 17h
//
//  Clocks: 2
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_17h(HC11 *hc11)
{	
	hc11->_clock();	
	hc11->ACCA = hc11->ACCB;

	if(hc11->ACCA == 0)
		hc11->CCR.Z(1);

	if(hc11->ACCA.bit7())
		hc11->CCR.N(1);		

	hc11->CCR.V(0);
};

/////////////////////////////////////////////////
//
//  TEST - TEST Operation
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 00h
//
//  Clocks: ?
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_0h(HC11 *hc11)
{	
	if(hc11->mode != SPECIAL_TEST)
		HC11::op_illegal(hc11);				
	else 
		for(;;)
		{
			hc11->_clock();	
			hc11->PC=hc11->PC+1;
		}		
};


/////////////////////////////////////////////////
//
//  TPA - Transfer CCR to ACCA
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 07h
//
//  Clocks: 2
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_7h(HC11 *hc11)
{	
	hc11->_clock();	
	hc11->ACCA = hc11->CCR;
};


/////////////////////////////////////////////////
//
//  TSTA - Test
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 4Dh
//
//  Clocks: 2
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//	Reviewed:	Paul Clarke 1/29/98
//
////////////////////////////////////////////////

void HC11::op_4Dh(HC11 *hc11)
{
    hc11->_clock();		
		hc11->CCR.N(hc11->ACCA.bit7());
    hc11->CCR.Z(hc11->ACCA == 0);
    hc11->CCR.V(0);
    hc11->CCR.C(0);		
}

/////////////////////////////////////////////////
//
//  TSTB - Test
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 5Dh
//
//  Clocks: 2
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_5Dh(HC11 *hc11)
{
    hc11->_clock();		
	hc11->CCR.N(hc11->ACCB.bit7());
    hc11->CCR.Z(hc11->ACCB == 0);
    hc11->CCR.V(0);
    hc11->CCR.C(0);		
}

/////////////////////////////////////////////////
//
//  TST - Test
//  
//  Addr. Mode: EXT
//  
//  Opcodes: 5Dh
//
//  Clocks: 6
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//	Reviewed:	Paul Clarke 1/29/98
//
////////////////////////////////////////////////

void HC11::op_7Dh(HC11 *hc11)
{
	Word data;
	word_t address;
	
    address = ExtAddr(hc11);
    
	hc11->_clock();
	data = hc11->memory[address];	

    hc11->_clock();		    
    hc11->_clock();		
	hc11->CCR.N(data.bit7());
    hc11->CCR.Z(data == 0);
    hc11->CCR.V(0);
    hc11->CCR.C(0);		
};


/////////////////////////////////////////////////
//
//  TST - Test
//  
//  Addr. Mode: IND, X
//  
//  Opcodes: 6Dh
//
//  Clocks: 6
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//	Reviewed:	Paul Clarke 1/29/98
//
////////////////////////////////////////////////

void HC11::op_6Dh(HC11 *hc11)
{
    Word data;
    word_t address;
	
	address = IndXAddr(hc11);
	
	hc11->_clock();
	data = hc11->memory[address];	

    hc11->_clock();		    
    hc11->_clock();		
	hc11->CCR.N(data.bit7());
    hc11->CCR.Z(data == 0);
    hc11->CCR.V(0);
    hc11->CCR.C(0);		
};


/////////////////////////////////////////////////
//
//  TST - Test
//  
//  Addr. Mode: IND, Y
//  
//  Opcodes: 	18h
//				5Dh
//
//  Clocks: 7
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//	Reviewed:	Paul Clarke 1/29/98
//
////////////////////////////////////////////////

void HC11::opIY_6Dh(HC11 *hc11)
{
    Word data;
	word_t address;

    address = IndYAddr(hc11);
	data = hc11->memory[address];	
    
    hc11->_clock();		    
    hc11->_clock();		
	hc11->CCR.N(data.bit7());
    hc11->CCR.Z(data == 0);
    hc11->CCR.V(0);
    hc11->CCR.C(0);		
};


/////////////////////////////////////////////////
//
//  TSX - Transfer from SP to IX
//  
//  Addr. Mode: Inherent
//  
//  Opcodes: 30h
//
//  Clocks: 4
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_30h(HC11 *hc11)
{
	hc11->_clock();
	hc11->_clock();
	hc11->IX = hc11->SP+1;
};

/////////////////////////////////////////////////
//
//  TSY - Transfer from SP to IY
//  
//  Addr. Mode: Inherent
//  
//  Opcode: 18h
//	        30h
//
//  Clocks: 4
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_30h(HC11 *hc11)
{
	hc11->_clock();
	hc11->_clock();
	hc11->IY = hc11->SP+1;
};

/////////////////////////////////////////////////
//
//  TXS - Transfer from IX to SP
//  
//  Addr. Mode: Inherent
//  
//  Opcode: 35h
//
//  Clocks: 4
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_35h(HC11 *hc11)
{
	hc11->_clock();
	hc11->_clock();	
	hc11->SP = hc11->IX-1;
};

/////////////////////////////////////////////////
//
//  TYS - Transfer from IY to SP
//  
//  Addr. Mode: Inherent
//  
//  Opcode: 18h
//	    35h
//
//  Clocks: 4
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_35h(HC11 *hc11)
{
	hc11->_clock();
	hc11->_clock();
	hc11->SP = hc11->IY -1;
};


/////////////////////////////////////////////////
//
//  WAI - Wait for Interrupt
//  
//  Addr. Mode: Inherint
//  
//  Opcode: 3E
//	    
//  Clocks: 14
//
//  Flags:  None
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

/*	This is the way the function should work, but it should possible be change, because
    there is a chance it will loop in here forever, if no interrupts occured. If this
    was the case, the caller would be locked up*/


void HC11::op_3Eh(HC11 *hc11)
{
    static CCRReg real_CCR;    
    // disable interrupts
        
    if(!hc11->waiting)
    {
        hc11->_clock();
        hc11->StackRegisters();    
        hc11->waiting = true;
        
        real_CCR = hc11->CCR;

        // mask these cause this will do interrupt checking from now on
        hc11->CCR.X(1);
        hc11->CCR.I(1);
    }
    
    if((!real_CCR.X() && !hc11->XIRQLevel()) || 
            (!real_CCR.I() && hc11->InterruptPending()))
    {        	  
        hc11->CCR = real_CCR;
        hc11->waiting = false;
        hc11->ResolveInterrupt();            
    }   
    else hc11->PC--;            
};

/////////////////////////////////////////////////
//
//  XGDX - Exchange ACCD and IX
//  
//  Addr. Mode: Inherint
//  
//  Opcode: 8Fh
//	    
//
//  Clocks: 3 
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::op_8Fh(HC11 *hc11)
{
	word_t temp;

	temp = ((hc11->ACCA)<<8) | hc11->ACCB;

	hc11->_clock();
	hc11->ACCB = hc11->IX.low();
	hc11->ACCA = hc11->IX.high();
	
	hc11->_clock();
	hc11->IX = temp;
}

/////////////////////////////////////////////////
//
//  XGDY - Exchange ACCD and IY
//  
//  Addr. Mode: Inherent/Y
//  
//  Opcode: 18h
//	        8Fh 
//
//  Clocks: 3 (4)
//
//  Flags:  
//
//  Author: Kalle Anderson 
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////

void HC11::opIY_8Fh(HC11 *hc11)
{
	word_t temp;

	temp = ((hc11->ACCA)<<8) | hc11->ACCB;

	hc11->_clock();
	hc11->ACCB = hc11->IY.low();
	hc11->ACCA = hc11->IY.high();

	hc11->_clock();
	hc11->IY = temp;
}

/////////////////////////////////////////////////
//
//  Opcodes that deal with IX and IY use these codes
//  to precede the actually opcode
//  
//  Opcode: 1A/CD
//          ---
//  Author: Kalle Anderson 
//
////////////////////////////////////////////////

void HC11::op_1Ah(HC11 *hc11)
{	
	byte_t num;
	hc11->_clock();
    num = hc11->memory[hc11->PC];
    hc11->PC++;

    switch(num)
    {
        case 0xAC: HC11::op1A_ACh(hc11);break;
        case 0xEE: HC11::op1A_EEh(hc11);break;
        case 0xEF: HC11::op1A_EFh(hc11);break;
				case 0x83: HC11::op1A_83h(hc11);break;
				case 0x93: HC11::op1A_93h(hc11);break;
				case 0xB3: HC11::op1A_B3h(hc11);break;
				case 0xA3: HC11::op1A_A3h(hc11);break;
        default: HC11::op_illegal(hc11);
    }
}              

void HC11::op_CDh(HC11 *hc11)
{
	byte_t num;
	hc11->_clock();
    num = hc11->memory[hc11->PC];
    hc11->PC++;

    switch(num)
    {
        case 0xAC: HC11::opCD_ACh(hc11);break;
        case 0xEE: HC11::opCD_EEh(hc11);break;
        case 0xEF: HC11::opCD_EFh(hc11);break;
				case 0xA3: HC11::opCD_A3h(hc11);break;
        default: HC11::op_illegal(hc11);
    }
}              

/////////////////////////////////////////////////
//
//  CPD - Compare Accumulator D
//  
//  Addr. Mode: IMM
//  
//  Opcode: 1Ah 83 
//	    
//
//  Clocks:  4 (5)
//
//  Flags:  N Z V C
//
//  Author: Paul Clarke
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////
void HC11::op1A_83h(HC11* hc11)
{
	Word temp;
	Word result;
	
	Word accd;
	accd = (hc11->ACCA << 8) | hc11->ACCB;

	hc11->_clock();

	temp.high(hc11->memory[hc11->PC]);
	hc11->PC++;

	hc11->_clock();

	temp.low(hc11->memory[hc11->PC]);
	hc11->PC++;

	result = accd - temp;

	hc11->CCR.N(result.bit15());
	hc11->CCR.Z(result == 0);
	hc11->CCR.V((accd.bit15() && !temp.bit15() && !result.bit15()) ||
							(!accd.bit15() && temp.bit15() && result.bit15()));
	hc11->CCR.C((!accd.bit15() && temp.bit15()) || (temp.bit15() && result.bit15()) ||
							(result.bit15() && !accd.bit15()));

	hc11->_clock();

}



/////////////////////////////////////////////////
//
//  CPD - Compare Accumulator D
//  
//  Addr. Mode: DIR
//  
//  Opcode: 1Ah 93h
//	    
//
//  Clocks:  5 (6)
//
//  Flags:  N Z V C
//
//  Author: Paul Clarke
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////
void HC11::op1A_93h(HC11* hc11)
{
	byte_t address;
	Word temp;
	Word result;

	Word accd;
	accd = (hc11->ACCA << 8) | hc11->ACCB;

	address = DirAddr(hc11);

	hc11->_clock();

	temp.high(hc11->memory[address]);
	temp.low(hc11->memory[address+1]);
	
	hc11->_clock();

	result = accd - temp;

	hc11->CCR.N(result.bit15());
	hc11->CCR.Z(result == 0);
	hc11->CCR.V((accd.bit15() && !temp.bit15() && !result.bit15()) ||
							(!accd.bit15() && temp.bit15() && result.bit15()));
	hc11->CCR.C((!accd.bit15() && temp.bit15()) || (temp.bit15() && result.bit15()) ||
							(result.bit15() && !accd.bit15()));


}
/////////////////////////////////////////////////
//
//  CPD - Compare Accumulator D
//  
//  Addr. Mode: EXT
//  
//  Opcode: 1Ah B3h
//	    
//
//  Clocks:  6 (7)
//
//  Flags:  N Z V C
//
//  Author: Paul Clarke
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////
void HC11::op1A_B3h(HC11* hc11)
{
	word_t address;
	Word temp;
	Word result;
	Word accd;

	accd = (hc11->ACCA << 8) | hc11->ACCB;

	address = ExtAddr(hc11);

	hc11->_clock();

	temp.high(hc11->memory[address]);
	temp.low(hc11->memory[address+1]);

	hc11->_clock();

	result = accd - temp;
	
	hc11->_clock();

	hc11->CCR.N(result.bit15());
	hc11->CCR.Z(result == 0);
	hc11->CCR.V((accd.bit15() && !temp.bit15() && !result.bit15()) ||
							(!accd.bit15() && temp.bit15() && result.bit15()));
	hc11->CCR.C((!accd.bit15() && temp.bit15()) || (temp.bit15() && result.bit15()) ||
							(result.bit15() && !accd.bit15()));


}
/////////////////////////////////////////////////
//
//  CPD - Compare Accumulator D
//  
//  Addr. Mode: IND, X
//  
//  Opcode: 1Ah A3h
//	    
//
//  Clocks:  6(7)
//
//  Flags:  N Z V C
//
//  Author: Paul Clarke
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////
void HC11::op1A_A3h(HC11* hc11)
{
	word_t address;
	Word temp;
	Word result;
	Word accd;

	accd = (hc11->ACCA << 8) | hc11->ACCB;

	address = IndXAddr(hc11);

	hc11->_clock();

	temp.high(hc11->memory[address]);
	temp.low(hc11->memory[address+1]);

	hc11->_clock();

	result = accd - temp;

	hc11->_clock();

	hc11->CCR.N(result.bit15());
	hc11->CCR.Z(result == 0);
	hc11->CCR.V((accd.bit15() && !temp.bit15() && !result.bit15()) ||
							(!accd.bit15() && temp.bit15() && result.bit15()));
	hc11->CCR.C((!accd.bit15() && temp.bit15()) || (temp.bit15() && result.bit15()) ||
							(result.bit15() && !accd.bit15()));


}
/////////////////////////////////////////////////
//
//  CPD - Compare Accumulator D
//  
//  Addr. Mode: Indexed Y
//  
//  Opcode: CDh A3h
//	    
//  Clocks:  6(7)
//
//  Flags:  N Z V C
//
//  Author: Paul Clarke
//
//	Reviewed: Jason Buttron
//
////////////////////////////////////////////////
void HC11::opCD_A3h(HC11* hc11)
{
	word_t address;
	Word temp;
	Word result;
	Word accd;

	accd = (hc11->ACCA << 8) | hc11->ACCB;

	address = IndYAddr(hc11);

	hc11->_clock();

	temp.high(hc11->memory[address]);
	temp.low(hc11->memory[address+1]);

	hc11->_clock();

	result = accd - temp;

	hc11->_clock();

	hc11->CCR.N(result.bit15());
	hc11->CCR.Z(result == 0);
	hc11->CCR.V((accd.bit15() && !temp.bit15() && !result.bit15()) ||
							(!accd.bit15() && temp.bit15() && result.bit15()));
	hc11->CCR.C((!accd.bit15() && temp.bit15()) || (temp.bit15() && result.bit15()) ||
							(result.bit15() && !accd.bit15()));


}