////////////////////////////////////////////////////////////////////////////////
// File Name:       cforc_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:37:24
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(CFORC_C_H)
#define CFORC_C_H

#include "ByteRegister.h"
#include "PortRegister.h"

//##ModelId=3A3D09AE029A
class CFORC_C: public ByteRegister
{
public:
	//##ModelId=3A3D09AE02D6
    void Write(byte_t data);
	//##ModelId=3A3D09AE02CE
    PortRegister* portA;
	//##ModelId=3A3D09AE02C4
    ByteRegister* oc1m;
	//##ModelId=3A3D09AE02B0
    ByteRegister* oc1d;
	//##ModelId=3A3D09AE02A6
    ByteRegister* tctl1;
};

#endif //!defined(CFORC_C_H)
