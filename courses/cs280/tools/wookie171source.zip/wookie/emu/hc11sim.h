#ifndef HC11SIM_H
#define HC11SIM_H

#include "hc11.h"

typedef enum {None, BriefCase, RugWarriorBootstrap, RugWarriorExpanded} HC11SimConfig;

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: HC11Sim
//
//  Author: Kalle Anderson & Jason Buttron
//
//  Purpose: This class is used to put the HC11 into various configurations, 
//           like Briefcase or RugWarrior. Later, perhaps it can be used
//           to add memory devices or other things like that.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Added a keyword 'private' to declaration
//
/////////////////////////////////////////////////////////////////////////////


//##ModelId=3A3D099C00FA
class HC11Sim
{
 private:
	//##ModelId=3A3D099C011A
    HC11SimConfig cfg;
	//##ModelId=3A3D099C0110
    RAM* expanded_ram;
	//##ModelId=3A3D099C0106
    ROM* briefcase_rom;

 public:    
    
	//##ModelId=3A3D099C00FD
    HC11 hc11; 

	//##ModelId=3A3D099C0138
    HC11Sim(void);    
	//##ModelId=3A3D099C0136
    ~HC11Sim(void);    
	//##ModelId=3A3D099C012E
    void Config(HC11SimConfig ncfg);
	//##ModelId=3A3D099C012C
    void SetupPsuedoVectors(word_t vector_base_addr);
	//##ModelId=3A3D099C0124
    void SetStartAddress(Word address);
	//##ModelId=3A3D099C0122
    bool LoadS19File(const char *fname);
};

#endif // HC11SIM_H
