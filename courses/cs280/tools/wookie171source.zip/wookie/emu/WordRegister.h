#if !defined(WORDREGISTER_H)
#define WORDREGISTER_H


#include "basetypes.h"

#include "ByteRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: WordRegister
//
//  Author: Kalle Anderson et al.
//
//  Purpose: A 16-bit register from two ByteRegisters combined that has 
//			 Read and Write operations.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class WordRegister into its own header
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099B03A1
class WordRegister
{
 public:		
    // all this is is a container for two ByteRegisters
	//##ModelId=3A3D099B03B7
	ByteRegister	low;        
	//##ModelId=3A3D099B03AD
	ByteRegister	high;

	//##ModelId=3A3D099B03C9
	word_t Read(void){return ((high<<8)|(low));};
	//##ModelId=3A3D099B03C2
    void Write(word_t data){low = data & 0xFF; high = (data & 0xFF00)>>8;};

	//##ModelId=3A3D099B03BF
    word_t operator++(int) //Word++
    {                                
        word_t val = ((((word_t)high)<<8)|low) + 1;
        high = (val>>8);
        low = (val&0xFF);
        return val;
    }
	//##ModelId=3A3D099B03C1
    word_t operator++()   //++Word
    {                                
        word_t val = ((((word_t)high)<<8)|low) + 1;
        high = (val>>8);
        low = (val&0xFF);
        return val;
    }
};

#endif //!defined(WORDREGISTER_H)
