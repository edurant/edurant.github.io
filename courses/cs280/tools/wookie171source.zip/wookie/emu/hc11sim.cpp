#include "stdafx.h"
#include "hc11sim.h"

//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::HC11Sim()
//
// Author: Kalle Anderson & Jason Buttron
//
// Purpose: Contructor
//          
// Input Parameters: None
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

HC11Sim::HC11Sim(void)
{
    cfg = None;        
}

//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::~HC11Sim()
//
// Author: Kalle Anderson & Jason Buttron
//
// Purpose: Destructor, cleans up the external ram object
//          
// Input Parameters: None
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

HC11Sim::~HC11Sim(void)
{
    if(cfg != None)
    {
        hc11.memory.RemoveMemoryObject(expanded_ram);
        delete expanded_ram;    
    }
		cfg = None;
}

//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::Config()
//
// Author: Kalle Anderson & Jason Buttron
//
// Purpose: Adds memory and stuff, to emulate various configurtations, like
//          the briefcase or the rugwarior board. Later on it could add
//          devices to the simulation too, like the 7segment display in 
//          the briefcase, or "motors" on the rugwarrior.
//          
// Input Parameters: The mode
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

void HC11Sim::Config(HC11SimConfig ncfg)
{
    int i;

    if(cfg != None)
    {
        hc11.memory.RemoveMemoryObject(expanded_ram);
        delete expanded_ram;
    }
    
    cfg = ncfg;
    
    switch(cfg)
    {
        case BriefCase:

            //hc11.mode = SPECIAL_TEST;            
            hc11.mode = EXPANDED;            
            expanded_ram = new RAM(0xC000, 0x3FFF);                
            hc11.memory.AddMemoryObject(expanded_ram);                        
		    
		    // Here we write the pseudo-vectors to extended memory
		    // so programs can use interrupts
		    SetupPsuedoVectors(0xFFC0);           
            break;

        case RugWarriorBootstrap:

            hc11.mode = BOOTSTRAP;            
            expanded_ram = new RAM(0x8000, 0x7FFF);                
            hc11.memory.AddMemoryObject(expanded_ram);                        

			// We don't worry about the pseudo-vectors here
			// because the are in the Boot ROM

            // disable these cause no port replacement unit
            for(i=0;i<8;i++)
                hc11.regfile.PORTB.SetMode(i, Pin::AUTO);            
            for(i=0;i<8;i++)
                hc11.regfile.PORTC.SetMode(i, Pin::AUTO);            
            break;

        case RugWarriorExpanded:        

            hc11.mode = EXPANDED;                                   
            expanded_ram = new RAM(0x8000, 0x7FFF);                
            hc11.memory.AddMemoryObject(expanded_ram);                        
           
            // disable these cause no port replacement unit
            for(i=0;i<8;i++)
                hc11.regfile.PORTB.SetMode(i, Pin::AUTO);            
            for(i=0;i<8;i++)
                hc11.regfile.PORTC.SetMode(i, Pin::AUTO);            
    }    
}


//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::SetStartAddress()
//
// Author: Kalle Anderson & Jason Buttron
//
// Purpose: This will stick the address into the reset vector location
//          of the hc11.
//
// Input Parameters: The address
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

void HC11Sim::SetStartAddress(Word address)
{
    switch(cfg)
    {
        case BriefCase:
        case RugWarriorExpanded:        
            hc11.memory.Write(0xFFFE, address.high());
            hc11.memory.Write(0xFFFF, address.low());
            break;
        case RugWarriorBootstrap:
            hc11.memory.Write(0xBFFE, address.high());
            hc11.memory.Write(0xBFFF, address.low());
            break;
    }
}


//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::SetupPsuedoVectors()
//
// Author: Kalle Anderson & Jason Buttron
//
// Purpose: This sets up the pseudo vectors, which is normally
//          done by the bootloader program we think.
//          
// Input Parameters: The address of the real interrupt vectors.
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

void HC11Sim::SetupPsuedoVectors(word_t vector_base_addr)
{
	hc11.memory.Write((vector_base_addr + ResetVector),0x00);
	hc11.memory.Write((vector_base_addr + ResetVector+1),0x00);
	
	hc11.memory.Write((vector_base_addr + SWIVector),0x00);
	hc11.memory.Write((vector_base_addr + SWIVector+1),0xF4);
	
	hc11.memory.Write((vector_base_addr + XIRQVector),0x00);
	hc11.memory.Write((vector_base_addr + XIRQVector+1),0xF1);
	
	hc11.memory.Write((vector_base_addr + IRQVector),0x00);
	hc11.memory.Write((vector_base_addr + IRQVector+1),0xEE);
	
	hc11.memory.Write((vector_base_addr + RTIVector),0x00);
	hc11.memory.Write((vector_base_addr + RTIVector+1),0xEB);

	hc11.memory.Write((vector_base_addr + IC1Vector),0x00);
	hc11.memory.Write((vector_base_addr + IC1Vector+1),0xE8);

	hc11.memory.Write((vector_base_addr + IC2Vector),0x00);
	hc11.memory.Write((vector_base_addr + IC2Vector+1),0xE5);

	hc11.memory.Write((vector_base_addr + IC3Vector),0x00);
	hc11.memory.Write((vector_base_addr + IC3Vector+1),0xE2);

	hc11.memory.Write((vector_base_addr + OC1Vector),0x00);
	hc11.memory.Write((vector_base_addr + OC1Vector+1),0xDF);

	hc11.memory.Write((vector_base_addr + OC2Vector),0x00);
	hc11.memory.Write((vector_base_addr + OC2Vector+1),0xDC);

	hc11.memory.Write((vector_base_addr + OC3Vector),0x00);
	hc11.memory.Write((vector_base_addr + OC3Vector+1),0xD9);

	hc11.memory.Write((vector_base_addr + OC4Vector),0x00);
	hc11.memory.Write((vector_base_addr + OC4Vector+1),0xD6);

	hc11.memory.Write((vector_base_addr + I4O5Vector),0x00);
	hc11.memory.Write((vector_base_addr + I4O5Vector+1),0xD3);

	hc11.memory.Write((vector_base_addr + TOVector),0x00);
	hc11.memory.Write((vector_base_addr + TOVector+1),0xD0);

	hc11.memory.Write((vector_base_addr + PAOVVector),0x00);
	hc11.memory.Write((vector_base_addr + PAOVVector+1),0xCD);

	hc11.memory.Write((vector_base_addr + PAIVector),0x00);
	hc11.memory.Write((vector_base_addr + PAIVector+1),0xCA);
}



//////////////////////////////////////////////////////////////////////////////
// Function Name: HC11Sim::LoadS19File()
//
// Author: Kalle Anderson (based on some example code I found on the internet,
//                         but I forgot where it came from)
//
// Purpose: This loads up a s19 into memory.
//          
// Input Parameters: The name of the s19 file.
//
// Return Value: None
/////////////////////////////////////////////////////////////////////////////

bool HC11Sim::LoadS19File(const char *fname)
{
    char line[256];
    int bc, val, cksm, fcksm, i;
    long addr;
    bool retval = true;

    FILE *fin;

    // Open .S19 file for reading
    fin = fopen(fname,"r");

    if(!fin)
    {
        log("couldn't open s19 file!\n",0);
        return false;
    }

    while (fgets(line, 256, fin) != NULL) 
    {                
         if (line[0] == 'S')
		 { 
            switch(line[1])
            {
                case '1':
                    // Get the byte count
					sscanf(&line[2],"%2x",&bc);    
					// Get the starting address
                    sscanf(&line[4],"%4x",&addr);  
                    // Calculate checksum
                    cksm = bc + (addr & 0xFF) + ((addr >> 8) & 0xFF);

                    for (i=0; i<(bc-3); i++) 
                    {    
													// Get a data byte
                        sscanf(&line[i*2 + 8], "%2x", &val);
													// Write data byte to HC11 memory
                        hc11.memory.Write(static_cast<word_t>(addr+i), val); // EAD 20050101: Can addr be of word_t?
													// Add to checksum
                        cksm += val;
                    }
                    // Get the checksum from the S19 record
                    sscanf(&line[(bc-3)*2 + 8], "%2x", &fcksm);
                    cksm = ~cksm & 0xFF;

			        //Compare our checksum with the S19 checksum
                    if (cksm != fcksm)
                    {
						log("s19 file checksum failed!\n",0);
						retval = false;
					}
                    break;                                           
                case '9':
                    break;                       
			 } // end switch
		 }  // end if
         else log("unknown line type in s19 file!\n",0);
    }        
    fclose(fin);

	return retval;
}
