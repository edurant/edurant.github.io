#include "stdafx.h"
#include "PortConnection.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: To be used for the tesing of the PortConnection's functionality.
//          When used correctly, this function is overriden by a derived class
//          so this function should never be called.
//
// Input Parameters: data - The data to write to the PortConnection object.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortConnection::Write(byte_t data)
{

printf("Port Updated: %d %d %d %d %d %d %d %d\n",
					(data&0x80) ? 1 : 0,
					(data&0x40) ? 1 : 0,
					(data&0x20) ? 1 : 0,
					(data&0x10) ? 1 : 0,
					(data&0x8) ? 1 : 0,
					(data&0x4) ? 1 : 0,
					(data&0x2) ? 1 : 0,
					(data&0x1) ? 1 : 0);


}