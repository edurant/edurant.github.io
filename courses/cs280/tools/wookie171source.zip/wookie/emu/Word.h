#if !defined(WORD_H)
#define WORD_H

#include "basetypes.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: Word
//
//  Author: Kalle Anderson
//
//  Purpose: Allows access to the bits and bytes of a word. (see Byte class)
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved struct Word into its own header
//                              Changed struct Word to class (made public)
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D09AC00E9
class Word
{
public:
	//##ModelId=3A3D09AC0113
    word_t word;

	//##ModelId=3A3D09AC01AC
    byte_t low(void){return word&0x00FF;};
	//##ModelId=3A3D09AC01A8
    byte_t high(void){return (word&0xFF00)>>8;};
	//##ModelId=3A3D09AC01B2
    void low(byte_t value){word = (word&0xFF00)|value;};
	//##ModelId=3A3D09AC01AA
    void high(byte_t value){word = (word&0x00FF)|(value<<8);};

	//##ModelId=3A3D09AC019F
    bit_t bit0(void){return (word&0x1);};
	//##ModelId=3A3D09AC0196
    bit_t bit1(void){return (word&0x2)>>1;};
	//##ModelId=3A3D09AC018D
    bit_t bit2(void){return (word&0x4)>>2;};
	//##ModelId=3A3D09AC0189
    bit_t bit3(void){return (word&0x8)>>3;};
	//##ModelId=3A3D09AC0181
    bit_t bit4(void){return (word&0x10)>>4;};
	//##ModelId=3A3D09AC0178
    bit_t bit5(void){return (word&0x20)>>5;};
	//##ModelId=3A3D09AC016F
    bit_t bit6(void){return (word&0x40)>>6;};
	//##ModelId=3A3D09AC016B
    bit_t bit7(void){return (word&0x80)>>7;};
	//##ModelId=3A3D09AC0163
    bit_t bit8(void){return (word&0x100)>>8;};
	//##ModelId=3A3D09AC015A
    bit_t bit9(void){return (word&0x200)>>9;};
	//##ModelId=3A3D09AC0151
    bit_t bit10(void){return (word&0x400)>>10;};
	//##ModelId=3A3D09AC014D
    bit_t bit11(void){return (word&0x800)>>11;};
	//##ModelId=3A3D09AC0144
    bit_t bit12(void){return (word&0x1000)>>12;};
	//##ModelId=3A3D09AC013C
    bit_t bit13(void){return (word&0x2000)>>13;};
	//##ModelId=3A3D09AC0132
    bit_t bit14(void){return (word&0x4000)>>14;};
	//##ModelId=3A3D09AC012A
    bit_t bit15(void){return (word&0x8000)>>15;};

	//##ModelId=3A3D09AC01A1
    void bit0(bit_t value){word = (word & 0xfffe) | (word_t)value;};
	//##ModelId=3A3D09AC019D
    void bit1(bit_t value){word = (word & 0xfffd) | (word_t)value<<1;};
	//##ModelId=3A3D09AC0194
    void bit2(bit_t value){word = (word & 0xfffb) | (word_t)value<<2;};
	//##ModelId=3A3D09AC018B
    void bit3(bit_t value){word = (word & 0xfff7) | (word_t)value<<3;};
	//##ModelId=3A3D09AC0183
    void bit4(bit_t value){word = (word & 0xffef) | (word_t)value<<4;};
	//##ModelId=3A3D09AC017F
    void bit5(bit_t value){word = (word & 0xffdf) | (word_t)value<<5;};
	//##ModelId=3A3D09AC0176
    void bit6(bit_t value){word = (word & 0xffbf) | (word_t)value<<6;};
	//##ModelId=3A3D09AC016D
    void bit7(bit_t value){word = (word & 0xff7f) | (word_t)value<<7;};
	//##ModelId=3A3D09AC0165
    void bit8(bit_t value){word = (word & 0xfeff) | (word_t)value<<8;};
	//##ModelId=3A3D09AC0161
    void bit9(bit_t value){word = (word & 0xfdff) | (word_t)value<<9;};
	//##ModelId=3A3D09AC0158
    void bit10(bit_t value){word = (word & 0xfbff) | (word_t)value<<10;};
	//##ModelId=3A3D09AC014F
    void bit11(bit_t value){word = (word & 0xf7ff) | (word_t)value<<11;};
	//##ModelId=3A3D09AC0146
    void bit12(bit_t value){word = (word & 0xefff) | (word_t)value<<12;};
	//##ModelId=3A3D09AC013E
    void bit13(bit_t value){word = (word & 0xdfff) | (word_t)value<<13;};
	//##ModelId=3A3D09AC013A
    void bit14(bit_t value){word = (word & 0xbfff) | (word_t)value<<14;};
	//##ModelId=3A3D09AC0130
    void bit15(bit_t value){word = (word & 0x7fff) | (word_t)value<<15;};


	//##ModelId=3A3D09AC0129
    operator word_t(){return word;}; 
	//##ModelId=3A3D09AC0127
    Word operator=(word_t data){word = data;return *this;};    

	//##ModelId=3A3D09AC011E
    Word(void){};
	//##ModelId=3A3D09AC0125
    Word(word_t data){word = data;};
	//##ModelId=3A3D09AC011C
    Word &operator++(int){word++;return *this;};
	//##ModelId=3A3D09AC0116
    Word &operator--(int){word--;return *this;};
};

#endif //!defined(WORD_H)
