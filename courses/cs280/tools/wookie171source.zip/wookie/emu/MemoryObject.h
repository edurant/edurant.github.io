#if !defined(MEMORYOBJECT_H)
#define MEMORYOBJECT_H

#include "basetypes.h"
#include "MemoryRegister.h"
#include "ByteRegister.h"
#include "WordRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: MemoryObject
//
//  Author: Kalle Anderson
//
//  Purpose: The base class for all the MemoryObjects. A memory object represents
//           a type of memory, like RAM or ROM. Each memory object is assigned
//           a certain range of memory.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class MemoryObject into its own header
//  12/17/2000  BPF and ILK     Changed #include "register.h" to 
//									include MemoryRegister.h, ByteRegister.h,
//									and WordRegister.h
//          
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D09AF01AB
class MemoryObject
{
 protected:
	//##ModelId=3A3D09AF01DF
    word_t size;
	//##ModelId=3A3D09AF01D5
	word_t base_addr;
	//##ModelId=3A3D09AF01CB
	word_t top_addr;				
 public:
	//##ModelId=3A3D09AF01B7
    bit_t enable;

	//##ModelId=3A3D09AF0206
    MemoryObject();
	//##ModelId=3A3D09AF01FF
    virtual ~MemoryObject(){;};
	//##ModelId=3A3D09AF01FC
	virtual byte_t Read(word_t address)=0;
	//##ModelId=3A3D09AF01F2
	virtual void Write(word_t address, byte_t data)=0;	
	//##ModelId=3A3D09AF01E9
    bool Contains(word_t addr){return((addr>=base_addr)&&(addr<=top_addr));};
	//##ModelId=3A3D09AF01E7
    void Move(word_t new_base);    
};

#endif //!defined(MEMORYOBJECT_H)
