////////////////////////////////////////////////////////////////////////////////
// File Name:       oc1m_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:36:35
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(OC1M_C_H)
#define OC1M_C_H

#include "ByteRegister.h"
#include "PortRegister.h"

//##ModelId=3A3D099D00B5
class OC1M_C : public ByteRegister
{
public:
	//##ModelId=3A3D099D00D8
    void Write(byte_t data);
	//##ModelId=3A3D099D00D5
    PortRegister* portA;
	//##ModelId=3A3D099D00CB
    ByteRegister* pactl;
	//##ModelId=3A3D099D00C1
    ByteRegister* tctl1;
};

#endif //!defined(OC1M_C_H)
