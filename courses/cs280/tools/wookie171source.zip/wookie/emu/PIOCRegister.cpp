////////////////////////////////////////////////////////////////////////////////
// File Name:       PIOCRegister.cpp
// Description:     This file defines all PIOCRegister member functions.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "PIOCRegister.h"


////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~PIOCRegister
// Scope:           PIOCRegister
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PIOCRegister::~PIOCRegister()
{
	//Nothing to do
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   PIOCRegister
// Scope:           PIOCRegister
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the ID for the PIOCRegister.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PIOCRegister::PIOCRegister()
{
	//Set the ID
    ID = "PIOC";
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   PIOCRegister
// Scope:           PIOCRegister
// Return Value:    <none>
// Usage:           Copy Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the ByteRegister copy constructor.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const PIOCRegi� rhs             I   object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PIOCRegister::PIOCRegister(const PIOCRegister& rhs)
: ByteRegister(rhs)
{
	//Nothing to do
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           PIOCRegister
// Usage:           Copy assignment operator.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Assigns all members from rhs to this
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const PIOCRegi� rhs             I   object to assign
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  PIOCRegister&   Returns a reference to the newly modifed object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PIOCRegister& PIOCRegister::operator=(const PIOCRegister& rhs)
{   
    //Check for self assignment
    if(this != &rhs)
    {
        ByteRegister::operator=(rhs);
    }
    
	return (*this);
}


