////////////////////////////////////////////////////////////////////////////////
// File Name:       tctl1_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:45:31
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "tctl1_c.h"

/////////////////////////////////////////////////////////////////
// TCTL1 function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: Writes to TCTL1 and sets modes of PortA pins as necessary
//
// Input Parameters: val - byte to be written to TCTL1 register.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void TCTL1_C::Write(byte_t val)
{
	byte = val;

	// Check if any of the output compares are setup to change pins
	// If the output compares are enabled, set the pins's modes accordingly

	// OL2, OM2
	if (bit7() || bit6())
		portA->SetMode(6,Pin::AUTO);
	else
		portA->SetMode(6,Pin::OUTPUT);

	// OL3, OM3
	if (bit5() || bit4())
		portA->SetMode(5,Pin::AUTO);
	else 
		portA->SetMode(5,Pin::OUTPUT);

	// OL4, OM4
	if (bit3() || bit2())
		portA->SetMode(4,Pin::AUTO);
	else
		portA->SetMode(4,Pin::OUTPUT);

	// OL5, OM5
	if (bit1() || bit0())
		portA->SetMode(3,Pin::AUTO);
	else
		portA->SetMode(3,Pin::OUTPUT);
}

