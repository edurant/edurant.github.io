////////////////////////////////////////////////////////////////////////////////
// File Name:       spcr_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:37:31
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(SPCR_C_H)
#define SPCR_C_H

#include "ByteRegister.h"
#include "DDRegister.h"
#include "PortRegister.h"

//##ModelId=3A3D099B036F
class SPCR_C : public ByteRegister
{
public:
	//##ModelId=3A3D099B0388
    void Write(byte_t data);          
	//##ModelId=3A3D099B0385
    DDRegister* ddrd;
	//##ModelId=3A3D099B037B
    PortRegister* portD;
};

#endif //!defined(SPCR_C_H)
