#include "stdafx.h"
#include "PortARegister.h"
#include "HC11.h"


/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////



PortARegister::PortARegister()
{
	// Make Port A IC pins as inputs
	SetMode(0,Pin::INPUT);
	SetMode(1,Pin::INPUT);
	SetMode(2,Pin::INPUT);    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: PinInput
//
// Author: Kalle Anderson
//
// Purpose: To input a level to a pin of the Port A register and see if an
//          input compare or pulse accumulator occurred.  The level of the
//          pin will only be changed if the pin's direction mode is INPUT.
//          The PortConnection will be updated if one is attached.
//
// Input Parameters:  PinNo - The pin number (0-7).
//                    value - The new level of the pin.
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortARegister::PinInput(int PinNo, bit_t value)
{
  // Input just one pin
	assert((PinNo >= 0) && (PinNo <= 7));

  
	bit_t previous_level = 0;
	// Edge mode determines what edges the IC's are sensitive to
	byte_t edge_mode = 0;

	// Edge type determines what edge (if any) has occurred
	byte_t edge_type = 0;

	
	// Edge configurations on EDGx
	//	EDGxA				EDGxB
	//		0						0					ICx's disabled
	//		0						1					Detect rising edges
	//		1						0					Detect falling edges
	//		1						1					Detect any edge


  switch(PinNo)
  {
      case 0:	// IC3
					// If the IC is enabled
          if (edge_mode = hc11->regfile.EDG3())
					{
						// If an edge occurred, a 0x3 does not represent an edge
						if ((edge_type = (Read(PinNo)<<1) | (value)) && (edge_type != 0x3))
						{
							// If the edge mode and type are equal, the right edge occurred (except 0x3)
							if ((edge_mode == edge_type) || (edge_mode == 0x3))
							{
								// Set flag
								hc11->regfile.IC3F(1);

								// Generate an interrupt (maybe)  ????

								// Set the TICx register
								hc11->regfile.TIC3.Write(hc11->regfile.TCNT.Read());
//printf("Input compare %d occurred at %d\n",3-PinNo,hc11->regfile.TCNT.Read());
//printf("TIC%d now holds %d\n",3-PinNo,hc11->regfile.TIC3.Read());
							}
						}		
					}

          pins[0].Input(value);
          break;

      case 1:	// IC2
					
					// If the IC is enabled
          if (edge_mode = hc11->regfile.EDG2())
					{
						// If an edge occurred, a 0x3 does not represent an edge
						if ((edge_type = (Read(PinNo)<<1) | (value)) && (edge_type != 0x3))
						{
							// If the edge mode and type are equal, the right edge occurred (except 0x3)
							if ((edge_mode == edge_type) || (edge_mode == 0x3))
							{
								// Set flag
								hc11->regfile.IC2F(1);

								// Generate an interrupt (maybe)  ????

								// Set the TICx register
								hc11->regfile.TIC2.Write(hc11->regfile.TCNT.Read());
//printf("Input compare %d occurred at %d\n",3-PinNo,hc11->regfile.TCNT.Read());
//printf("TIC%d now holds %d\n",3-PinNo,hc11->regfile.TIC2.Read());
							}
						}		
					}
          pins[1].Input(value);
          break;

      case 2:   // IC1
          
					// If the IC is enabled
          if (edge_mode = hc11->regfile.EDG1())
					{
						// If an edge occurred, a 0x3 does not represent an edge
						if ((edge_type = (Read(PinNo)<<1) | (value)) && (edge_type != 0x3))
						{
							// If the edge mode and type are equal, the right edge occurred (except 0x3)
							if ((edge_mode == edge_type) || (edge_mode == 0x3))
							{
								// Set flag
								hc11->regfile.IC1F(1);

								// Generate an interrupt (maybe)  ????

								// Set the TICx register
								hc11->regfile.TIC1.Write(hc11->regfile.TCNT.Read());
//printf("Input compare %d occurred at %d\n",3-PinNo,hc11->regfile.TCNT.Read());
//printf("TIC%d now holds %d\n",3-PinNo,hc11->regfile.TIC1.Read());
							}
						}		
					}  
				
					pins[2].Input(value);
          break;

      case 7:
          // PAI
          previous_level = Read(PinNo);            
          pins[PinNo].Input(value);

          //
          if((hc11->regfile.PAEN() && !hc11->regfile.PAMOD()) &&
             (previous_level != Read(PinNo)) &&
             (hc11->regfile.PEDGE() != previous_level))
          {                                   
              hc11->regfile.PAIF(1);                                 
              if(++hc11->regfile.PACNT == 0)
              {
                  hc11->regfile.PAOVF(1);  
              }
          }
          break;
  }
	

	if (connect != NULL)
		connect->Write(Read());
}
