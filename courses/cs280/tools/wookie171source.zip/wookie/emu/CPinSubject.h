////////////////////////////////////////////////////////////////////////////////
// File Name:       CPinSubject.h
// Description:     This is a real subject.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:55:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CPINSUBJECT_3A6217AA0145_INCLUDED
#define _INC_CPINSUBJECT_3A6217AA0145_INCLUDED

#include "CMemorySubject.h"

class CPinSubject 
: public CMemorySubject
{
public:
	virtual ~CPinSubject();

	CPinSubject();

	CPinSubject(const CPinSubject& orig);

	CPinSubject& operator=(const CPinSubject& rhs);
};

#endif /* _INC_CPINSUBJECT_3A6217AA0145_INCLUDED */

