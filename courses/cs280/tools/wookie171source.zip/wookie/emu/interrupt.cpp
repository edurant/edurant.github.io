#include "stdafx.h"
#include "hc11.h"
#include "STRAPin.h"

interrupt_service_t HC11::psel_table[N_IBIT_INTERRUPTS] = { HC11::ServiceTO,
                                                            HC11::ServicePAOV,
                                                            HC11::ServicePAI,
                                                            HC11::ServiceSPI,
                                                            HC11::ServiceSCI,
                                                            HC11::ServiceIRQ,
                                                            HC11::ServiceIRQIO,
                                                            HC11::ServiceRTI,
                                                            HC11::ServiceIC1,
                                                            HC11::ServiceIC2,
                                                            HC11::ServiceIC3,
                                                            HC11::ServiceOC1,
                                                            HC11::ServiceOC2,
                                                            HC11::ServiceOC3,
                                                            HC11::ServiceOC4,
                                                            HC11::ServiceI4O5};
                                                        

bool HC11::ServiceIRQ(HC11 *hc11)
{
        bool status = false;

        if(hc11->IRQInterrupt())            
        {
                if(hc11->regfile.IRQE())
                    hc11->irq_edge = 0;
                hc11->FetchVector(IRQVector);        
                status = true;
        }

        return(status);
};

bool HC11::ServiceIRQIO(HC11 *hc11)
{
        bool status = false;

        if(hc11->IRQInterrupt() ||           
           (hc11->regfile.STAF() && hc11->regfile.STAI()))           
        {
                if(hc11->regfile.IRQE())
                    hc11->irq_edge = 0;
                hc11->FetchVector(IRQVector);        
                status = true;
        }
        return(status);
};


bool HC11::ServiceRTI(HC11 *hc11)
{   
        bool status = false;

        if(hc11->regfile.RTII() && hc11->regfile.RTIF())        
        {                
                hc11->FetchVector(RTIVector);        
                status = true;
        }

        return(status);
};


bool HC11::ServiceIC1(HC11 *hc11)
{   
        bool status = false;

        if(hc11->regfile.IC1I() && hc11->regfile.IC1F())        
        {         
                hc11->FetchVector(IC1Vector);        
                status = true;
        }        

        return(status);
};


bool HC11::ServiceIC2(HC11 *hc11)
{   
        bool status = false;

        if(hc11->regfile.IC2I() && hc11->regfile.IC2F())        
        {                
                hc11->FetchVector(IC2Vector);        
                status = true;
        }        

        return(status);
};

bool HC11::ServiceIC3(HC11 *hc11)
{   
        bool status = false;

        if(hc11->regfile.IC3I() && hc11->regfile.IC3F())        
        {
                hc11->FetchVector(IC3Vector);        
                status = true;
        }        

        return(status);
};

bool HC11::ServiceOC1(HC11 *hc11)
{   
        bool status = false;

        if(hc11->regfile.OC1I() && hc11->regfile.OC1F())        
        {                
                hc11->FetchVector(OC1Vector);        
                status = true;
        }        

        return(status);
};

bool HC11::ServiceOC2(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.OC2I() && hc11->regfile.OC2F())        
        {         
                hc11->FetchVector(OC2Vector);        
                status = true;
        }        

        return(status);
};

bool HC11::ServiceOC3(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.OC3I() && hc11->regfile.OC3F())        
        {         
                hc11->FetchVector(OC3Vector);        
                status = true;
        }        
        return(status);
};

bool HC11::ServiceOC4(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.OC4I() && hc11->regfile.OC4F())        
        {         
                hc11->FetchVector(OC4Vector);        
                status = true;
        }        
        return(status);
};

bool HC11::ServiceI4O5(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.I4O5I() && hc11->regfile.I4O5F())        
        {         
                hc11->FetchVector(I4O5Vector);        
                status = true;
        }        
        return(status);
};


bool HC11::ServiceTO(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.TOI() && hc11->regfile.TOF())        
        {         
                hc11->FetchVector(TOVector);        
                status = true;
        }        
        return(status);
};

bool HC11::ServicePAOV(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.PAOVI() && hc11->regfile.PAOVF())        
        {         
                hc11->FetchVector(PAOVVector);        
                status = true;
        }        
        return(status);
};

bool HC11::ServicePAI(HC11 *hc11)
{   
        bool status = false;
        if(hc11->regfile.PAII() && hc11->regfile.PAIF())        
        {         
                hc11->FetchVector(PAIVector);        
                status = true;
        }        
        return(status);
};

bool HC11::ServiceSPI(HC11 *hc11)
{   
        bool status = false;
/*
        if()        
        {
                hc11->pending_interrupt &= ~SIGNAL_SPI;                
                hc11->FetchVector(PAIVector);        
                status = true;
        }        
*/
        return(status);
};

bool HC11::ServiceSCI(HC11 *hc11)
{   
        bool status = false;
/*
        if()        
        {
                hc11->FetchVector(PAIVector);        
                status = true;
        }        
*/
        return(status);
};


