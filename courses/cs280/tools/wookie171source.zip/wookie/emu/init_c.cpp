////////////////////////////////////////////////////////////////////////////////
// File Name:       init_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:48:08
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "init_c.h"
#include "RegisterMap.h"
#include "RAM.h"

/////////////////////////////////////////////////////////////////
// INIT function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke, etc.
//
// Purpose: Writes to the INIT register and 
//
// Input Parameters: val - byte to write to the register
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void INIT_C::Write(byte_t val)
{
	byte = val;
	
	byte_t temp = 0;

	// Check the movement of the register block
	if ((temp = byte<<4) != 0)
	{
		byte_t move_back = temp>>4;

		// The register block needs to be moved!
		RegisterMap* pregmap = (RegisterMap*)regmap;
		
		// Multiply the number by 4k to get the new starting address
		int new_base = move_back * 0x1000;

		// Change the memory object's addresses
		pregmap->Move(new_base);        
	}

	// Check the movement of the chip 256 byte RAM
	if ((temp = byte>>4) != 0)
	{
		// The on chip ram needs to be moved!
		RAM* pram = (RAM*)chip_ram;

		// Multiply the number by 4k to get the new starting address
		int new_base = temp * 0x1000;

		// Change the memory object's addresses
        pram->Move(new_base);
	}
}

