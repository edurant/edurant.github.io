///////////////////////////////////////////////////////////////
// File Name: basetypes.h
// Purpose: define some basic data types used by the simulator
///////////////////////////////////////////////////////////////

#ifndef BASETYPE_H 
#define BASETYPE_H

// boolean
// typedef unsigned char bool;
// 1 bit (bool is inefficient)
typedef unsigned char bit_t;
// 8 bits
typedef unsigned char byte_t;
// 16 bits
typedef unsigned short word_t;
// 32 bits
typedef unsigned long dword_t;

#endif //BASETYPE_H
