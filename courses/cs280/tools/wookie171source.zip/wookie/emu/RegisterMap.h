#if !defined(REGISTERMAP_H)
#define REGISTERMAP_H

#include "basetypes.h"
#include "MemoryRegister.h"
#include "ByteRegister.h"
#include "WordRegister.h"
#include "MemoryObject.h"
#include "regfile.h"


#define NUM_REGISTERS 64

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: RegisterMap
//
//  Author: Kalle Anderson
//
//  Purpose: The range of memory that maps all the HC11 ports/registers.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class RegisterMap into its own header
//  12/17/2000  BPF and ILK     Changed #include "register.h" to 
//									include MemoryRegister.h, ByteRegister.h,
//									and WordRegister.h
//          
/////////////////////////////////////////////////////////////////////////////

//##ModelId=3A3D099C01FE
class RegisterMap: public MemoryObject
{
 private:
	//##ModelId=3A3D099C0214
	MemoryRegister *regs[NUM_REGISTERS];
	//##ModelId=3A3D099C020A
	ByteRegister reserved;
 public:

	//##ModelId=3A3D099C0220
	RegisterMap(word_t base, class RegisterFile* regfile);
	//##ModelId=3A3D099C021F
	~RegisterMap();
	//##ModelId=3A3D099C021D
	byte_t Read(word_t address);	
	//##ModelId=3A3D099C0217
	void Write(word_t address, byte_t data);	
};

#endif //!defined(REGISTERMAP_H)
