#if !defined(CCRREG_H)
#define CCRREG_H

#include "Byte.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: CCRReg
//
//  Author: Kalle Anderson
//
//  Purpose: Class for the CCR.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved struct CCRReg into its own header
//                              Changed the CCRReg struct to a class
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099C0028
class CCRReg: public Byte
{
public:

	//##ModelId=3A3D099C005F
    CCRReg &operator=(byte_t data){byte = data;return *this;};
	//##ModelId=3A3D099C005C
    CCRReg(byte_t data){byte = data;};
	//##ModelId=3A3D099C005E
    CCRReg(){byte=0;};


	//##ModelId=3A3D099C0055
    bit_t C(void){return (bit0());};
	//##ModelId=3A3D099C0051
    bit_t V(void){return (bit1());};
	//##ModelId=3A3D099C004A
	bit_t Z(void){return (bit2());};
	//##ModelId=3A3D099C0046
	bit_t N(void){return (bit3());};
	//##ModelId=3A3D099C003E
	bit_t I(void){return (bit4());};
	//##ModelId=3A3D099C0037
	bit_t H(void){return (bit5());};
	//##ModelId=3A3D099C0033
    bit_t X(void){return (bit6());};
	//##ModelId=3A3D099C002A
    bit_t S(void){return (bit7());};
    
	//##ModelId=3A3D099C005A
    void C(bit_t val){bit0(val);};
	//##ModelId=3A3D099C0053
    void V(bit_t val){bit1(val);};
	//##ModelId=3A3D099C004C
    void Z(bit_t val){bit2(val);};
	//##ModelId=3A3D099C0048
    void N(bit_t val){bit3(val);};
	//##ModelId=3A3D099C0040
    void I(bit_t val){bit4(val);};
	//##ModelId=3A3D099C003C
    void H(bit_t val){bit5(val);};
	//##ModelId=3A3D099C0035
    void X(bit_t val){bit6(val);};
	//##ModelId=3A3D099C002C
    void S(bit_t val){bit7(val);};
};

#endif //!defined(CCRREG_H)
