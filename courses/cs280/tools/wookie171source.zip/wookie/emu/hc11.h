/////////////////////////////////////////////////////////////////////////////
// File Name: hc11.h
// Purpose:  Definition of the main Hc11 class
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved a SECOND public section to beginning
//                              of first public section
//  12/17/2000  ILK & BPF       Changed 'HC11Misc' to 'CCRReg.h'
//
/////////////////////////////////////////////////////////////////////////////

#ifndef HC11_H
#define HC11_H

#include "basetypes.h"
#include "regfile.h"
#include "Byte.h"
#include "Word.h"
#include "CCRReg.h"
#include "Pin.h"
#include "MemoryMap.h"
#include "RegisterMap.h"
#include "RAM.h"
#include "ROM.h"
#include "TimerSubSystem.h"
#include "HandshakeIOSubSystem.h"
#include "STRAPin.h"

/*
#include "basetypes.h"
#include "register.h"
#include "regfile.h"
#include "hc11io.h"
#include "memory.h"
#include "timer.h"
#include "iosystem.h"
#include "hc11misc.h"
*/

#define N_OPCODES 256


// some interrupt stuff

#define N_IBIT_INTERRUPTS 16

/*
#define SWIVector   (0xF4)
#define XIRQVector  (0xF4)
#define IRQVector   (0xF2)
#define RTIVector   (0xF0)
#define IC1Vector   (0xEE)
#define IC2Vector   (0xEC)
#define IC3Vector   (0xEA)
#define OC1Vector   (0xE8)
#define OC2Vector   (0xE6)
#define OC3Vector   (0xE4)
#define OC4Vector   (0xE2)
#define I4O5Vector  (0xE0)
#define TOVector    (0xDE)
#define PAOVVector  (0xDC)
#define PAIVector   (0xDA)
*/

//changed base vector from ff00 to ffco and b stuff.
#define ResetVector (0x3E)
#define IllegalVector (0x38)
#define SWIVector   (0x36)
#define XIRQVector  (0x34)
#define IRQVector   (0x32)
#define RTIVector   (0x30)
#define IC1Vector   (0x2E)
#define IC2Vector   (0x2C)
#define IC3Vector   (0x2A)
#define OC1Vector   (0x28)
#define OC2Vector   (0x26)
#define OC3Vector   (0x24)
#define OC4Vector   (0x22)
#define I4O5Vector  (0x20)
#define TOVector    (0x1E)
#define PAOVVector  (0x1C)
#define PAIVector   (0x1A)


// maybe make an opcode_t struct with include the cycle
typedef void (*opcode_t)(class HC11 *);
typedef bool (*interrupt_service_t)(class HC11 *);

//##ModelId=3A3D09AD0299
class HC11
{     
 // MC68HC11 CPU
 public:
	STRAPin& GetSTRA();

	const STRAPin& GetSTRAConst() const;


 // Interface Functions   
	//##ModelId=3A3D09AE01BE
    HC11();
	//##ModelId=3A3D09AE01B6
    ~HC11();

    // changing this will only take effect after a reset
	//##ModelId=3A3D09AE0039
    Mode mode;
        
	//##ModelId=3A3D09AE01B4
    void Reset(void);
	//##ModelId=3A3D09AE01AA
    void Step(void); 

    friend class PortARegister;


	// ACCD, ACC.A and ACC.D     
    // ACCD is (A<<8)|:B
	//##ModelId=3A3D09AE002D
	Byte	ACCA;	
	//##ModelId=3A3D09AE001B
    Byte	ACCB;		
	// The condition code register
	
	//##ModelId=3A3D09AE000F
    CCRReg CCR;	        

	// Index Registers
	//##ModelId=3A3D09AD03E5
	Word	IX;
	//##ModelId=3A3D09AD03D1
	Word	IY;
	// Program Counter
	//##ModelId=3A3D09AD03C7
	Word	PC;
	// Stack Pointer
	//##ModelId=3A3D09AD03BB
	Word	SP;
    
    // continuous counter
	//##ModelId=3A3D09AD03A7
	long int timer_count;
   	
  	
 // Misc Pins    
	//##ModelId=3A3D09AE018C
    void XIRQLevel(bit_t level);
	//##ModelId=3A3D09AE0178
    void IRQLevel(bit_t level);    
	//##ModelId=3A3D09AE01A0
    bit_t XIRQLevel(void);
	//##ModelId=3A3D09AE0182
    bit_t IRQLevel(void);
 
	//##ModelId=3A6B4A2E0322
    STRAPin STRA;   //handshake io stuff
	//##ModelId=3A3D09AD0393
    Pin STRB;

    // check if IRQ interrupt occured
	//##ModelId=3A3D09AE016E
    bool IRQInterrupt(void);
    
 // The Memory Map
	//##ModelId=3A3D09AD0381
    MemoryMap	memory;

 // Some memory map objects 
	//##ModelId=3A3D09AD0375
	RegisterMap* regmap;
	//##ModelId=3A3D09AD0363
	RAM* chip_ram;
	//##ModelId=3A3D09AD0359
	ROM* boot_rom;

 // The Memory Map
	//##ModelId=3A3D09AD034D
    RegisterFile    regfile;

 // Subsystem Stuff    
	//##ModelId=3A3D09AD033B
    TimerSubSystem	*timer_system;  
	//##ModelId=3A3D09AD0331
    HandshakeIOSubSystem *handshake_system;
    // ADSubSystem	*ad_system;
    // SPISubSystem	*spi_system;
    // SCISubSystem	*sci_system;    
    friend class TimerSubSystem;
        
 private:        
	//##ModelId=3A3D09AD0325
    bool xbit_cleared;
    // used in the STOP and WAIT opcodes    
	//##ModelId=3A3D09AD031C
    bool stopped;
	//##ModelId=3A3D09AD031B
    bool waiting;

	//##ModelId=3A3D09AD0313
    bit_t xirq_level;
	//##ModelId=3A3D09AD0309
    bit_t irq_level;
	//##ModelId=3A3D09AD02FD
    bit_t irq_edge;
    // this is the internal clocking function
	//##ModelId=3A3D09AE0164
    void _clock(void); 	
	//##ModelId=3A3D09AE015A
	void LoadROMBootLoader(word_t vector_base_addr);  //for bootstrap mode     
 protected:

 // Opcodes Stuff                               
    // the array of opcode function pointers    
	//##ModelId=3A3D09AD02EB
    static opcode_t opcode[N_OPCODES];
	//##ModelId=3A3D09AD02CB
    static opcode_t opIYcode[N_OPCODES];
    // executes the instruction pointed to by PC
	//##ModelId=3A3D09AE0147
    void Fetch();
    // this would set PC to address and grab the opcode
	//##ModelId=3A3D09AE0150
    void Fetch(word_t address);
        
    // opcode declarations
    #include "opcodes.h"
               
 // Interrupt Stuff   
    // priority resolution    
	//##ModelId=3A3D09AE013C
    void ResolveInterrupt(void);	
    // the base address of the interrupt vectors    
	//##ModelId=3A3D09AD02AF
    word_t  vector_base_addr;
	//##ModelId=3A3D09AE0132
    void FetchVector(word_t address);
    
    // checked at the end of the current opcode execution        
	//##ModelId=3A3D09AE0128
    inline bool InterruptPending(void)
    {            
        return(IRQInterrupt() || (regfile.TFLG1)&(regfile.TMSK1) || 
                                 (regfile.TFLG2)&(regfile.TMSK2));
        // also check for spi/sci later
    };

    
    // used for priority ordering (required for PSEL)        
	//##ModelId=3A3D09AD02A5
    static interrupt_service_t psel_table[N_IBIT_INTERRUPTS];    
    // these service the interrupt if it occured
	//##ModelId=3A3D09AE0114
    static bool ServiceTO(HC11 *hc11);
	//##ModelId=3A3D09AE010A
    static bool ServicePAOV(HC11 *hc11);
	//##ModelId=3A3D09AE0100
    static bool ServicePAI(HC11 *hc11);
	//##ModelId=3A3D09AE00EC
    static bool ServiceSPI(HC11 *hc11);
	//##ModelId=3A3D09AE00E2
    static bool ServiceSCI(HC11 *hc11);
	//##ModelId=3A3D09AE00CE
    static bool ServiceIRQ(HC11 *hc11);    
	//##ModelId=3A3D09AE00C4
    static bool ServiceIRQIO(HC11 *hc11);    
	//##ModelId=3A3D09AE00BA
    static bool ServiceRTI(HC11 *hc11);
	//##ModelId=3A3D09AE00A6
    static bool ServiceIC1(HC11 *hc11);
	//##ModelId=3A3D09AE009C
    static bool ServiceIC2(HC11 *hc11);
	//##ModelId=3A3D09AE0092
    static bool ServiceIC3(HC11 *hc11);
	//##ModelId=3A3D09AE007E
    static bool ServiceOC1(HC11 *hc11);
	//##ModelId=3A3D09AE0069
    static bool ServiceOC2(HC11 *hc11);
	//##ModelId=3A3D09AE005F
    static bool ServiceOC3(HC11 *hc11);
	//##ModelId=3A3D09AE004B
    static bool ServiceOC4(HC11 *hc11);
	//##ModelId=3A3D09AE0041
    static bool ServiceI4O5(HC11 *hc11);
};

#endif // HC11_H

