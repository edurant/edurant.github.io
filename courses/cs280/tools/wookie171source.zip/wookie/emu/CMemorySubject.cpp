////////////////////////////////////////////////////////////////////////////////
// File Name:       CMemorySubject.cpp
// Description:     The base subject class in the memory observer pattern.
//
// Author:          Ian L Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CMemoryObserver.h"
#include "CMemorySubject.h"

////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~CMemorySubject
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemorySubject::~CMemorySubject()
{
    //Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CMemorySubject
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           No-Argument constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the ID and type for the CMemorySubject.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemorySubject::CMemorySubject()
{
    //This is not a valid type this value should
    //be overwritten in derived classes
	type = INVALID_TYPE;

    //This argument should also be overwritten
    //in derived classes
    ID = "UNSPECIFIED";
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CMemorySubject
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           Copy constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Copies the ID, type, and observers set
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CMemoryS� orig            I   the object to copy.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemorySubject::CMemorySubject(const CMemorySubject& orig)
{
    ID = orig.ID;
    type = orig.type;
    m_setObservers = orig.m_setObservers;
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Attach
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           Call this function to attach a new observer to this subject.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function adds the observer to the set of observers
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CMemoryObserve� newObserver     I/O the observer to attach to
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CMemorySubject::Attach(CMemoryObserver& newObserver)
{
	m_setObservers.insert(&newObserver);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Detach
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           Call this function to detach an observer from this subject
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function removes the observer to the set of observers
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CMemoryObserve� removeSubject   I/O the observer to remove from the set
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CMemorySubject::Detach(CMemoryObserver& removeSubject)
{
	m_setObservers.erase(&removeSubject);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Notify
// Scope:           CMemorySubject
// Return Value:    <none>
// Usage:           Call this function to notify attached observers that a
//                  change was made.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function notifies observers in the set that a change
//                  occurred.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  enOperation     operation       I   the type of operation that occurred
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CMemorySubject::Notify(enOperation operation)
{
    std::set<CMemoryObserver*>::iterator currentObs = m_setObservers.begin();

    for(; currentObs != m_setObservers.end(); ++currentObs)
    {
        (*currentObs)->Update((*this),operation);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           CMemorySubject
// Usage:           Copy assignment operator.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This assigns the useful data to the lhs.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CMemoryS� rhs             I   the object to be copied
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  CMemorySubject& the newly copied object
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemorySubject& CMemorySubject::operator=(const CMemorySubject& rhs)
{
	//Check for self assignment
    if(this != &rhs)
    {
        ID = rhs.ID;
        type = rhs.type;
        m_setObservers = rhs.m_setObservers;
    }
    	
	return (*this);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   GetID (const)
// Scope:           CMemorySubject
// Return Value:    const std::string&
// Usage:           This function returns the ID
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Gets the ID for the CMemorySubject.
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  const std::str� the ID
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
const std::string& CMemorySubject::GetID() const
{
    return(ID);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   get_type (const)
// Scope:           CMemorySubject
// Usage:           This function returns the type
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Gets the type for the CMemorySubject.
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  SubjectType     the type
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 14:18:22
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
SubjectType CMemorySubject::get_type () const
{
    return(type);
}