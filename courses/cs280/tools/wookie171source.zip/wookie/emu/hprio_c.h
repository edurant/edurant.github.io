////////////////////////////////////////////////////////////////////////////////
// File Name:       hprio_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:37:03
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(HPRIO_C_H)
#define HPRIO_C_H

#include "ByteRegister.h"

//##ModelId=3A3D09AE0308
class HPRIO_C : public ByteRegister
{
public:
	//##ModelId=3A3D09AE030A
    void Write(byte_t data);
    //  word_t* pvector;
};

#endif //!defined(HPRIO_C_H)
