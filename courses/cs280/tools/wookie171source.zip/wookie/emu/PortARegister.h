#if !defined(PORTAREGISTER_H)
#define PORTAREGISTER_H

#include "basetypes.h"
#include "PortRegister.h"
class HC11;

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: PortARegister
//
//  Author: Kalle Anderson
//
//  Purpose: The override of a PortRegister so special events may happen
//           when Port A is changed.  This class is mainly used to capture
//           inputs on the pins.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class PortARegister into its own header
//                              Removed the keyword 'class' from before HC11
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099D030E
class PortARegister: public PortRegister
{
 private:
	//##ModelId=3A3D099D031A
    HC11 *hc11;
 public:	
	//##ModelId=3A3D099D0325
    PortARegister();
	//##ModelId=3A3D099D0323
    void SetHC11(HC11 *mcu){hc11 = mcu;};
	//##ModelId=3A3D099D031D
    void PinInput(int PinNo,bit_t value);
	friend class DDRegister;
};


#endif //!defined(PORTAREGISTER_H)
