#include "stdafx.h"
#include "hc11.h"
#include "CCRReg.h"

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11 :: HC11
//
// Author: Kalle Anderson
//
// Purpose: Constructor for the HC11 class. It adds in the chip memory that is 
//          always there. It would also be where the subsystem classes are 
//          created. (i.e. timer_system)
//
/////////////////////////////////////////////////////////////////////////////
       
HC11::HC11()
{
 // initialize the various systems
    timer_system = new TimerSubSystem(this);    
    handshake_system = new HandshakeIOSubSystem(this);


    // Add these memory objects as the default
    chip_ram = new RAM(0,512);
    regmap = new RegisterMap(0x1000,&regfile);    
    RAM* vector_ram = new RAM(0xFF00,0xFF);

    // Make a boot rom memory object just in case we are in bootstrap mode
    boot_rom = new ROM(0xbf00,0xff);
    // Initially disable the ROM until we know we are in bootstrap
    boot_rom->enable = 0;

    // Transfer the important memory objects over
    regfile.INIT.regmap = (void*)regmap;
    regfile.INIT.chip_ram = (void*)chip_ram;
    //regfile.pvector_base_addr = &vector_base_addr;		

    // These objects are loaded by their priority!
    memory.AddMemoryObject(regmap);    
    memory.AddMemoryObject(vector_ram);
    memory.AddMemoryObject(chip_ram);
    memory.AddMemoryObject(boot_rom);
            
    // For the pin triggered interrupts
    xirq_level=1;
    irq_level=1;
    irq_edge=0;

  	regfile.PORTA.SetHC11(this);
    regfile.PORTB.SetHC11(this);

    mode=SPECIAL_TEST;
    Reset();
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11 :: ~HC11
//
// Author: Kalle Anderson
//
// Purpose: Destructor - deletes the timer_system. Note, that the allocated
//                       MemoryObjects, are cleaned up when the MemoryMap
//                       destructs.
//
/////////////////////////////////////////////////////////////////////////////
       
HC11::~HC11()
{
    delete timer_system;
    delete handshake_system;
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::Reset
//
// Author: 
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions:
//
/////////////////////////////////////////////////////////////////////////////

void HC11::Reset(void)
{	
	CCR.I(1);
	CCR.X(1);

	regfile.Reset(mode);   //reset regfile
	
	timer_count = 0;
    
    // just in case someone resets out of a wait
    stopped=false;
    waiting=false;

	if (mode == BOOTSTRAP)  //change vector base according to mode
	{
		// The DWOM bit enables the SCI to use PORTD
		regfile.DWOM(1);
		vector_base_addr = 0xbfc0;
	    boot_rom->enable = 1;

		// We now have ROM, so we need to make sure some stuff is there
		LoadROMBootLoader(vector_base_addr);	 
	}
	else if (mode == SPECIAL_TEST)
	{
		vector_base_addr = 0xbfc0;
	}
	else if(mode == EXPANDED || mode == SINGLE_CHIP)
	{
		vector_base_addr = 0xffc0;
	}
		
    FetchVector(ResetVector);
    xbit_cleared=false;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::_clock
//
// Author: Kalle Anderson
//
// Purpose: This gets called every e-clock cycle internally by the simulator.
//          NOTE - Later on it might contain a external call back that could
//                 be used for more accurate timing or something.
//
// Input Parameters: None
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::_clock()
{	 
    // do things that happen 
    timer_system->ClockSystem();
    timer_count++;
};


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::Fetch
//
// Author: Kalle Anderson
//
// Purpose: Grabs the opcode pointed too by the PC, and calls it. The PC gets
//          incremented before the opcode gets called. This takes one clock cycle.
//          
// Input Parameters: None
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::Fetch(void)
{       
    byte_t num;    
   
    _clock();  
		    
    num=memory[PC];
    PC++;

    opcode[num](this);
};



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::Fetch(address)
//
// Author: Kalle Anderson
//
// Purpose: Loads the PC with and address, and then calls Fetch()
//          
// Input Parameters: word_t address.
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::Fetch(word_t address)
{   
    Word addr;
    addr = address;

    _clock();
    PC.low(addr.low());
    _clock();
    PC.high(addr.high());    

    Fetch();
};


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::FetchVector
//
// Author: Kalle Anderson
//
// Purpose: Loads the PC with an address, but does NOT call the opcode. This
//          will be done in the next clock. The address is actually an offset
//          from the vector_base address. Should be called using the #defines
//          for the vectors in the hc11.h file.
//          
// Input Parameters: word_t address.
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::FetchVector(word_t address)
{   
    word_t vec;
   
    vec = address + vector_base_addr;	
    log("fetching vector 0x%X\n",(int)vec);
	
    _clock();
    PC.high(memory[vec]);
    _clock();
    PC.low(memory[vec+1]);    
};


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::Step
//
// Author: Kalle Anderson
//
// Purpose: This is the function that operates the simulator. It will step the
//          simulation through an entire opcode, or though interrupt resolution.
//          
// Input Parameters: None
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::Step(void)
{
    // check for XIRQ
    if (!(CCR.X() || XIRQLevel()))
    {          
        xbit_cleared = true;
        StackRegisters();                
                
        _clock();
        CCR.X(1);
                
        _clock();
        CCR.I(1);                   
                                
        FetchVector(XIRQVector);        
    } 
    // else check if there are any i bit interrupts pending
    else if(!CCR.I() && InterruptPending())        
    {   
        StackRegisters();        
        ResolveInterrupt();     
    }
    // otherwise grab the next opcode
    else Fetch();
};


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::ResolveInterrupt
//
// Author: Kalle Anderson
//
// Purpose: When an interrupt is detected in the HC11::Step routine, this
//          function is called to resolve it and load the PC with the
//          interrupt service routines address.
//                   
// Input Parameters: None
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void HC11::ResolveInterrupt(void)
{   
    // XIRQ is always highest priority, and can be serviced, even though it 
    // was not the cause of the inital interrupt that caused this function call
    if(!(CCR.X() || XIRQLevel())) 
    {                                
        xbit_cleared = true;

        _clock();
        CCR.X(1);
        CCR.I(1);

        FetchVector(XIRQVector);                      
    }
    else
    {
        CCR.I(1);
        // This if statement is organized by the priority of the interrupts.
        if(psel_table[regfile.PSEL()](this));
        else if(ServiceIRQIO(this));
        else if(ServiceRTI(this));
        else if(ServiceIC1(this));                    
        else if(ServiceIC2(this));                    
        else if(ServiceIC3(this));            
        else if(ServiceOC1(this));           
        else if(ServiceOC2(this));           
        else if(ServiceOC3(this));          
        else if(ServiceOC4(this));           
        else if(ServiceI4O5(this));
        else if(ServiceTO(this));
        else if(ServicePAOV(this));
        else if(ServicePAI(this));
        // else it was a spurious interrupt, so grab the IRQ vector.
        else FetchVector(IRQVector);        
    }        
};

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::LoadROMBootLoader
//
// Author: Paul Clarke/Jason Buttron
//
// Purpose: 
//          
//          
//                   
// Input Parameters: word_t vector_base_addr
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////


void HC11::LoadROMBootLoader(word_t vector_base_addr)
{
	boot_rom->Program((vector_base_addr + ResetVector),0x00);
	boot_rom->Program((vector_base_addr + ResetVector+1),0x00);
	
	boot_rom->Program((vector_base_addr + SWIVector),0x00);
	boot_rom->Program((vector_base_addr + SWIVector+1),0xF4);
	
	boot_rom->Program((vector_base_addr + XIRQVector),0x00);
	boot_rom->Program((vector_base_addr + XIRQVector),0xF1);
	
	boot_rom->Program((vector_base_addr + IRQVector),0x00);
	boot_rom->Program((vector_base_addr + IRQVector+1),0xEE);
	
	boot_rom->Program((vector_base_addr + RTIVector),0x00);
	boot_rom->Program((vector_base_addr + RTIVector+1),0xEB);

	boot_rom->Program((vector_base_addr + IC1Vector),0x00);
	boot_rom->Program((vector_base_addr + IC1Vector+1),0xE8);

	boot_rom->Program((vector_base_addr + IC2Vector),0x00);
	boot_rom->Program((vector_base_addr + IC2Vector+1),0xE5);

	boot_rom->Program((vector_base_addr + IC3Vector),0x00);
	boot_rom->Program((vector_base_addr + IC3Vector+1),0xE2);

	boot_rom->Program((vector_base_addr + OC1Vector),0x00);
	boot_rom->Program((vector_base_addr + OC1Vector+1),0xDF);

	boot_rom->Program((vector_base_addr + OC2Vector),0x00);
	boot_rom->Program((vector_base_addr + OC2Vector+1),0xDC);

	boot_rom->Program((vector_base_addr + OC3Vector),0x00);
	boot_rom->Program((vector_base_addr + OC3Vector+1),0xD9);

	boot_rom->Program((vector_base_addr + OC4Vector),0x00);
	boot_rom->Program((vector_base_addr + OC4Vector+1),0xD6);

	boot_rom->Program((vector_base_addr + I4O5Vector),0x00);
	boot_rom->Program((vector_base_addr + I4O5Vector+1),0xD3);

	boot_rom->Program((vector_base_addr + TOVector),0x00);
	boot_rom->Program((vector_base_addr + TOVector+1),0xD0);

	boot_rom->Program((vector_base_addr + PAOVVector),0x00);
	boot_rom->Program((vector_base_addr + PAOVVector+1),0xCD);

	boot_rom->Program((vector_base_addr + PAIVector),0x00);
	boot_rom->Program((vector_base_addr + PAIVector+1),0xCA);

}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: HC11::XIRQLevel, IRQLevel
//
// Author: Kalle Anderson
//
// Purpose: Functions to get and set the XIRQ and IRQ pins
//                   
// Input Parameters: the new level if it is being set setting, else nothing
//
// Return Value: the level if nothing was passed int
//
/////////////////////////////////////////////////////////////////////////////

void HC11::XIRQLevel(bit_t level)
{
    xirq_level = level;
};

void HC11::IRQLevel(bit_t level)
{
    if(regfile.IRQE() && irq_level && (level == 0))        
            irq_edge = 1;
    
    irq_level = level;
};

bit_t HC11::XIRQLevel(void)
{
    return(xirq_level);
};

bit_t HC11::IRQLevel(void)
{
    return(irq_level);
};

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: IRQInterrupt
//
// Author: Kalle Anderson
//
// Purpose: Returns a true or false about whether an IRQ interrupt has occured.
//                   
// Input Parameters: None
//
// Return Value: bool - whether an IRQ interupt occured
//
/////////////////////////////////////////////////////////////////////////////

bool HC11::IRQInterrupt(void)
{    
    return((regfile.IRQE()&&irq_edge)||(!regfile.IRQE()&&!irq_level));
};


STRAPin& HC11::GetSTRA()
{
	return(STRA);
}

const STRAPin& HC11::GetSTRAConst() const
{
	return(STRA);
}


