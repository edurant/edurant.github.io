#include "stdafx.h"
#include "hc11.h"

long LoadS19File(char *fname, HC11 *hc11)
{
        char line[256];
        int bc, val, cksm, fcksm, i;
        long addr;
		long start_addr = 99999999;

        FILE *fin;
        fin = fopen(fname,"r");

        if(!fin)
        {
            log("couldn't open s19 file!\n",0);
            return 0;
        }

        while (fgets(line, 256, fin) != NULL) 
        {                
                if (line[0] == 'S')
                switch(line[1])
                {
                    case '1':
                        sscanf(&line[2],"%2x",&bc);     // byte count
                        sscanf(&line[4],"%4x",&addr);   // starting address

						if(addr < start_addr)
							start_addr = addr;
                        
                        cksm = bc + (addr & 0xFF) + ((addr >> 8) & 0xFF);

                        for (i=0; i<(bc-3); i++) 
                        {                            
                            sscanf(&line[i*2 + 8], "%2x", &val);
                            hc11->memory.Write(static_cast<word_t>(addr+i), val); // EAD 20050101: Can addr be word_t?
                            cksm += val;
                        }
                        
                        sscanf(&line[(bc-3)*2 + 8], "%2x", &fcksm);
                        cksm = ~cksm & 0xFF;

                        if (cksm != fcksm)
                        {
                            log("s19 file checksum failed!\n",0);
                        }

                        break;                                           
//                    case '9':
//                        break;                       
                } 
                else log("unknown line type in s19 file!\n",0);
        }        
        fclose(fin);

		return start_addr;
}
