#if !defined(PIN_H)
#define PIN_H

#include "basetypes.h"
#include "CPinSubject.h"

#include "PinConnection.h"

class PortConnection;

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: Pin
//
//  Author: Paul Clarke, Kalle Anderson
//
//  Purpose: This is the object that represents an outside pin of the HC11.
//          This is used by all the ports, by the XIRQ and the IRQ.
//          The pin can be attached to a PinConnection object.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class Pin into its own header
//                              Consolidated public sections
//                              Added MANY #includes for new files
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099B0302
class Pin : public CPinSubject
{
 public:
	~Pin();

	Pin(const Pin& rhs);

	Pin& operator=(const Pin& rhs);

	virtual byte_t ReadMemory() const;

	virtual void WriteMemory(byte_t newValue);
	
	typedef enum  { INPUT = 0, OUTPUT, AUTO } PinDirection;	

	//##ModelId=3A3D099B033F
    Pin() { connect = NULL; level = 0; mode = Pin::OUTPUT; };
	//##ModelId=3A3D099B033E
	PinDirection GetMode() { return mode;};
	//##ModelId=3A3D099B0336
	void SetMode(PinDirection value) { mode = value; };
	//##ModelId=3A3D099B0334
	void Attach(PinConnection* pConnect) {	assert(pConnect != NULL); 
	                                        connect = pConnect; };
	//##ModelId=3A3D099B032C
	void UnAttach(void) { connect = NULL;};

	// these should be changes later
	//##ModelId=3A3D099B032B
	bit_t GetLevel(){return level;};
	
	//##ModelId=3A3D099B0329
	void Input(bit_t value);	// Only changes pin if mode = INPUT

 private:		
	//##ModelId=3A3D099B0317
	bit_t level;
	//##ModelId=3A3D099B030D
	PinDirection mode;
	//##ModelId=3A3D099B0305
	PinConnection* connect;	

 protected:
	//##ModelId=3A3D099B0321
	void Output(bit_t value); // Only changes pin if mode = OUTPUT
	//##ModelId=3A3D099B031F
	void Action(bit_t value); // Only changes pin if mode = AUTO

	friend class PortRegister;
    //  12/10/2000  JMB & BPF       Doesn't Exist?
	//friend class HC11SubSystem;
    friend class HandshakeIOSubSystem;
};


#endif //!defined(PIN_H)
