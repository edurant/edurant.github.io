#include "stdafx.h"
#include "DDRegister.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: DDRegister
//
// Author: Kalle Anderson
//
// Purpose: Initalize a DDRegister object.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
DDRegister::DDRegister(void)
{
	port_reg = NULL;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Read
//
// Purpose: To read the byte value of a DDRegister.
//
// Input Parameters: None.
//
// Return Value: The byte value of the register.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
byte_t DDRegister::Read(void)
{
    return byte;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: To write a byte value to the register.  After the byte is written,
//          the direction modes of the pins of the port that this register is
//          associated with are updated.
//
// Input Parameters: data - The byte to be written to the register.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void DDRegister::Write(byte_t data)
{
	byte = data;

	if (port_reg != NULL)
	{
		//Change the mode of the pins of the associated port
		if(port_reg->GetMode(0)!=Pin::AUTO)
			port_reg->pins[0].SetMode((data&0x1) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(1)!=Pin::AUTO)
			port_reg->pins[1].SetMode((data&0x2) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(2)!=Pin::AUTO)
			port_reg->pins[2].SetMode((data&0x4) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(3)!=Pin::AUTO)
			port_reg->pins[3].SetMode((data&0x8) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(4)!=Pin::AUTO)
			port_reg->pins[4].SetMode((data&0x10) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(5)!=Pin::AUTO)
			port_reg->pins[5].SetMode((data&0x20) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(6)!=Pin::AUTO)
			port_reg->pins[6].SetMode((data&0x40) ? Pin::OUTPUT : Pin::INPUT);
		if(port_reg->GetMode(7)!=Pin::AUTO)
			port_reg->pins[7].SetMode((data&0x80) ? Pin::OUTPUT : Pin::INPUT);
	}
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Associate
//
// Author: Paul Clarke
//
// Purpose: To associate a port with a DDRegister so that the DDRegister will
//          have control over the direction modes of the port's pins.
//
// Input Parameters:  port - Pointer to the port register to associate with the
//                    DDRegister.
//
// Return Value: None.
//
// Preconditions: The port pointer must not be NULL.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void DDRegister::Associate(PortRegister* port)
{
	assert(port != NULL);

	port_reg = port;
}
