#if !defined(AFX_PORTIO_H__64155C04_8F7A_11D1_BF13_0000C0E665E5__INCLUDED_)
#define AFX_PORTIO_H__64155C04_8F7A_11D1_BF13_0000C0E665E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PortIO.h : header file
//
#include "../emu/PinConnection.h"
#include "../emu/Pin.h"
#include "../emu/PortConnection.h"
#include "../emu/PortRegister.h"
#include "../emu/PortARegister.h"
#include "../emu/PortBRegister.h"
#include "../emu/DDRegister.h"


//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CPortIO
//
// Author: Kalle Anderson
//
// Purpose: This is the blinky led view for the ports. Also, if you click on 
//          an led, it will try to change that pins state.
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the UpdateDirectionLabels, GetDirectionString,
//                              and Visible() functions and the visible member.
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPortIO dialog
//##ModelId=3A3D09680351
class CPortIO : public CDialog, public PortConnection
{
// Construction
	//##ModelId=3A3D09690056
    void Update(byte_t val);
public:
    void UpdateDirectionLabels ();

	//##ModelId=3A3D09690042
	CPortIO(PortRegister *port, CString title, CWnd* pParent = NULL);   // standard constructor   
	// from PortConnection
	//##ModelId=3A3D09690038
    void Write(byte_t val);
	//##ModelId=3A3D0969002E
    void Visible(bool val);  
    bool Visible ();

// Dialog Data
	//{{AFX_DATA(CPortIO)
	enum { IDD = IDD_PORTIO };
	CStatic	m_dir7;
	CStatic	m_dir6;
	CStatic	m_dir5;
	CStatic	m_dir4;
	CStatic	m_dir3;
	CStatic	m_dir2;
	CStatic	m_dir1;
	CStatic	m_dir0;
	CButton	m_active;
	CEdit	m_valuec;
	CButton	m_pin7c;
	CButton	m_pin6c;
	CButton	m_pin4c;
	CButton	m_pin5c;
	CButton	m_pin3c;
	CButton	m_pin2c;
	CButton	m_pin1c;
	CButton	m_pin0c;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPortIO)
	protected:
	//##ModelId=3A3D09690027
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
    static CString GetDirectionString (Pin::PinDirection dir);


	//##ModelId=3A3D09680376
	PortRegister * m_port;
	//##ModelId=3A3D0968036C
    CBitmap led_on;
	//##ModelId=3A3D0968035A
    CBitmap led_off;

	// Generated message map functions
	//{{AFX_MSG(CPortIO)
	//##ModelId=3A3D09690025
	virtual BOOL OnInitDialog();
	//##ModelId=3A3D0969001F
	afx_msg void OnPin0();
	//##ModelId=3A3D0969001D
	afx_msg void OnPin1();
	//##ModelId=3A3D0969001B
	afx_msg void OnPin2();
	//##ModelId=3A3D09690015
	afx_msg void OnPin3();
	//##ModelId=3A3D09690013
	afx_msg void OnPin4();
	//##ModelId=3A3D09690011
	afx_msg void OnPin5();
	//##ModelId=3A3D0969000B
	afx_msg void OnPin6();
	//##ModelId=3A3D09690009
	afx_msg void OnPin7();
	//##ModelId=3A3D09690007
	virtual void OnOK();
	//##ModelId=3A3D096803E9
	afx_msg void OnActive();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
    bool visible;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PORTIO_H__64155C04_8F7A_11D1_BF13_0000C0E665E5__INCLUDED_)
