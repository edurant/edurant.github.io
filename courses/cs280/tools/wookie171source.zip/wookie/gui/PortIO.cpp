// PortIO.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "PortIO.h"
#include "KeypadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPortIO dialog

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CPortIO constructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
CPortIO::CPortIO(PortRegister *port, CString title, CWnd* pParent /*=NULL*/)
	: CDialog(CPortIO::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPortIO)
	//}}AFX_DATA_INIT
    m_port = port;   
    Create(IDD_PORTIO, NULL);    
    led_on.LoadBitmap(IDB_LEDON);    
    led_off.LoadBitmap(IDB_LEDOFF);    

    SetWindowText(title);    
}


void CPortIO::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPortIO)
	DDX_Control(pDX, IDC_DIRECTION7, m_dir7);
	DDX_Control(pDX, IDC_DIRECTION6, m_dir6);
	DDX_Control(pDX, IDC_DIRECTION5, m_dir5);
	DDX_Control(pDX, IDC_DIRECTION4, m_dir4);
	DDX_Control(pDX, IDC_DIRECTION3, m_dir3);
	DDX_Control(pDX, IDC_DIRECTION2, m_dir2);
	DDX_Control(pDX, IDC_DIRECTION1, m_dir1);
	DDX_Control(pDX, IDC_DIRECTION0, m_dir0);
	DDX_Control(pDX, IDC_ACTIVE, m_active);
	DDX_Control(pDX, IDC_PORTVALUE, m_valuec);
	DDX_Control(pDX, IDC_PIN7, m_pin7c);
	DDX_Control(pDX, IDC_PIN6, m_pin6c);
	DDX_Control(pDX, IDC_PIN4, m_pin4c);
	DDX_Control(pDX, IDC_PIN5, m_pin5c);
	DDX_Control(pDX, IDC_PIN3, m_pin3c);
	DDX_Control(pDX, IDC_PIN2, m_pin2c);
	DDX_Control(pDX, IDC_PIN1, m_pin1c);
	DDX_Control(pDX, IDC_PIN0, m_pin0c);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPortIO, CDialog)
	//{{AFX_MSG_MAP(CPortIO)
	ON_BN_CLICKED(IDC_PIN0, OnPin0)
	ON_BN_CLICKED(IDC_PIN1, OnPin1)
	ON_BN_CLICKED(IDC_PIN2, OnPin2)
	ON_BN_CLICKED(IDC_PIN3, OnPin3)
	ON_BN_CLICKED(IDC_PIN4, OnPin4)
	ON_BN_CLICKED(IDC_PIN5, OnPin5)
	ON_BN_CLICKED(IDC_PIN6, OnPin6)
	ON_BN_CLICKED(IDC_PIN7, OnPin7)
	ON_BN_CLICKED(IDC_ACTIVE, OnActive)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPortIO message handlers
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnInitDialog
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
BOOL CPortIO::OnInitDialog() 
{
	CDialog::OnInitDialog();	

    UpdateDirectionLabels();    

    CString valstr;
    //valstr.Format("0x%X",(int)m_port->Read());
    m_valuec.SetWindowText(valstr);
    return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Visible
//
// Author: Kalle Anderson
//
// Purpose: This shows/hides the dialog. When it is shown, the pins all get
//          initialized, and this class is attached to the port. 
//          When it gets hidded, it gets un-attached.
//
// Input Parameters: 
//
// Return Value: 
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the call to UpdateDirectionLabels on visible.
/////////////////////////////////////////////////////////////////////////////
void CPortIO::Visible(bool val)
{
	CString valstr;
    if(val)
    {
        visible = true;
        ShowWindow(true);	
        m_port->Attach(this);
        byte_t portval = m_port->Read();
        Update(portval);
        valstr.Format("0x%X",(int)portval);
	    m_valuec.SetWindowText(valstr);   
        UpdateDirectionLabels();
    }
    else
    {
        visible = false;
        ShowWindow(false);	
        m_port->UnAttach();
    }
}            


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Kalle Anderson
//
// Purpose: This is the "callback" that the GUI's get
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CPortIO::Write(byte_t val)
{    	
    CString valstr;
    Update(val);
    valstr.Format("0x%X",(int)val);
    m_valuec.SetWindowText(valstr);   
}   

// These OnPinX functions are called when the led's are clicked. They
// attempt to toggel the pin's value.
void CPortIO::OnPin0() 
{
    m_port->PinInput(0,!m_port->Read(0));		
}

void CPortIO::OnPin1() 
{
    m_port->PinInput(1,!m_port->Read(1));		
}

void CPortIO::OnPin2() 
{
    m_port->PinInput(2,!m_port->Read(2));		
}

void CPortIO::OnPin3() 
{
    m_port->PinInput(3,!m_port->Read(3));		
}

void CPortIO::OnPin4() 
{
    m_port->PinInput(4,!m_port->Read(4));		
}

void CPortIO::OnPin5() 
{
    m_port->PinInput(5,!m_port->Read(5));		
}

void CPortIO::OnPin6() 
{
    m_port->PinInput(6,!m_port->Read(6));		
}

void CPortIO::OnPin7() 
{
    m_port->PinInput(7,!m_port->Read(7));		
}

// Just hides dialog

void CPortIO::OnOK() 
{
	//CDialog::OnOK();
    Visible(0);
}

void CPortIO::OnActive()
{
	// TODO: Add your control notification handler code here
    if(m_active.GetCheck())    
        m_active.SetWindowText("Active Low");
    else
        m_active.SetWindowText("Active High");

    byte_t portval = m_port->Read();
    Update(portval);
}

void CPortIO::Update(byte_t val) 
{
    if(m_active.GetCheck())
    {
        m_pin0c.SetBitmap((val&0x1)?led_off:led_on);
        m_pin1c.SetBitmap((val&0x2)?led_off:led_on);
        m_pin2c.SetBitmap((val&0x4)?led_off:led_on);
        m_pin3c.SetBitmap((val&0x8)?led_off:led_on);
        m_pin4c.SetBitmap((val&0x10)?led_off:led_on);
        m_pin5c.SetBitmap((val&0x20)?led_off:led_on);
        m_pin6c.SetBitmap((val&0x40)?led_off:led_on);
        m_pin7c.SetBitmap((val&0x80)?led_off:led_on);
    }
    else 
    {
        m_pin0c.SetBitmap((val&0x1)?led_on:led_off);
        m_pin1c.SetBitmap((val&0x2)?led_on:led_off);
        m_pin2c.SetBitmap((val&0x4)?led_on:led_off);
        m_pin3c.SetBitmap((val&0x8)?led_on:led_off);
        m_pin4c.SetBitmap((val&0x10)?led_on:led_off);
        m_pin5c.SetBitmap((val&0x20)?led_on:led_off);
        m_pin6c.SetBitmap((val&0x40)?led_on:led_off);
        m_pin7c.SetBitmap((val&0x80)?led_on:led_off);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   GetDirectionString
// Scope:           CPortIO
// Usage:           Call this function to convert a Pin::PinDirection enumerated
//                  value into the corresponding label string.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function will return "I" for INPUT, "O" for OUTPUT, and
//                  "A" for AUTO.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  Pin::PinDirect� dir             I   Pin direction value to convert.
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  CString         One letter string representing the pin direction value.
//
// Author:          Jake & Blake
// Created:         01/28/2001 13:58:49
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CString CPortIO::GetDirectionString (Pin::PinDirection dir)
{
    CString szDir;
    switch(dir)
    {
    case Pin::INPUT:
        szDir = "I";
        break;
    case Pin::OUTPUT:
        szDir = "O";
        break;
    case Pin::AUTO:
        szDir = "A";
        break;
    }
    return(szDir);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   UpdateDirectionLabels
// Scope:           CPortIO
// Return Value:    <none>
// Usage:           Call this function to update the direction labels on the display.
// Pre-Conditions:  The m_port member must be set to a non-null value and the window
//                  must be created.
// Post-Conditions: <none>
// Description:     This function will use the GetMode(pin) function of the DDRegister
//                  class to determine which direction each pin is.  It will then
//                  convert these values to strings for the display using the
//                  GetDirectionString function.
//
// Author:          Jake & Blake
// Created:         01/28/2001 13:58:53
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CPortIO::UpdateDirectionLabels ()
{
    m_dir7.SetWindowText(GetDirectionString(m_port->GetMode(7)));
    m_dir6.SetWindowText(GetDirectionString(m_port->GetMode(6)));
    m_dir5.SetWindowText(GetDirectionString(m_port->GetMode(5)));
    m_dir4.SetWindowText(GetDirectionString(m_port->GetMode(4)));
    m_dir3.SetWindowText(GetDirectionString(m_port->GetMode(3)));
    m_dir2.SetWindowText(GetDirectionString(m_port->GetMode(2)));
    m_dir1.SetWindowText(GetDirectionString(m_port->GetMode(1)));
    m_dir0.SetWindowText(GetDirectionString(m_port->GetMode(0)));
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Visible
// Scope:           CPortIO
// Usage:           Call this function to check if the port display is currently
//                  visible.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function returns the visible member (updated in the other
//                  Visible function).
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  bool            True if the port display is visible.
//
// Author:          Jake & Blake
// Created:         01/28/2001 13:58:54
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
bool CPortIO::Visible ()
{
    return(visible);
}
