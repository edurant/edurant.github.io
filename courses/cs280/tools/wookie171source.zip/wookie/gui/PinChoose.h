#if !defined(AFX_PINCHOOSE_H__BEDBE1A3_9B4F_11D1_BF19_0000C03A66E5__INCLUDED_)
#define AFX_PINCHOOSE_H__BEDBE1A3_9B4F_11D1_BF19_0000C03A66E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PinChoose.h : header file
//

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CPinChoose
//
// Author: Kalle Anderson
//
// Purpose: This can be used to choose a specific pin on one of the ports.
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CPinChoose dialog

//##ModelId=3A3D096D03AF
class CPinChoose : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096D03C4
	CPinChoose(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPinChoose)
	enum { IDD = IDD_PINCHOOSE };
	//##ModelId=3A3D096D03BB
	int		m_port;
	//##ModelId=3A3D096D03BA
	int		m_pin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPinChoose)
	protected:
	//##ModelId=3A3D096D03BC
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPinChoose)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PINCHOOSE_H__BEDBE1A3_9B4F_11D1_BF19_0000C03A66E5__INCLUDED_)
