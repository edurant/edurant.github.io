////////////////////////////////////////////////////////////////////////////////
// File Name:       KeyButton.h
// Description:     This file declares the CKeyButton button class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:19:03
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(AFX_KEYBUTTON_H__9EA9F3FD_6592_4F2F_8964_6707B2513B88__INCLUDED_)
#define AFX_KEYBUTTON_H__9EA9F3FD_6592_4F2F_8964_6707B2513B88__INCLUDED_

#include "IKeySink.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeyButton.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CKeyButton window

////////////////////////////////////////////////////////////////////////////////
// Class Name:      CKeyButton
// Usage:           Use this class for the keys on a keypad.
// Description:     This class fires events to a IKeySink interface when a key
//                  is pressed and when it is released using the code the button
//                  was initialized with.
//
// Base Classes
//  Access          Name            Description
//  --------------- --------------- --------------------------------------------
//  public          CButton         MFC Button class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:19:19
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
class CKeyButton : public CButton
{
// Construction
public:
	CKeyButton(IKeySink& sink, short nCode);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CKeyButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CKeyButton)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
    short m_nCode;      //Code the button was initialized with
    IKeySink* m_pSink;  //Sink to fire events to
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYBUTTON_H__9EA9F3FD_6592_4F2F_8964_6707B2513B88__INCLUDED_)
