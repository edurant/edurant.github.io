// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "HardCoreWookieDoc.h"
#include "MainFrm.h"
#include "Hc11View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_LOADWINDOWSETTINGS, OnFileLoadwindowsettings)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{

}

CMainFrame::~CMainFrame()
{
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnCreate
//
// Author: Matt Enwald
//
// Purpose: To create the status bar
//
// Input Parameters: LPCREATESTRUCT - Unused
//
// Return Value: int - always 0
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	CPoint point;

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnCreateClient
//
// Author: Matt Enwald
//
// Purpose: To create the slider bar between the main dialog and the code view
//
// Input Parameters: 
//
// Return Value: BOOL - if true, Wookie frame loads.  If false, program exits
//
// Preconditions: None
//
// Post Conditions: Frame is created
//
/////////////////////////////////////////////////////////////////////////////
/*
BOOL CMainFrame::OnCreateClient( LPCREATESTRUCT ,
	CCreateContext* pContext)
{
	// Creating the horizontal splitter bar to divide the main dlg with the Code View

	if (!m_wndSplitter.CreateStatic(this,1,2))
	{
		return FALSE;
	}
	m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CHc11View),CSize(380,220),pContext);
	m_wndSplitter.CreateView(1,0,RUNTIME_CLASS(CCodeView),CSize(0,0),pContext);
	SetActiveView((CView*)m_wndSplitter.GetPane(0,0));

	return TRUE;
}
*/

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



void CMainFrame::OnFileLoadwindowsettings() 
{
	// TODO: Add your command handler code here
	
}
