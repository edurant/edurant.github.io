#if !defined(AFX_CODEVIEWERDLG_H__B15D0580_B4A6_11D2_AC60_004033510A08__INCLUDED_)
#define AFX_CODEVIEWERDLG_H__B15D0580_B4A6_11D2_AC60_004033510A08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CodeViewerDlg.h : header file

#pragma warning(disable: 4786)

#include "../emu/hc11.h"
#include <map>
/////////////////////////////////////////////////////////////////////////////
// CCodeViewerDlg dialog

//##ModelId=3A3D09690197
class CCodeViewerDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D0969024B
	CCodeViewerDlg(HC11 *hc11, CWnd* pParent = NULL);   // standard constructor

	//##ModelId=3A3D09690239
    void Visible(bool);    
	//##ModelId=3A3D09690242
    bool Visible(void){return visible;};    	
	//##ModelId=3A3D09690237
	void Update(void);
	//##ModelId=3A3D0969022E
	void AddLine(const char *txt, int address = -1);
	//##ModelId=3A3D09690225
	void Clear(void);
	//##ModelId=3A3D09690223
	bool SelectLine(int address);	
	//##ModelId=3A3D0969021B
	void LoadFile(void);
	//##ModelId=3A3D0969020F
	bool LoadLstFile(LPCTSTR filename);

// Dialog Data
	//{{AFX_DATA(CCodeViewerDlg)
	enum { IDD = IDD_CODEVIEW };
	//##ModelId=3A3D096901E9
	CButton	m_loadb;
	//##ModelId=3A3D096901DF
	CButton	m_clearb;
	//##ModelId=3A3D096901D5
	CButton	m_okb;
	//##ModelId=3A3D096901CB
	CListCtrl	m_listctrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCodeViewerDlg)
	protected:
	//##ModelId=3A3D09690211
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//##ModelId=3A3D096901C1
	HC11 *hc11;
	//##ModelId=3A3D096901BA
	bool visible;
	//##ModelId=3A3D096901B7
	CFont TheFont;	// added SLB, 4/10/99

	//##ModelId=3A3D096901AE
	std::map<int, int> address_map;

	// Generated message map functions
	//{{AFX_MSG(CCodeViewerDlg)
	//##ModelId=3A3D09690200
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//##ModelId=3A3D096901FE
	virtual void OnOK();
	//##ModelId=3A3D096901FC
	virtual BOOL OnInitDialog();
	//##ModelId=3A3D096901F3
	afx_msg void OnLoadLst();
	//##ModelId=3A3D096901F1
	afx_msg void OnClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CODEVIEWERDLG_H__B15D0580_B4A6_11D2_AC60_004033510A08__INCLUDED_)
