// HardCoreWookieDoc.h : interface of the CHardCoreWookieDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HARDCOREWOOKIEDOC_H__6DC3710B_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
#define AFX_HARDCOREWOOKIEDOC_H__6DC3710B_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "PortIO.h"
#include "hc11view.h"

#include "../emu/hc11sim.h"
#include "../emu/hc11.h"
#include "mainfrm.h"

#include <afxmt.h>

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CHardCoreWookieDoc
//
// Author: Kalle Anderson
//
// Purpose: Da Document Class. 
//
// Important things it does: It holds the HC11Sim class (and thus the hc11)
//                           "Global" access to the views and stuff.
//                           Manages the thread(s)
//                           Holds the breakpoint and the is_runnning flag
//
/////////////////////////////////////////////////////////////////////////////

// Thread function declaration
UINT TimerProc(LPVOID pParam);

// LoadS19File function declaration
void LoadS19File(char *fname, HC11 *hc11);

//##ModelId=3A3D096E01E4
class CHardCoreWookieDoc : public CDocument
{
protected: // create from serialization only
	//##ModelId=3A3D096E0273
	CHardCoreWookieDoc();
	DECLARE_DYNCREATE(CHardCoreWookieDoc)

// Attributes
public:
	//##ModelId=3A3D096E0222
	CToolBar	m_ToolBar;
//	CCodeView* m_pCodeView;
	//##ModelId=3A3D096E0218
    CHc11View *m_pHc11View;     
	//##ModelId=3A3D096E020D
    HWND m_hwndHc11View;
// Operations

    // used when the simulator is run "all out"
	//##ModelId=3A3D096E0271
    void SimGO(void);
	//##ModelId=3A3D096E026A
    void SimSTOP(void);

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHardCoreWookieDoc)
	public:
	//##ModelId=3A3D096E0268
	virtual BOOL OnNewDocument();
	//##ModelId=3A3D096E025E
	virtual void Serialize(CArchive& ar);
	//##ModelId=3A3D096E0257
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
    // da break point. (set negative to disable)
	//##ModelId=3A3D096E020C
    int m_breakpoint;
	
    // The event used to pause the worker thread
	//##ModelId=3A3D096E0202
    HANDLE m_hThreadGo;    

    // signifies that the thread is running
	//##ModelId=3A3D096E01F9
	int m_isrunning;    	

	CString basefilename;
        
    // THE SIMULATOR
	//##ModelId=3A3D096E01F0
	HC11Sim hc11sim;

	//##ModelId=3A3D096E0256
    HC11* GetHC11();

	//##ModelId=3A3D096E0254
	virtual ~CHardCoreWookieDoc();

#ifdef _DEBUG
	//##ModelId=3A3D096E0252
	virtual void AssertValid() const;
	//##ModelId=3A3D096E024A
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
public:

    //{{AFX_MSG(CHardCoreWookieDoc)
	afx_msg void OnSimmulatorStep();
	afx_msg void OnUpdateSimmulatorStep(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnAddRmbs();
	afx_msg void OnUpdateAddRmbs(CCmdUI* pCmdUI);
	afx_msg void OnEgg();
	afx_msg void OnUpdateClose(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
    // The worker thread (i dunno why it got called m_timerThread
	//##ModelId=3A3D096E01E8
	CWinThread* m_timerThread;    	
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HARDCOREWOOKIEDOC_H__6DC3710B_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
