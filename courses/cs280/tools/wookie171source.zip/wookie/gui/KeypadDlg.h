////////////////////////////////////////////////////////////////////////////////
// File Name:       KeypadDlg.h
// Description:     This file declares the CKeypadDlg class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:35:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(AFX_KEYPADDLG_H__A6D9E8AE_058D_48FB_BFF9_074DA8578C3D__INCLUDED_)
#define AFX_KEYPADDLG_H__A6D9E8AE_058D_48FB_BFF9_074DA8578C3D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeypadDlg.h : header file
//
#include "../emu/hc11.h"
#include "KeyButton.h"
#include "resource.h"

////////////////////////////////////////////////////////////////////////////////
// Class Name:      CKeypadDlg
// Usage:           CKeypadDlg dialog (IDD_KEYPAD).
// Description:     This dialog mimics the keypad functionality using port c.
//
// Base Classes
//  Access          Name            Description
//  --------------- --------------- --------------------------------------------
//  public          CDialog         MFC Dialog base class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:10:49
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
class CKeypadDlg : public CDialog, public IKeySink, public PortConnection
{
// Construction
public:
	CKeypadDlg(HC11* pHC11, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CKeypadDlg)
	enum { IDD = IDD_KEYPAD };
	CKeyButton	m_keyF;
	CKeyButton	m_keyE;
	CKeyButton	m_keyD;
	CKeyButton	m_keyC;
	CKeyButton	m_keyB;
	CKeyButton	m_keyA;
	CKeyButton	m_key9;
	CKeyButton	m_key8;
	CKeyButton	m_key7;
	CKeyButton	m_key6;
	CKeyButton	m_key5;
	CKeyButton	m_key4;
	CKeyButton	m_key3;
	CKeyButton	m_key2;
	CKeyButton	m_key1;
	CKeyButton	m_key0;
	CStatic	m_error;
	//}}AFX_DATA

    void Update ();
    bool UpdateDisplay ();
    virtual void Write (byte_t val);

    void Visible (bool val);
    bool Visible () const;

    virtual void OnKeyDown (short nCode);
    virtual void OnKeyUp (short nCode);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeypadDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CKeypadDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
    void UpdatePressedValue (short nValue);

    HC11* m_pHC11;          //Pointer to the simulator.
    bool m_bVisible;        //Whether the window is visible or not (to be consistent with other dialogs)
    short m_nPressedValue;  //What the last key pressed was, -1 for nothing pressed.
                            // 0 - 9 => 0 - 9
                            // A - F => 10 - 15
	static const byte_t m_aLookupTable[17][16];
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYPADDLG_H__A6D9E8AE_058D_48FB_BFF9_074DA8578C3D__INCLUDED_)
