// HardCoreWookieDoc.cpp : implementation of the CHardCoreWookieDoc class
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "HardCoreWookieDoc.h"

#include "MainFrm.h"

#include "Hc11View.h"
#include "SetModeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int StringToHex (CString);


/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieDoc

IMPLEMENT_DYNCREATE(CHardCoreWookieDoc, CDocument)

BEGIN_MESSAGE_MAP(CHardCoreWookieDoc, CDocument)
	//{{AFX_MSG_MAP(CHardCoreWookieDoc)
	ON_COMMAND(ID_SIMMULATOR_STEP, OnSimmulatorStep)
	ON_UPDATE_COMMAND_UI(ID_SIMMULATOR_STEP, OnUpdateSimmulatorStep)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_COMMAND(ID_ADD_RMBS, OnAddRmbs)
	ON_UPDATE_COMMAND_UI(ID_ADD_RMBS, OnUpdateAddRmbs)
	ON_COMMAND(ID_EGG, OnEgg)
	ON_UPDATE_COMMAND_UI(ID_CLOSE, OnUpdateClose)
	ON_COMMAND(ID_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieDoc construction/destruction
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CHardCoreWookieDoc Constructor
//
// Author: Matt Enwald
//
// Purpose: To initialize the proper variables when a new document is created
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: The GUI must know that the simulator is not running. 
//					The thread that runs the HC11 must be initialized and ready
//					to go.
//					The breakpoint must be initialized to an invalid number
//
/////////////////////////////////////////////////////////////////////////////
CHardCoreWookieDoc::CHardCoreWookieDoc()
: m_pHc11View(0), // added 2/29/2002, SLB suggested by Eric Durant
  m_isrunning(0),
  m_breakpoint(-1) // indicates no breakpoint
{    
    m_hThreadGo = CreateEvent(NULL, TRUE, FALSE, NULL);
    // idle priority seems to work better than normal priority
	m_timerThread = AfxBeginThread(TimerProc, LPVOID(this), THREAD_PRIORITY_IDLE);
    
	hc11sim.Config(HC11SimConfig(1));
	hc11sim.SetStartAddress(0xC000);
	hc11sim.hc11.Reset();
}

CHardCoreWookieDoc::~CHardCoreWookieDoc()
{

}

BOOL CHardCoreWookieDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

//	m_pCodeView->GetEditCtrl().SetReadOnly();

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieDoc serialization

void CHardCoreWookieDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieDoc diagnostics

#ifdef _DEBUG
void CHardCoreWookieDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CHardCoreWookieDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieDoc commands
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnOpenDocument
//
// Author: Matt Enwald and Kalle Anderson
//
// Purpose: To load a new HC11 (s19 and lst) that the user specifies.
//
// Input Parameters: LPCTSTR lpszPathName
//
// Return Value: BOOL - Did the HC11 load properly?
//
// Preconditions: None.
//
// Post Conditions: If the return value is true, the S19 and LST files must be
//					loaded properly.
//
/////////////////////////////////////////////////////////////////////////////
BOOL CHardCoreWookieDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
    // in case they try to open a file while the simulator is running
    if(m_isrunning)
		CHardCoreWookieDoc::SimSTOP();

	OnClose();

    if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;	

    int address=-1;

	// path contains the filename and path of the file the user wants to open
	CString s19path = lpszPathName;
    
	// Load the LST file into the CCodeView.  The path and file name from 
	// the S19 file can be used, the 3 letter .S19 extension is stripped 
	// and replaced with the .LST extension
		
	CString extension = s19path.Right(3);

	if(extension == "s19" || extension == "S19")
	{   		
		// Display the Set Mode dialog box to prompt the user for a mode and start address
		CSetModeDlg pDlg;
		//pDlg.m_address.Format("%X",(int)0);
		//Previous line commented out to allow changing of default starting address within SetModeDlg initialization
		pDlg.DoModal();
		
		// Set the mode according to the user's response
		hc11sim.Config(HC11SimConfig(pDlg.m_mode+1));

		// Convert the start address for the starting PC value to hex
		sscanf(pDlg.m_address,"%X",&address);
		if(address>=0 && address<=0xffff)
			hc11sim.SetStartAddress(address);    
   		else
			hc11sim.SetStartAddress(0);

		// Reset the HC11	
		hc11sim.hc11.Reset();
		// Load the S19 file into the HC11
		if (!hc11sim.LoadS19File(s19path.GetBuffer(0)))
			return FALSE;

		// 3/24/2005: Previous version loaded the listing and updated the view here.
		// Problem 1: Crash if double-click on S19 (view not yet created)
		// Problem 2: Checking for NULL prevents crash, but does not allow code to be loaded by double-click.
		// Solution: Defer the loading behavior until Hc11View::OnInitialUpdate (even called when loading subsequent S19s)

		basefilename = s19path.Left(s19path.GetLength()-extension.GetLength()); // includes period -- used by Hc11View::OnInitial Update
		m_breakpoint=-1;
	}
	
	return TRUE;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnSimmulatorStep (the incorrect spelling version 1.0)
//
// Author: Matt Enwald
//
// Purpose: To step the HC11 through only 1 instruction or opcode.
//
// Input Parameters: None
//
// Return Value: None.
//
// Preconditions: The HC11 must be loaded
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHardCoreWookieDoc::OnSimmulatorStep() 
{
	hc11sim.hc11.Step();
	m_pHc11View->m_pCodeView->SelectLine(hc11sim.hc11.PC);
	m_pHc11View->Update();           
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: SimGO
//
// Author: Kalle Anderson
//
// Purpose: To run the HC11 at full speed
//
// Input Parameters: None
//
// Return Value: None.
//
// Preconditions: The HC11 must be loaded
//
// Post Conditions: The HC11 must be running at full speed
//
/////////////////////////////////////////////////////////////////////////////
void CHardCoreWookieDoc::SimGO() 
{    
	// Set the running flag to running in order to notify the GUI that the 
	// HC11 thread is running full speed.
    m_isrunning = 1;
	// Resume the thread that runs the HC11 at full speed.
    SetEvent(m_hThreadGo);	
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: SimSTOP
//
// Author: Kalle Anderson
//
// Purpose: To stop the HC11 if it is running and select the line of code it
//			stopped on.
//
// Input Parameters: None
//
// Return Value: None.
//
// Preconditions: The HC11 must be loaded
//
// Post Conditions: The HC11 must be stopped.
//
/////////////////////////////////////////////////////////////////////////////
void CHardCoreWookieDoc::SimSTOP() 
{    
	// By clearing this flag to 0, if the HC11 is running, the thread will stop
    m_isrunning = 0;
    // Now that the simulator has stopped, select the line of code in the CodeView
	m_pHc11View->m_pCodeView->SelectLine(hc11sim.hc11.PC);
	// Also, update all the register dialog, memwatch dialog, cpu dialog, etc.
    m_pHc11View->Update();     
}

HC11* CHardCoreWookieDoc::GetHC11()
{
	return (&hc11sim.hc11);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: TimerProc
//
// Author: Kalle Anderson
//
// Purpose: To run the HC11 at full speed using a thread, enabling all GUI 
//			functions while the HC11 is running.
//
// Input Parameters: void* pParam - this is a pointer to the open HC11 document
//
// Return Value: UINT - return value from thread - unused
//
// Preconditions: The HC11 must be loaded
//
// Post Conditions: The HC11 must be in a valid state.
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the sending of the OnCodeStep notification.
/////////////////////////////////////////////////////////////////////////////
UINT TimerProc(void * pParam)
{
	CHardCoreWookieDoc* pDoc = (CHardCoreWookieDoc*)pParam;	    
 
    // forever 
    for(;;)
    {   
        // This is used to pause the GUI when it falls out of the
        // m_isrunning loop. This avoids having to start up a new thread
        // each time the simulator is run "all-out"
        WaitForSingleObject(pDoc->m_hThreadGo,INFINITE);        
        while(pDoc->m_isrunning) 
	    {	              
            // I tried using some synchronization classes inside this loop
            // and it slowed stuff down too much. It works well without
            // them though.
            pDoc->hc11sim.hc11.Step();        

            if (pDoc->m_breakpoint == (int)pDoc->hc11sim.hc11.PC)                  
                break;            
	    }       
        // Reseting the event will "pause" this thread again.
        ResetEvent(pDoc->m_hThreadGo);                            
        // Notify the Hc11View that the thread has stopped stepping
        // the HC11. This will cause it to highlight the current line
        // of code etc... 
        ::PostMessage(pDoc->m_hwndHc11View,WM_THREAD_STOP, 0, 0);			    
    }
	return(0);
}



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnUpdateSimmulatorStep
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: The menu item
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////
void CHardCoreWookieDoc::OnUpdateSimmulatorStep(CCmdUI* pCmdUI) 
{
    pCmdUI->Enable(!m_isrunning);    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnUpdateFileOpen
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: The menu item
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////
void CHardCoreWookieDoc::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_isrunning);    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnAddRmbs
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: None
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////

void CHardCoreWookieDoc::OnAddRmbs() 
{
	// TODO: Add your command handler code here
	AfxMessageBox("This command is not currently implemented");	
//    m_pCodeView->AddRmbWatches(m_pHc11View->m_pWatch);    	
//    m_pHc11View->m_pWatch->Update();
}

// disable the above menu item when there is no .lst file
void CHardCoreWookieDoc::OnUpdateAddRmbs(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
//    pCmdUI->Enable(m_pCodeView->m_isFileOpen);
} 

void CHardCoreWookieDoc::OnEgg() 
{
	AfxMessageBox ("Show WOOKIE now");	
}

void CHardCoreWookieDoc::OnUpdateClose(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_isrunning);    	
}

void CHardCoreWookieDoc::OnClose() 
{
	// TODO: Add your specialized code here and/or call the base class
    SetPathName("Untitled",FALSE);

	// modified 2/29/2002 by SLB, suggested by Eric Durant
	if (m_pHc11View)	// not initialized when called for a startup (e.g. double-click or command line) document
		m_pHc11View->m_pCodeView->Clear();

//	CDocument::OnCloseDocument();
}
