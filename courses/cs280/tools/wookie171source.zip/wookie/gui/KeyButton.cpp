////////////////////////////////////////////////////////////////////////////////
// File Name:       KeyButton.cpp
// Description:     This file defines all CKeyButton member functions.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:24:50
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "hardcorewookie.h"
#include "KeyButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CKeyButton
// Scope:           CKeyButton
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the sink and the code for the button.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  IKeySink&       sink            I/O Sink to fire events to.
//  short           nCode           I   Code of the key (unique among other keys).
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:23:51
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CKeyButton::CKeyButton(IKeySink& sink, short nCode)
{
    m_pSink = &sink;
    m_nCode = nCode;
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~CKeyButton
// Scope:           CKeyButton
// Return Value:    <none>
// Usage:           Destructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:24:33
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CKeyButton::~CKeyButton()
{
    //nothing
}

BEGIN_MESSAGE_MAP(CKeyButton, CButton)
	//{{AFX_MSG_MAP(CKeyButton)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnLButtonDown
// Scope:           CKeyButton
// Return Value:    <none>
// Usage:           Event called when the buttons gets pressed.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the OnKeyDown event of the sink.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  UINT            nFlags          I   <don't care>
//  CPoint          point           I   <don't care>
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:22:18
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeyButton::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_pSink->OnKeyDown(m_nCode);
	CButton::OnLButtonDown(nFlags, point);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnLButtonUp
// Scope:           CKeyButton
// Return Value:    <none>
// Usage:           Event called when the button gets lifted.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the OnKeyUp event of the sink.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  UINT            nFlags          I   <don't care>
//  CPoint          point           I   <don't care>
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:22:20
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeyButton::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_pSink->OnKeyUp(m_nCode);
	CButton::OnLButtonUp(nFlags, point);
}
