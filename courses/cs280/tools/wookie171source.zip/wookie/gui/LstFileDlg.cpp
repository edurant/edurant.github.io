// LstFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "LstFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLstFileDlg dialog


CLstFileDlg::CLstFileDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLstFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLstFileDlg)
	m_filetype = 3; // GCC3 - latest and probably most common listing format - update when this changes in the future
	m_startingaddr = _T("0");
	//}}AFX_DATA_INIT
}


void CLstFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLstFileDlg)
	DDX_CBIndex(pDX, IDC_COMBO1, m_filetype);
	DDX_Text(pDX, IDC_ADDRESS, m_startingaddr);
	DDV_MaxChars(pDX, m_startingaddr, 4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLstFileDlg, CDialog)
	//{{AFX_MSG_MAP(CLstFileDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLstFileDlg message handlers
