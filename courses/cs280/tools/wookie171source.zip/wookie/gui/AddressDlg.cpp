// AddressDlg.cpp : implementation file
//

//////////////////////////////////////////////////////////////////////////////
//
// Microsoft wrote this code for me. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "HardCoreWookie.h"
#include "AddressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddressDlg dialog


CAddressDlg::CAddressDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddressDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddressDlg)
	m_address = _T("");
	m_name = _T("");
	m_word = false;
	m_byte = -1;
	//}}AFX_DATA_INIT
	m_byte = 0;
}


void CAddressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddressDlg)
	DDX_Text(pDX, IDC_EDIT1, m_address);
	DDV_MaxChars(pDX, m_address, 4);
	DDX_Text(pDX, IDC_EDIT2, m_name);
	DDX_Radio(pDX, IDC_BYTE, m_byte);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddressDlg, CDialog)
	//{{AFX_MSG_MAP(CAddressDlg)
	ON_BN_CLICKED(IDC_BYTE, OnByte)
	ON_BN_CLICKED(IDC_WORD, OnWord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddressDlg message handlers

void CAddressDlg::OnByte() 
{
//	m_word = false;
	
}

void CAddressDlg::OnWord() 
{
//	m_word = true;
	
}
