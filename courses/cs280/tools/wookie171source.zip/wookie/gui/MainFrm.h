// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__6DC37109_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
#define AFX_MAINFRM_H__6DC37109_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//##ModelId=3A3D096A00F8
class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	//##ModelId=3A3D096A012E
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
protected:
	//##ModelId=3A3D096A0116
	CSplitterWnd m_wndSplitter;
public:
	//##ModelId=3A3D096A0106
	CStatusBar  m_wndStatusBar;
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	//##ModelId=3A3D096A012B
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	//##ModelId=3A3D096A0125
	virtual ~CMainFrame();
#ifdef _DEBUG
	//##ModelId=3A3D096A0123
	virtual void AssertValid() const;
	//##ModelId=3A3D096A0120
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	//##ModelId=3A3D096A0103
	int			m_PC;

// Generated message map functions
public:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnFileLoadwindowsettings();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__6DC37109_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
