// MemoryWatch.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "MemoryWatch.h"
#include "AddressDlg.h"
#include "ctrlext.h"
#include "valuedlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemoryWatch dialog
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CMemoryWatch constructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
CMemoryWatch::CMemoryWatch(HC11 *phc11, CWnd* pParent /*=NULL*/)
	: CDialog(CMemoryWatch::IDD, pParent)
{
    Create(IDD_MEMWATCH, NULL);    
    visible = 0;    
    hc11 = phc11;
    numerical_base = hex_base;

    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	    	    		
	ctlList.AddColumn("name   ",0);
    ctlList.AddColumn("address",1);
    ctlList.AddColumn("hex value    ",2);
    //ctlList.AddColumn("Binary      ",3);
                       
    //{{AFX_DATA_INIT(CMemoryWatch)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT   
}


void CMemoryWatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemoryWatch)
	DDX_Control(pDX, IDC_DELETEWATCH, m_delete);
	DDX_Control(pDX, IDC_ADDWATCH, m_add);
	DDX_Control(pDX, IDC_LIST, m_listctrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMemoryWatch, CDialog)
	//{{AFX_MSG_MAP(CMemoryWatch)
	ON_BN_CLICKED(IDC_ADDWATCH, OnAddwatch)
	ON_BN_CLICKED(IDC_DELETEWATCH, OnDeletewatch)
	ON_BN_CLICKED(IDC_UPDATE, OnUpdate)
	ON_BN_CLICKED(IDC_MODIFY, OnModify)
	ON_BN_CLICKED(IDC_BASE, OnBase)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemoryWatch message handlers
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnAddwatch
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::OnAddwatch() 
{
	// TODO: Add your control notification handler code here
	CAddressDlg dlg;
    int address=-1000;

    if(dlg.DoModal() == IDOK)
    {
        sscanf(dlg.m_address,"%X",&address);
        
        if(address>=0 && address<=0xffff)
        {
            AddWatch(dlg.m_name,address);
			// If 'word' was selected for display, and the next byte is not 
			//	invalid, then add the next byte of the word.
			if(dlg.m_byte == 1 && (address + 0x0001<=0xffff))
			{
				AddWatch(dlg.m_name + "2",(address + 0x0001));
			}
            Update();
        }
        else
        {
            AfxMessageBox("invalid address!");
        }
    }
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnDeletewatch
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::OnDeletewatch() 
{    
    int i;    
    LV_ITEM item;
    item.mask = LVIF_STATE;
    item.stateMask = LVIS_SELECTED;
    item.iSubItem = 0;

    std::list<word_t>::iterator index = watches.begin();    
 
    for(i=0;i< m_listctrl.GetItemCount();i++,index++)
    {        
        item.iItem = i;
        if(m_listctrl.GetItem(&item))
        if(item.state&LVIS_SELECTED)
        {            
            m_listctrl.DeleteItem(item.iItem);     
            watches.remove(*index);
            break;
        }        
    }
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Visible
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::Visible(bool val)
{
    visible = val;

    if(val)
    {
        ShowWindow(true);	    
        Update();
    }
    else    
        ShowWindow(false);	        
}            


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Update
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::Update(void)
{
    CString data;    
	int num;
    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	    
    std::list<word_t>::iterator index = watches.begin();    
    int i=0;

    for(; index != watches.end(); index++, i++)
	{
		num=(int)hc11->memory.Read(*index);
        switch(numerical_base)
        {
            case hex_base:
                data.Format("$%.2X",num);//addendum
                break;
            case decimal_base:
                data.Format("%d",num);
                break;
            case binary_base:
                data = "%00000000";                              
                for(int j=0;j<8;j++)	                
                    data.SetAt(8-j,(num&(1<<j)) ? '1' : '0');	            
                break;
        }        
        ctlList.AddItem(i,2,data);
	}		    
};

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnUpdate
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::OnUpdate() 
{
	// TODO: Add your control notification handler code here
    Update();	
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: AddWatch
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::AddWatch(CString name, word_t address)
{
    CString addrstr;
    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	

    addrstr.Format("$%X",address);
    watches.push_back(address);          
    ctlList.AddItem(watches.size()-1,0,name);
    ctlList.AddItem(watches.size()-1,1,addrstr);
}



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CRegisterWatch constructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
CRegisterWatch::CRegisterWatch(HC11 *phc11, CWnd* pParent)
	: CMemoryWatch(phc11, pParent)
{
    m_add.ShowWindow(false);    
    m_delete.ShowWindow(false);
    SetWindowText("Register Watch");  
    AddWatch("PORTA",0x1000);
    AddWatch("PIOC",0x1002);
    AddWatch("PORTC",0x1003);
    AddWatch("PORTB",0x1004);
    AddWatch("PORTCL",0x1005);
    AddWatch("DDRC",0x1007);
    AddWatch("PORTD",0x1008);    
    AddWatch("DDRD",0x1009);
    AddWatch("PORTE",0x100A);
    AddWatch("CFORC",0x100B);
    AddWatch("OC1M",0x100C);
    AddWatch("OC2D",0x100D);
    AddWatch("TCNT(H)",0x100E);
    AddWatch("TCNT(L)",0x100F);    
    AddWatch("TIC1(H)",0x1010);    
    AddWatch("TIC1(L)",0x1011);    
    AddWatch("TIC2(H)",0x1012);    
    AddWatch("TIC2(L)",0x1013);    
    AddWatch("TIC3(H)",0x1014);    
    AddWatch("TIC3(L)",0x1015);    
    AddWatch("TOC1(H)",0x1016);    
    AddWatch("TOC1(L)",0x1017);    
    AddWatch("TOC2(H)",0x1018);    
    AddWatch("TOC2(L)",0x1019);    
    AddWatch("TOC3(H)",0x101A);    
    AddWatch("TOC3(L)",0x101B);    
    AddWatch("TOC4(H)",0x101C);    
    AddWatch("TOC4(L)",0x101D);    
    AddWatch("T14/O5(H)",0x101E);    
    AddWatch("T14/05(L)",0x101F);    
    AddWatch("TCTL1",0x1020);    
    AddWatch("TCTL2",0x1021);    
    AddWatch("TMSK1",0x1022);    
    AddWatch("TFLG1",0x1023);    
    AddWatch("TMSK2",0x1024);    
    AddWatch("TFLG2",0x1025);    
    AddWatch("PACTL",0x1026);    
    AddWatch("PACNT",0x1027);    
    AddWatch("SPCR",0x1028);    
    AddWatch("SPSR",0x1029);    
    AddWatch("SPDR",0x102A);    
    AddWatch("BAUD",0x102B);    
    AddWatch("SCCR1",0x102C);    
    AddWatch("SCCR2",0x102D);    
    AddWatch("SCSR",0x102E);    
    AddWatch("SCDR",0x102F);    
    AddWatch("ADCTL",0x1030);    
    AddWatch("ADR1",0x1031);    
    AddWatch("ADR2",0x1032);    
    AddWatch("ADR3",0x1033);    
    AddWatch("ADR4",0x1034);    
    AddWatch("BPROT",0x1035);    
    AddWatch("EPROG2",0x1036);    
    AddWatch("OPTION",0x1039);    
    AddWatch("COPRST",0x103A);    
    AddWatch("PPROG",0x103B);    
    AddWatch("HPRIO",0x103C);    
    AddWatch("INIT",0x103D);    
    AddWatch("TEST1",0x103E);    
    AddWatch("CONFIG",0x103F);    
}   
 


void CMemoryWatch::OnOK() 
{
    Visible(0);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnModify
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::OnModify() 
{
	// TODO: Add your control notification handler code here
    CValueDlg dlg;
    int value = -1;

        
    LV_ITEM item;
    item.mask = LVIF_STATE;
    item.stateMask = LVIS_SELECTED;
    item.iSubItem = 0;

    std::list<word_t>::iterator index = watches.begin();    
    int i;

    for(i=0; i< m_listctrl.GetItemCount(); i++, index++)
    {        
        item.iItem = i;
        if(m_listctrl.GetItem(&item))
        if(item.state&LVIS_SELECTED)
        {  
            value = hc11->memory.Read(*index);
            switch(numerical_base)
            {
                case hex_base:
                    dlg.m_value.Format("%X",value);
                    dlg.m_radio = 0;
                    break;
                case decimal_base:
                    dlg.m_value.Format("%d",value);
                    dlg.m_radio = 1;
                    break;
                case binary_base:
                    dlg.m_value = "00000000";                              
                    for(int j=0;j<8;j++)	                
                        dlg.m_value.SetAt(7-j,(value&(1<<j)) ? '1' : '0');	            
                    dlg.m_radio = 2;
                    break;
            }        
           
			if(dlg.DoModal() == IDOK)
			{				
				if(dlg.value_ok) // 4 chars
				{
					hc11->memory.Write(*index,(byte_t)(dlg.value&0xFF));					
					Update();
				}
                else AfxMessageBox("invalid value!");
			}
 
			break;
        }        
    }	
}



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnBase
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::OnBase() 
{
	// TODO: Add your control notification handler code here
    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	    	    		
    ctlList.DeleteColumn(2);
    switch(numerical_base)
    {
        case hex_base:
            numerical_base = decimal_base;
            ctlList.AddColumn("decimal value",2);
            break;
        case decimal_base:
            numerical_base = binary_base;
            ctlList.AddColumn("binary value ",2);
            break;
        case binary_base:
            numerical_base = hex_base;
            ctlList.AddColumn("hex value    ",2);
            break;
    }        
    
	int i=0;

    std::list<word_t>::iterator index = watches.begin();
    CString addrstr;

    for(; index != watches.end(); index++, i++)
	{        
        addrstr.Format("$%X", *index);                
        ctlList.AddItem(i,1,addrstr);
	}		    

    Update();
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: ClearWatches
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void CMemoryWatch::ClearWatches(void) 
{     
    while(m_listctrl.GetItemCount() > 0)
    {                    
            m_listctrl.DeleteItem(0);
            watches.pop_front();
    }
}
BEGIN_MESSAGE_MAP(CRegisterWatch, CMemoryWatch)
	//{{AFX_MSG_MAP(CRegisterWatch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

