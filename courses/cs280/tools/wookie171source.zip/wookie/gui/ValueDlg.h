#if !defined(AFX_VALUEDLG_H__A61C5374_92A3_11D1_BF16_0000C03A66E5__INCLUDED_)
#define AFX_VALUEDLG_H__A61C5374_92A3_11D1_BF16_0000C03A66E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ValueDlg.h : header file
//

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CValueDlg
//
// Author: Kalle Anderson
//
// Purpose: General dialog for entering values in hex/binary/decimal. One
//          thing that should be changed would be to add conversion in the
//          DoDataExchange function. Cause, right now the default string that
//          get stuck in this dialog, must be computeed externally, although
//          the output value gets computed by this class.
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CValueDlg dialog

//##ModelId=3A3D096C00A1
class CValueDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096C00D8
	CValueDlg(CWnd* pParent = NULL);   // standard constructor
    
	//##ModelId=3A3D096C00C0
    int value;
	//##ModelId=3A3D096C00BF
    bool value_ok;

// Dialog Data
	//{{AFX_DATA(CValueDlg)
	enum { IDD = IDD_VALUEDLG };
	//##ModelId=3A3D096C00B8
	CEdit	m_valuectrl;
	//##ModelId=3A3D096C00B5
	CString	m_value;
	//##ModelId=3A3D096C00AC
	int		m_radio;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CValueDlg)
	protected:
	//##ModelId=3A3D096C00D5
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CValueDlg)
	//##ModelId=3A3D096C00D3
	virtual void OnOK();
	//##ModelId=3A3D096C00CC
	afx_msg void OnHex();
	//##ModelId=3A3D096C00CA
	afx_msg void OnDecimal();
	//##ModelId=3A3D096C00C1
	afx_msg void OnBinary();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VALUEDLG_H__A61C5374_92A3_11D1_BF16_0000C03A66E5__INCLUDED_)
