#if !defined(AFX_ADDRESSDLG_H__AC3EAF54_9122_11D1_BF13_0000C0EB65E5__INCLUDED_)
#define AFX_ADDRESSDLG_H__AC3EAF54_9122_11D1_BF13_0000C0EB65E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AddressDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddressDlg dialog
//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CAddressDlg
//
// Author: Kalle Anderson & Bill Gates
//
// Purpose: This is used to enter the watches into the memory watch window
//
/////////////////////////////////////////////////////////////////////////////

//##ModelId=3A3D096A0166
class CAddressDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096A0174
	CAddressDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddressDlg)
	enum { IDD = IDD_ADDRESS };
	CString	m_address;
	CString	m_name;
	bool m_word;
	int		m_byte;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddressDlg)
	protected:
	//##ModelId=3A3D096A0171
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddressDlg)
	afx_msg void OnByte();
	afx_msg void OnWord();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDRESSDLG_H__AC3EAF54_9122_11D1_BF13_0000C0EB65E5__INCLUDED_)
