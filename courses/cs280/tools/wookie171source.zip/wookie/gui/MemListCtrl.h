#if !defined(AFX_MEMLISTCTRL_H__8D968A60_35E2_11D2_AC60_004033510A08__INCLUDED_)
#define AFX_MEMLISTCTRL_H__8D968A60_35E2_11D2_AC60_004033510A08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MemListCtrl.h : header file
//
#include "ctrlext.h"
#include "../emu/hc11.h"

/////////////////////////////////////////////////////////////////////////////
// CMemListCtrl window

//##ModelId=3A3D096C03AE
class CMemListCtrl : public CListCtrlEx
{
// Construction
public:
	//##ModelId=3A3D096D0005
	CMemListCtrl();

	//##ModelId=3A3D096C03B2
	HC11 *hc11;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemListCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	//##ModelId=3A3D096D0003
	virtual ~CMemListCtrl();

	//##ModelId=3A3D096C03E5
	void Initialize(HC11 *phc11);

	// Generated message map functions
protected:
	//{{AFX_MSG(CMemListCtrl)
	//##ModelId=3A3D096C03E1
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	//##ModelId=3A3D096C03D8
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//##ModelId=3A3D096C03D0
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//##ModelId=3A3D096C03CC
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//##ModelId=3A3D096C03C5
	afx_msg void OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	
	//##ModelId=3A3D096C03BB
	int	HitTestEx(CPoint &point, int *col) const;
	//##ModelId=3A3D096C03B8
	CEdit* EditSubLabel( int nItem, int nCol );

private:
	int rcToAddress(long index, long subItem) const; // dialog-specific physical to logical layout translation
	bool isAddressColumn(long subItem) const;

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMLISTCTRL_H__8D968A60_35E2_11D2_AC60_004033510A08__INCLUDED_)
