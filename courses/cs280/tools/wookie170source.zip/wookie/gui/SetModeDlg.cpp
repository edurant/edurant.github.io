// SetModeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "SetModeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetModeDlg dialog


CSetModeDlg::CSetModeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetModeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetModeDlg)
	m_address = _T("C000");
	m_mode = 0;
	//}}AFX_DATA_INIT
}


void CSetModeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetModeDlg)
	DDX_Text(pDX, IDC_EDIT1, m_address);
	DDV_MaxChars(pDX, m_address, 4);
	DDX_CBIndex(pDX, IDC_COMBO1, m_mode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetModeDlg, CDialog)
	//{{AFX_MSG_MAP(CSetModeDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetModeDlg message handlers

void CSetModeDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}
