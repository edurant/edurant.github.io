// PinGraph.cpp : implementation file
//

#include <math.h>
#include "stdafx.h"
#include "HardCoreWookie.h"
#include "PinGraph.h"
#include "pinchoose.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPinGraph dialog


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CPinGraph constructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
CPinGraph::CPinGraph(HC11 *phc11, CWnd* pParent /*=NULL*/)
	: CDialog(CPinGraph::IDD, pParent)
{        
    Create(IDD_GRAPHDLG, NULL);    
    visible = 0;    
    //{{AFX_DATA_INIT(CPinGraph)
	//}}AFX_DATA_INIT
    attached=false;
    hc11 = phc11;
    scale = 0;

    m_pin = -1;
    m_port = NULL;

    
    m_scale.SetRangeMin(0);
    m_scale.SetRangeMax(10000);
    m_scale.SetTicFreq(1000);

    m_scale.SetPos(((m_scale.GetRangeMax() - m_scale.GetRangeMin())/4) +
                        m_scale.GetRangeMin());    

}


void CPinGraph::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPinGraph)
	DDX_Control(pDX, IDC_PINNAME, m_pinname);
	DDX_Control(pDX, IDC_FREQ, m_freq);
	DDX_Control(pDX, IDC_BUTTON1, m_attach);
	DDX_Control(pDX, IDC_PERIOD, m_period);
	DDX_Control(pDX, IDC_DUTY, m_duty);
	DDX_Control(pDX, IDC_EDIT1, m_mscalestrc);
	DDX_Control(pDX, IDC_SLIDER1, m_scale);
	DDX_Control(pDX, IDC_GRAPH, m_graph);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPinGraph, CDialog)
	//{{AFX_MSG_MAP(CPinGraph)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPinGraph message handlers


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnButton1
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
void CPinGraph::OnButton1() 
{	
    CString pinname;
    // TODO: Add your control notification handler code here
    if(!attached)
    {
        CPinChoose dlg;
        if(dlg.DoModal() == IDOK)
        {
            RECT rect;
            m_graph.GetClientRect(&rect);
            CDC *dc = m_graph.GetDC();         	
            CPen *old_pen = dc->GetCurrentPen();		
	        CPen new_pen;	
            new_pen.CreatePen(PS_SOLID , 1, RGB(0,0,0));	    		
	        dc->SelectObject(&new_pen);    
            dc->FillSolidRect(&rect, RGB(0,0,0));
            dc->SelectObject(&old_pen);
            
            previous_clock = hc11->timer_count;
            switch(dlg.m_port)
            {
                case 0:
                    m_port = &hc11->regfile.PORTA;
                    pinname.Format("PORTA pin %d",dlg.m_pin);
                    break;
                case 1:
                    m_port = &hc11->regfile.PORTB;
                    pinname.Format("PORTB pin %d",dlg.m_pin);
                    break;
                case 2:
                    m_port = &hc11->regfile.PORTC;
                    pinname.Format("PORTC pin %d",dlg.m_pin);
                    break;
                case 3:
                    m_port = &hc11->regfile.PORTD;
                    pinname.Format("PORTD pin %d",dlg.m_pin);
                    break;
            }
            m_pin = dlg.m_pin;
            m_port->Attach(m_pin,this);
            attached=true;
            m_attach.SetWindowText("Unattach");
            m_pinname.SetWindowText(pinname);
        }
    } 
    else
    {        
        m_port->UnAttach(m_pin);
        attached = false;
        m_attach.SetWindowText("Attach");
        m_pinname.SetWindowText("Unattached");
    }         
}

BOOL CPinGraph::OnInitDialog() 
{
	CDialog::OnInitDialog();

    RECT rect;
    m_graph.GetClientRect(&rect);
    pos=rect.left;    
	
    previous_slider_pos = -1;
    previous_level = 0;
    previous_clock = 0;

    return TRUE;  // return TRUE unless you set the focus to a control
}

/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
/* this is all experimental and stuffff i'll comment it later...*/

void CPinGraph::Set(bit_t value)
{        
    int window_size;    
    long ipos;
    CString str;
    
    RECT rect;
    m_graph.GetClientRect(&rect);

    if(previous_slider_pos!=m_scale.GetPos())
    {
        previous_slider_pos=m_scale.GetPos();
        window_size = rect.right - rect.left;
        scale = (float)(m_scale.GetPos() - m_scale.GetRangeMin())/
                            (float)(m_scale.GetRangeMax() - m_scale.GetRangeMin());    
        scale = (double)window_size/(1000000.0*scale + .1);
        
        
        if(scale > 0.0)
            str.Format("%.1fk clocks",(float)((window_size/scale)/1000.0));
        m_mscalestrc.SetWindowText(str);
    }

    tick = (hc11->timer_count-previous_clock)*scale;    
   
    
    CDC *dc = m_graph.GetDC();         	
	CPen *old_pen = dc->GetCurrentPen();		
	CPen new_pen;	
    new_pen.CreatePen(PS_SOLID , 1, RGB(80,255,63));
	dc->SelectObject(&new_pen);
	
    ipos = (int)pos;        
    if((int)(pos+tick)>=rect.right)
    {
        dc->FillSolidRect((int)(pos+1),rect.top,
                        rect.right-(int)pos-1,rect.bottom-rect.top, RGB(0,0,0));
        
        dc->MoveTo(ipos,rect.bottom-previous_level * 50 - 15);            
        pos = rect.left;        
        dc->LineTo(rect.right,rect.bottom-previous_level * 50 - 15);        
        m_graph.UpdateWindow();
    }
    else
    {   
        if((int)(pos+tick)>ipos)
        {
            dc->FillSolidRect((int)(pos+1), rect.top,
                              (int)tick, rect.bottom-rect.top, RGB(0,0,0));

            dc->MoveTo(ipos,rect.bottom-previous_level * 50 - 15);                
            
            pos+=tick;
            ipos = (int)pos;
            dc->LineTo(ipos,rect.bottom-previous_level * 50 - 15);	
            dc->LineTo(ipos,rect.bottom-value *50 - 15);	
            m_graph.UpdateWindow();
        }
    }
            
  	dc->SelectObject(old_pen);        


    if((previous_level == 0) && (value == 1))
    {
        period = hc11->timer_count - period_start;        
        str.Format("%.4fs",(float)period/2000000.0);
        m_period.SetWindowText(str);

        if(period!=0)
        {
            str.Format("%.2f%%",100.0*((float)high_time/(float)period));
            m_duty.SetWindowText(str);

            str.Format("%.3fHz",((float)2000000.0/(float)period));
            m_freq.SetWindowText(str);
        }           
        
        period_start = hc11->timer_count;
    }
    else if((previous_level == 1) && (value == 0))
    {
        high_time = hc11->timer_count - period_start;        
    }

    previous_level = value;
    previous_clock = hc11->timer_count;
}

void CPinGraph::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
    Visible(false);

    if(attached)
    {
        m_port->UnAttach(m_pin);
        attached = false;
        m_attach.SetWindowText("Attach");
    }
}

void CPinGraph::Visible(bool val)
{
    visible = val;

    if(val)
    {
        ShowWindow(true);	    
    }
    else    
        ShowWindow(false);	        
}            
