// ValueDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "ValueDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CValueDlg dialog


CValueDlg::CValueDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CValueDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CValueDlg)
	m_value = _T("");
	m_radio = 0;
	//}}AFX_DATA_INIT
}


void CValueDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CValueDlg)
	DDX_Control(pDX, IDC_VALUE, m_valuectrl);
	DDX_Text(pDX, IDC_VALUE, m_value);
	DDX_Radio(pDX, IDC_RADIO1, m_radio);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CValueDlg, CDialog)
	//{{AFX_MSG_MAP(CValueDlg)
	ON_BN_CLICKED(IDC_RADIO1, OnHex)
	ON_BN_CLICKED(IDC_RADIO2, OnDecimal)
	ON_BN_CLICKED(IDC_RADIO3, OnBinary)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CValueDlg message handlers

void CValueDlg::OnOK() 
{
	// TODO: Add extra validation here       
	CDialog::OnOK();
    int i;
    
    value = -1;    
    switch(m_radio)
    {
        case 0: //hex
				sscanf(m_value.GetBuffer(0),"%x",&value);
                break;
        case 1: //decimal
				sscanf(m_value.GetBuffer(0),"%d",&value);
                break;
        case 2:	//binary			
                value = 0;
                for(i = 0; i<m_value.GetLength();i++)
                {
                    value<<=1;
                    if(m_value[i] == '1')
                        value |= 1;
                    else if(m_value[i] != '0')
                    {
                        value = -1;
                        break;
                    }                    
                }
                break;
    }    
    value_ok = (value>=0 && value<=0xFFFF);
}

void CValueDlg::OnHex() 
{
	// TODO: Add your control notification handler code here
    CString valstr;
    int value;
    int i;
    
    switch(m_radio)
    {
        case 1:
            m_valuectrl.GetWindowText(valstr);            
            sscanf(valstr.GetBuffer(0),"%d",&value);            
            valstr.Format("%X",value);
            m_valuectrl.SetWindowText(valstr);            
            break;
        case 2:
            m_valuectrl.GetWindowText(valstr);            
            value = 0;
            for(i = 0; i<valstr.GetLength();i++)
            {
                value<<=1;
                if(valstr[i] == '1')
                    value |= 1;
                else if(valstr[i] != '0')
                {
                    value = -1;
                    break;
                }                    
            }
            valstr.Format("%X",value);
            m_valuectrl.SetWindowText(valstr);                 
            break;
    }

    m_radio = 0;
	
}

void CValueDlg::OnDecimal() 
{
	// TODO: Add your control notification handler code here
    CString valstr;
    int value;
    int i;
    
    switch(m_radio)
    {
        case 0:
            m_valuectrl.GetWindowText(valstr);            
            sscanf(valstr.GetBuffer(0),"%x",&value);            
            valstr.Format("%d",value);
            m_valuectrl.SetWindowText(valstr);            
            break;
        case 2:
            m_valuectrl.GetWindowText(valstr);            
            value = 0;
            for(i = 0; i<valstr.GetLength();i++)
            {
                value<<=1;
                if(valstr[i] == '1')
                    value |= 1;
                else if(valstr[i] != '0')
                {
                    value = -1;
                    break;
                }                    
            }
            valstr.Format("%d",value);
            m_valuectrl.SetWindowText(valstr);                 
            break;
    }

    m_radio = 1;
}

void CValueDlg::OnBinary() 
{
	// TODO: Add your control notification handler code here
    CString valstr;
    int value;
    int i;
    
    switch(m_radio)
    {
        case 0:
            m_valuectrl.GetWindowText(valstr);            
            sscanf(valstr.GetBuffer(0),"%x",&value);            
            valstr = "00000000";                              
            for(i=0;i<8;i++)	                
                valstr.SetAt(7-i,(value&(1<<i)) ? '1' : '0');	                        
            m_valuectrl.SetWindowText(valstr);            
            break;
        case 1:
            m_valuectrl.GetWindowText(valstr);            
            sscanf(valstr.GetBuffer(0),"%d",&value);            
            valstr = "00000000";                              
            for(i=0;i<8;i++)	                
                valstr.SetAt(7-i,(value&(1<<i)) ? '1' : '0');	                        
            m_valuectrl.SetWindowText(valstr);            
            break;
    }

    m_radio = 2;
}
