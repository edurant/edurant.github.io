#if !defined(AFX_MEMORYWATCH_H__AC3EAF53_9122_11D1_BF13_0000C0EB65E5__INCLUDED_)
#define AFX_MEMORYWATCH_H__AC3EAF53_9122_11D1_BF13_0000C0EB65E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MemoryWatch.h : header file
//
#include "../emu/hc11.h"


//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CMemoryWatch
//
// Author: Kalle Anderson
//
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CMemoryWatch dialog

//##ModelId=3A3D096A02A7
class CMemoryWatch : public CDialog
{
// Construction
    // Check to see if it should be updated
	//##ModelId=3A3D096A02E3
    bool visible;
    
    // pointer to the hc11
	//##ModelId=3A3D096A02DB
    HC11 *hc11;
public:
    enum base_value
    {
        hex_base,
        decimal_base,
        binary_base
    };

	//##ModelId=3A3D096A031F
	CMemoryWatch(HC11 *phc11, CWnd* pParent = NULL);   // standard constructor
    // reread the values
	//##ModelId=3A3D096A0318
    void Update(void);
    // list of the addresses
	//##ModelId=3A3D096A02D3
    list<word_t> watches;

    base_value numerical_base;
    
    // Hide or show this window
	//##ModelId=3A3D096A030E
    void Visible(bool val);
	//##ModelId=3A3D096A0316
    bool Visible(void){return visible;};    

    // Add a watch
	//##ModelId=3A3D096A030B
    void AddWatch(CString name, word_t address);
    // Clear them all
	//##ModelId=3A3D096A0303
    void ClearWatches(void);

// Dialog Data
	//{{AFX_DATA(CMemoryWatch)
	enum { IDD = IDD_MEMWATCH };
	//##ModelId=3A3D096A02C5
	CButton	m_delete;
	//##ModelId=3A3D096A02B3
	CButton	m_add;
	//##ModelId=3A3D096A02AB
	CListCtrl	m_listctrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemoryWatch)
	protected:
	//##ModelId=3A3D096A02FC
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMemoryWatch)
	//##ModelId=3A3D096A02FA
	afx_msg void OnAddwatch();
	//##ModelId=3A3D096A02F8
	afx_msg void OnDeletewatch();
	//##ModelId=3A3D096A02F2
	afx_msg void OnUpdate();
	//##ModelId=3A3D096A02F0
	virtual void OnOK();
	//##ModelId=3A3D096A02EE
	afx_msg void OnModify();
	//##ModelId=3A3D096A02E4
	afx_msg void OnBase();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CRegisterWatch
//
// Author: Kalle Anderson
//
// Purpose: A static memory watch containing just registers.
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D096C0209
class CRegisterWatch: public CMemoryWatch 
{
    public:
	//##ModelId=3A3D096C020B
        CRegisterWatch(HC11 *phc11, CWnd* pParent = NULL);               
protected:
	//{{AFX_MSG(CRegisterWatch)

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMORYWATCH_H__AC3EAF53_9122_11D1_BF13_0000C0EB65E5__INCLUDED_)
