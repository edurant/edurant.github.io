#if !defined(AFX_LSTFILEDLG_H__1231BA60_B630_11D2_AC60_004033510A08__INCLUDED_)
#define AFX_LSTFILEDLG_H__1231BA60_B630_11D2_AC60_004033510A08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LstFileDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLstFileDlg dialog

//##ModelId=3A3D096C01D7
class CLstFileDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096C01E5
	CLstFileDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLstFileDlg)
	enum { IDD = IDD_LSTFILE };
	//##ModelId=3A3D096C01E1
	int		m_filetype;
	//##ModelId=3A3D096C01D9
	CString	m_startingaddr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLstFileDlg)
	protected:
	//##ModelId=3A3D096C01E2
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLstFileDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LSTFILEDLG_H__1231BA60_B630_11D2_AC60_004033510A08__INCLUDED_)
