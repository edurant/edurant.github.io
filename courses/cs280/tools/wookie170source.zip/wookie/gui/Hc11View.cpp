////////////////////////////////////////////////////////////////////////////////
// File Name:       Hc11View.cpp
// Description:     implementation file
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/14/2001  Jake & Dainen   Added implementation for the OnKeypad event.
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HardCoreWookie.h"
#include "Hc11View.h"
#include "HardCoreWookieDoc.h"
#include "PortIO.h"
#include "PinGraph.h"
#include "CodeViewerDlg.h"
#include "../emu/hc11.h"
#include <string.h>
#include "direct.h"  //addendum


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int StringToHex(CString s1);

/////////////////////////////////////////////////////////////////////////////
// CHc11View

IMPLEMENT_DYNCREATE(CHc11View, CFormView)

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CHc11View constructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions:
//
// Post Conditions:
//
/////////////////////////////////////////////////////////////////////////////
CHc11View::CHc11View()
	: CFormView(CHc11View::IDD)
{
	//{{AFX_DATA_INIT(CHc11View)
	m_breakp = _T("");
	//}}AFX_DATA_INIT
    m_pADlg=NULL;

    stepbmp.LoadBitmap(IDB_STEP);
    runningbmp.LoadBitmap(IDB_GREENLIGHT);
    stoppedbmp.LoadBitmap(IDB_REDLIGHT);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CHc11View destructor
//
// Author: Kalle Anderson
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions:
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/14/2001  Jake & Dainen   Added deletion of the keypad upon destruction.
//  01/14/2001  Jake & Dainen   Fixed defect: Was not freeing 7 seg, mem browse,
//                              and code view members.
/////////////////////////////////////////////////////////////////////////////
CHc11View::~CHc11View()
{
	delete m_pADlg;
	delete m_pBDlg;
	delete m_pCDlg;
	delete m_pDDlg;
	delete m_pEDlg;
	delete m_pWatch;
	delete m_pRegWatch;
	delete m_pMCUDlg;
    delete m_pGraphDlg;
    delete m_pKeypad;
    delete m_p7seg;
    delete m_pMemBrowse;
    delete m_pCodeView;
}

void CHc11View::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHc11View)
	DDX_Control(pDX, IDC_BPEDIT, m_bpctrl);
	DDX_Control(pDX, IDC_STEP, m_stepctrl);
	DDX_Control(pDX, IDC_RUN, m_runctrl);
	DDX_Control(pDX, IDC_XIRQ, m_xirqctrl);
	DDX_Control(pDX, IDC_IRQ, m_irqctrl);
	DDX_Text(pDX, IDC_BPEDIT, m_breakp);
	DDV_MaxChars(pDX, m_breakp, 4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHc11View, CFormView)
	ON_MESSAGE(WM_THREAD_STOP, OnThreadStop)
	//{{AFX_MSG_MAP(CHc11View)
	ON_BN_CLICKED(IDC_MEMORY, OnMemoryClick)
	ON_BN_CLICKED(IDC_CPU, OnCpuClick)
	ON_BN_CLICKED(IDC_PORTA, OnPortAClick)
	ON_BN_CLICKED(IDC_PORTB, OnPortBClick)
	ON_BN_CLICKED(IDC_PORTC, OnPortCClick)
	ON_BN_CLICKED(IDC_PORTD, OnPortDClick)
	ON_BN_CLICKED(IDC_PORTE, OnPortEClick)
	ON_BN_CLICKED(IDC_MEMORYW, OnMemoryWatch)
	ON_BN_CLICKED(IDC_REGS, OnRegs)
	ON_BN_CLICKED(IDC_IRQ, OnIrq)
	ON_BN_CLICKED(IDC_XIRQ, OnXirq)
	ON_BN_CLICKED(IDC_Reset, OnReset)
	ON_BN_CLICKED(IDC_RUN, OnRun)
	ON_BN_CLICKED(IDC_STEP, OnStep)
	ON_EN_CHANGE(IDC_BPEDIT, OnChangeBpedit)
	ON_BN_CLICKED(IDC_GRAPHTEST, OnGraphtest)
	ON_BN_CLICKED(IDC_GO7SEG, OnGo7seg)
	ON_BN_CLICKED(IDC_VIEWCODE, OnViewCode)
	ON_BN_CLICKED(IDC_KEYPAD, OnKeypad)
	ON_COMMAND(ID_FILE_LOADWINDOWSETTINGS, OnLoadWinSettings)
	ON_COMMAND(ID_FILE_SAVEWINDOWSETTINGS, OnSaveWinSettings)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHc11View diagnostics

#ifdef _DEBUG
void CHc11View::AssertValid() const
{
	CFormView::AssertValid();
}

void CHc11View::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHc11View message handlers
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnMemoryClick
//
// Author: Matt Enwald
//
// Purpose: 
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions:
//
// Post Conditions:
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnMemoryClick() 
{
	m_pMemBrowse->Visible(1);
/*
	// Create a new Memory box
	CMemoryDlg* pDlg = new CMemoryDlg;

	// Keep displaying Memory box until the user hits cancel
	while (pDlg->DoModal() == IDOK)
	{
		// The user has pressed OK
		//
		// If the radio button is on SET
		if (pDlg->m_setordisplay == SET)
		{
			// Convert the text in the memory display box from hex to an int
			int memory = StringToHex(pDlg->m_memoryDisplay);
			// For each byte that needs to be written to
			for (int i = 0; i < pDlg->numofbytes; i++)
			{
				// Write the current memory to the correct address
				if (pDlg->m_numericBase == "Octal")
				{
					((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory.Write(pDlg->startaddy+i,memory);
				}
				else if (pDlg->m_numericBase == "Decimal")
				{
					((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory.Write(pDlg->startaddy+i,memory);
				}
				else if (pDlg->m_numericBase == "Hex")
				{
					((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory.Write(pDlg->startaddy+i,memory);
				}
			}
		}
		// If the radio button is on DISPLAY
		else if (pDlg->m_setordisplay == DISPLAY)
		{
			// Clear the memory display box
			pDlg->m_memoryDisplay = "";
			CString buffer = pDlg->m_memoryDisplay;
			// For each byte that needs to be read in
			for (int i = 0; i < pDlg->numofbytes; i++)
			{
				// Add the byte in its correct format to the memory display
				if (pDlg->m_numericBase == "Octal")
				{
					buffer.Format("%02o",((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory[pDlg->startaddy+i]);
				}
				else if (pDlg->m_numericBase == "Decimal")
				{
					buffer.Format("%03d",((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory[pDlg->startaddy+i]);
				}
				else if (pDlg->m_numericBase == "Hex")
				{
					buffer.Format("%02x",((CHardCoreWookieDoc *)GetDocument())->hc11sim.hc11.memory[pDlg->startaddy+i]);
				}
				pDlg->m_memoryDisplay = pDlg->m_memoryDisplay + buffer + " ";
			}
		}
	}
	delete pDlg;
*/
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnCpuClick
//
// Author: Kalle Anderson
//
// Purpose: To show the CPU Dialog
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions:
//
// Post Conditions:
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnCpuClick() 
{

    m_pMCUDlg->Visible(true); 
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnPortAClick
//
// Author: Kalle Anderson
//
// Purpose: To display Port A
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: Port A has been created.
//
// Post Conditions: Port A is visible
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnPortAClick() 
{
    m_pADlg->Visible(1);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnPortAClick
//
// Author: Kalle Anderson
//
// Purpose: To display Port B
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: Port B has been created.
//
// Post Conditions: Port B is visible
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnPortBClick() 
{
	m_pBDlg->Visible(1);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnPortAClick
//
// Author: Kalle Anderson
//
// Purpose: To display Port C
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: Port C has been created.
//
// Post Conditions: Port C is visible
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnPortCClick() 
{
	m_pCDlg->Visible(1);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnPortAClick
//
// Author: Kalle Anderson
//
// Purpose: To display Port D
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: Port D has been created.
//
// Post Conditions: Port D is visible
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnPortDClick() 
{
    m_pDDlg->Visible(1);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnPortAClick
//
// Author: Kalle Anderson
//
// Purpose: To display Port E
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: Port E has been created.
//
// Post Conditions: Port E is visible
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnPortEClick() 
{
	m_pEDlg->Visible(1);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnInitialUpdate
//
// Author: Kalle Anderson and Matt Enwald
//
// Purpose: To initialize the program when loaded
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: CDocument class is ready to go
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/14/2001  Jake & Dainen   Added initialization of the keypad class.
//  01/28/2001  Jake & Blake    Added passing the HC11 pointer to the keypad.
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();    	
	
	// Get the hc11 from the Document class
    HC11 *hc11 = &((CHardCoreWookieDoc*)GetDocument())->hc11sim.hc11;
	// Set the member variable in the Doc to this so that the Doc can access the View
    ((CHardCoreWookieDoc*)GetDocument())->m_pHc11View = this;	
	// Set the member variable in the Doc to a handle to this - used in Multithreading
    ((CHardCoreWookieDoc*)GetDocument())->m_hwndHc11View = m_hWnd;	
	// This only get initialized once per HC11Wookie.exe execution
    if(m_pADlg==NULL)   
    {
		// Create and set the window placement for all the popup windows.
		// After this, the popup windows will only be hidden and made visible
		// and finally destroyed when the HC11Wookie.exe is exited
        m_pADlg = new CPortIO(&hc11->regfile.PORTA,"Port A");
		WINDOWPLACEMENT wndpl;
		m_pADlg->GetWindowPlacement(&wndpl);
		wndpl.rcNormalPosition.left += 400;
		wndpl.rcNormalPosition.right += 400;
		m_pADlg->SetWindowPlacement(&wndpl);
        m_pADlg->Visible(0);

        m_pBDlg = new CPortIO(&hc11->regfile.PORTB,"Port B");	
		wndpl.rcNormalPosition.top += 105;
		wndpl.rcNormalPosition.bottom += 105;
		m_pBDlg->SetWindowPlacement(&wndpl);
        m_pBDlg->Visible(0);

        m_pCDlg = new CPortIO(&hc11->regfile.PORTC,"Port C");	
		wndpl.rcNormalPosition.top += 105;
		wndpl.rcNormalPosition.bottom += 105;
		m_pCDlg->SetWindowPlacement(&wndpl);
        m_pCDlg->Visible(0);

        m_pDDlg = new CPortIO(&hc11->regfile.PORTD,"Port D");	
		wndpl.rcNormalPosition.top += 105;
		wndpl.rcNormalPosition.bottom += 105;
		m_pDDlg->SetWindowPlacement(&wndpl);
        m_pDDlg->Visible(0);

        m_pEDlg = new CPortIO(&hc11->regfile.PORTE,"Port E");	        
		wndpl.rcNormalPosition.top += 105;
		wndpl.rcNormalPosition.bottom += 105;
        m_pEDlg->SetWindowPlacement(&wndpl);
        m_pEDlg->Visible(0);     

        m_pWatch = new CMemoryWatch(hc11);	        
        m_pRegWatch = new CRegisterWatch(hc11);	   
        m_pMCUDlg = new CMCUDlg(hc11);	   

        m_pWatch->Visible(0); 	    
        m_pRegWatch->Visible(0);
        m_pMCUDlg->Visible(0); 

        m_pGraphDlg = new CPinGraph(hc11);
        m_pGraphDlg->Visible(0);
        
        m_stepctrl.SetBitmap(stepbmp);
        m_runctrl.SetBitmap(stoppedbmp);    

        m_p7seg = new C7SegDlg(hc11);       
        m_p7seg->Visible(0);       

        m_pKeypad = new CKeypadDlg(hc11);
        m_pKeypad->Create(IDD_KEYPAD, this);
        m_pKeypad->Visible(0);

       	m_pMemBrowse = new CMemoryBrowseDlg(hc11);
		m_pMemBrowse->Visible(0);

		m_pCodeView = new CCodeViewerDlg(hc11);
		m_pCodeView->Visible(0);	
   }       
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnMemoryWatch
//
// Author: Kalle Anderson
//
// Purpose: To make the memory watch visible
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: MemoryWatch popup window has already been created
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnMemoryWatch() 
{
	m_pWatch->Visible(1); 	    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Update
//
// Author: Kalle Anderson
//
// Purpose: To refresh all contents of the screen that are visible. This does
//          not get called while the worker thread is stepping the HC11, because
//          it bogs stuff down too much. 
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the call to update the three multidirectional
//                              ports' labels when the ports are visible.
//  01/28/2001  Jake & Blake    Added the call to update the 7 segment display.
//  01/28/2001  Jake & Blake    Added the UpdateDisplay call to the keypad.
/////////////////////////////////////////////////////////////////////////////
void CHc11View::Update(void) 
{
    HC11 *hc11 = &((CHardCoreWookieDoc*)GetDocument())->hc11sim.hc11;
    if(m_pWatch->Visible())
        m_pWatch->Update();
    if(m_pRegWatch->Visible())
        m_pRegWatch->Update();
    if(m_pMCUDlg->Visible())
        m_pMCUDlg->Update();
    if(m_pMemBrowse->Visible())
        m_pMemBrowse->Update();
    
    if (m_pADlg->Visible())
    {
        m_pADlg->UpdateDirectionLabels();
    }
    
    if (m_pCDlg->Visible())
    {
        m_pCDlg->UpdateDirectionLabels();
    }
    
    if (m_pDDlg->Visible())
    {
        m_pDDlg->UpdateDirectionLabels();
    }

    if (m_p7seg->Visible())
    {
        m_p7seg->Update();
    }

    if (m_pKeypad->Visible())
    {
        m_pKeypad->UpdateDisplay();
    }
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnRegs
//
// Author: Kalle Anderson
//
// Purpose: Make the RegisterWatch visible.
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnRegs() 
{
	m_pRegWatch->Visible(1); 	    	
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnIrq
//
// Author: Kalle Anderson
//
// Purpose: Toggle the IRQ pin in the simulator. 
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions:
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnIrq() 
{
    HC11 *hc11 = &((CHardCoreWookieDoc*)GetDocument())->hc11sim.hc11;
	hc11->IRQLevel(!m_irqctrl.GetCheck());
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnXirq
//
// Author: Kalle Anderson
//
// Purpose: Toggle the XIRQ pin in the simulator.
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnXirq() 
{
    HC11 *hc11 = &((CHardCoreWookieDoc*)GetDocument())->hc11sim.hc11;
    hc11->XIRQLevel(!m_xirqctrl.GetCheck());
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnReset
//
// Author: Kalle Anderson
//
// Purpose: Reset the hc11, if it is not running.
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnReset() 
{
    if(!((CHardCoreWookieDoc*)GetDocument())->m_isrunning)
    {
        ((CHardCoreWookieDoc*)GetDocument())->hc11sim.hc11.Reset();
        Update();
    }
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnRun
//
// Author: Kalle Anderson
//
// Purpose: This is the button to toggle the "all-out" stepping of the hc11
//          by the worker thread.
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnRun() 
{
    CHardCoreWookieDoc *pDoc = (CHardCoreWookieDoc*)GetDocument();

    if(pDoc->m_isrunning)
    {
        pDoc->m_isrunning = 0;                          
        //This will cause the worker thread to fall out of its stepping loop.
        //It will notify the view when it has done so, then pause itself
        //by waiting for the THREAD_GO event.
    }
    else
    {
        // only start the thread if there is a file open
//        if(pDoc->m_pCodeView->m_isFileOpen)
//        {
            // Toggel the ren light to a green light
            m_runctrl.SetBitmap(runningbmp);    
            // disable the step button
            m_stepctrl.EnableWindow(false);
            // disable the breakpoint edit control
            m_bpctrl.EnableWindow(false);
            // call the doc to start the thread
            pDoc->SimGO();
//        }
    }    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnStep
//
// Author: Kalle Anderson
//
// Purpose: To step the HC11 through one instruction
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the call to OnCodeStep after the step.
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnStep() 
{
    ((CHardCoreWookieDoc*)GetDocument())->OnSimmulatorStep();           	
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnThreadStop
//
// Author: Kalle Anderson
//
// Purpose: When the simulator falls out of it's stepping loop, it sends
//          a WM_THREAD_STOP message indicating that it is no longer
//          stepping the hc11 class. Then this will tell the doc to
//          do its stuff, and reenable a few buttons too.
//
// Input Parameters: None
//
// Return Value: LRESULT - always zero
//
// Preconditions: None
//
// Post Conditions: Interface displays that the simulator is stopped
//
/////////////////////////////////////////////////////////////////////////////
LRESULT CHc11View::OnThreadStop(WPARAM, LPARAM)
{    
    
    ((CHardCoreWookieDoc*)GetDocument())->SimSTOP();
    // make the green light red
    m_runctrl.SetBitmap(stoppedbmp);    
    // enable the step button
    m_stepctrl.EnableWindow(true);
    // enable the breakpoint edit control
    m_bpctrl.EnableWindow(true);
    return 0;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnChangeBpedit
//
// Author: Kalle Anderson
//
// Purpose: Input the breakpoint for the simulator. This gets called every time
//          a character is typed into the breakpoint box. If the box is empty
//          or what is typed in is invalid, the breakpoint will be set to -1
//          
//
// Input Parameters: none
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnChangeBpedit() 
{		
    int address=-1;
    CString str;
    m_bpctrl.GetWindowText(str);               
        
    if(str.GetLength()>0)
    {        
        sscanf(str.GetBuffer(0),"%x",&address);    
        if((address >=0)&&(address<=0xFFFF)) 
            ((CHardCoreWookieDoc*)GetDocument())->m_breakpoint = address;		
        else 
            ((CHardCoreWookieDoc*)GetDocument())->m_breakpoint = -1;
    }
    else ((CHardCoreWookieDoc*)GetDocument())->m_breakpoint = -1;

}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: StringToHex
//
// Author: Matt Enwald and Paul Clarke
//
// Purpose: To convert a CString hex number to an int
//
// Input Parameters: CString s1 - the CString that represents a hex value
//
// Return Value: int - the hex value
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
int StringToHex(CString s1)
{
	int num1;
	int num2;

	s1.MakeUpper();

	if (s1[0]>='A')
		num1 = (s1[0] - 'A' + 10) * 16;
	else
		num1 = (s1[0] - '0') * 16;

	if (s1[1] >='A')
		num2 = (s1[1] - 'A' + 10);
	else
		num2 = (s1[1] - '0');
	return (num1+num2);
}



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnGraphTest
//
// Author: Kalle Anderson
//
// Purpose: Starts up the "experimental" pin graph.
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnGraphtest() 
{

    m_pGraphDlg->Visible(true);   
}

void CHc11View::OnGo7seg() 
{
	// TODO: Add your control notification handler code here
	m_p7seg->Visible(true);
}

void CHc11View::OnViewCode() 
{
	// TODO: Add your control notification handler code here
	m_pCodeView->Visible(true);	
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnKeypad
// Scope:           CHc11View
// Return Value:    <none>
// Usage:           Event handler for pressing IDC_KEYPAD.
// Pre-Conditions:  OnInitialUpdate must have been called and successfully created
//                  the keypad dialog member.
// Post-Conditions: The keypad should be displayed.
// Description:     Makes the keypad tool window visible.
//
// Author:          Jake & Dainen
// Created:         01/14/2001 14:42:24
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CHc11View::OnKeypad() 
{
	m_pKeypad->Visible(true);
}

// Addendum
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnLoadWinSettings
//
// Author: Craig Irving
//
// Purpose: To load window placement settings from .ini file
//
// Input Parameters: None
//
// Return Value:  Window settings
//
// Preconditions:  Window configuration ini file exists
//
// Post Conditions:  Windows position and visibility set
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnLoadWinSettings()
{
	// set data types for string
	CString cs_IniFormat = "%ld,%ld,%ld,%d,%d,%d,%d,%d,%d,%d,%d,%d";  
	CString strRegASet;
	CString strRegBSet;
	CString strRegCSet;
	CString strRegDSet;
	CString strRegESet;
	CString strMemWatch;
	CString strRegWatch;
	CString strMCUDlg;
	CString strPinGraph;
	CString str7Seg;
	CString strKeyPad;
	CString strMemBrowse;
	CString strCodeView;
	bool visible = 0;

	CFile inifile;
	
	CFileDialog iniLoadDlg(TRUE, NULL, NULL, NULL, "ini Files(*.ini)|*.ini||");

	//Implement CWD
	char buffer[_MAX_PATH];
	_getcwd(buffer, _MAX_PATH);
	iniLoadDlg.m_ofn.lpstrTitle = "Load Window Configuration";
	iniLoadDlg.m_ofn.lpstrInitialDir = buffer;

	if (iniLoadDlg.DoModal() == IDOK)
	{
		if(inifile.Open(iniLoadDlg.GetFileName(), CFile::modeRead) == FALSE )
			return;
		
		//Load data into strings
		CArchive ar(&inifile, CArchive::load);
		ar >> strRegASet >> strRegBSet >> strRegCSet >> strRegDSet >> strRegESet
			>> strMemWatch >> strRegWatch >> strMCUDlg >> strPinGraph >> str7Seg
			>> strKeyPad >> strMemBrowse >> strCodeView;
		ar.Close();
	}

	else
		return;

		inifile.Close();
	
	//Set window configurations
	WINDOWPLACEMENT wndpl;
	if (!strRegASet.IsEmpty())
	{
		sscanf(strRegASet, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pADlg->SetWindowPlacement(&wndpl);
		m_pADlg->Visible(visible);
	}

	if (!strRegBSet.IsEmpty())
	{
		sscanf(strRegBSet, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pBDlg->SetWindowPlacement(&wndpl);
		m_pBDlg->Visible(visible);
	}

	if (!strRegCSet.IsEmpty())
	{
		sscanf(strRegCSet, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pCDlg->SetWindowPlacement(&wndpl);
		m_pCDlg->Visible(visible);
	}

	if (!strRegDSet.IsEmpty())
	{
		sscanf(strRegDSet, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pDDlg->SetWindowPlacement(&wndpl);
		m_pDDlg->Visible(visible);
	}

	if (!strRegESet.IsEmpty())
	{
		sscanf(strRegESet, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pEDlg->SetWindowPlacement(&wndpl);
		m_pEDlg->Visible(visible);
	}

	if (!strMemWatch.IsEmpty())
	{
		sscanf(strMemWatch, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pWatch->SetWindowPlacement(&wndpl);
		m_pWatch->Visible(visible);
	}

	if (!strRegWatch.IsEmpty())
	{
		sscanf(strRegWatch, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pRegWatch->SetWindowPlacement(&wndpl);
		m_pRegWatch->Visible(visible);
	}

	if (!strMCUDlg.IsEmpty())
	{
		sscanf(strMCUDlg, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pMCUDlg->SetWindowPlacement(&wndpl);
		m_pMCUDlg->Visible(visible);
	}

	if (!strPinGraph.IsEmpty())
	{
		sscanf(strPinGraph, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pGraphDlg->SetWindowPlacement(&wndpl);
		m_pGraphDlg->Visible(visible);
	}

	if (!str7Seg.IsEmpty())
	{
		sscanf(str7Seg, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_p7seg->SetWindowPlacement(&wndpl);
		m_p7seg->Visible(visible);
	}

	if (!strKeyPad.IsEmpty())
	{
		sscanf(strKeyPad, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pKeypad->SetWindowPlacement(&wndpl);
		m_pKeypad->Visible(visible);
	}

	if (!strMemBrowse.IsEmpty())
	{
		sscanf(strMemBrowse, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pMemBrowse->SetWindowPlacement(&wndpl);
		m_pMemBrowse->Visible(visible);
	}

	if (!strCodeView.IsEmpty())
	{
		sscanf(strCodeView, cs_IniFormat, 
			&wndpl.flags,
            &wndpl.length,
            &wndpl.showCmd,
            &wndpl.ptMaxPosition.x,
            &wndpl.ptMaxPosition.y,
            &wndpl.ptMinPosition.x,
            &wndpl.ptMinPosition.y,
            &wndpl.rcNormalPosition.left, 
            &wndpl.rcNormalPosition.top, 
            &wndpl.rcNormalPosition.right,
            &wndpl.rcNormalPosition.bottom,
			&visible);

		m_pCodeView->SetWindowPlacement(&wndpl);
		m_pCodeView->Visible(visible);
	}

}

// Addendum
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnSaveWinSettings
//
// Author: Craig Irving
//
// Purpose: To save window placement settings to an .ini file
//
// Input Parameters: Window settings
//
// Return Value: None.
//
// Preconditions: Windows initialized
//
// Post Conditions: Window settings stored in ini file
//
/////////////////////////////////////////////////////////////////////////////
void CHc11View::OnSaveWinSettings()
{
	// set data types for string
	CString cs_IniFormat = "%ld,%ld,%ld,%d,%d,%d,%d,%d,%d,%d,%d,%d";  
	CString strRegASet;
	CString strRegBSet;
	CString strRegCSet;
	CString strRegDSet;
	CString strRegESet;
	CString strMemWatch;
	CString strRegWatch;
	CString strMCUDlg;
	CString strPinGraph;
	CString str7Seg;
	CString strKeyPad;
	CString strMemBrowse;
	CString strCodeView;
	bool visible;

	CFile inifile;

	CFileDialog iniSaveDlg(FALSE, "*.ini", NULL, OFN_OVERWRITEPROMPT,
		"ini Files(*.ini)|*.ini||", NULL);

	//ImplementCWD
	char buffer[_MAX_PATH];
	_getcwd(buffer, _MAX_PATH);
	iniSaveDlg.m_ofn.lpstrTitle = "Save Window Configuration";
	iniSaveDlg.m_ofn.lpstrInitialDir = buffer;

	//Get window settings
	WINDOWPLACEMENT wndpl;
	if (m_pADlg && m_pADlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pADlg->Visible();
        strRegASet.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pBDlg && m_pBDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pBDlg->Visible();
        strRegBSet.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pCDlg && m_pCDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pCDlg->Visible();
        strRegCSet.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pDDlg && m_pDDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pDDlg->Visible();
        strRegDSet.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pEDlg && m_pEDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pEDlg->Visible();
        strRegESet.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pWatch && m_pWatch->GetWindowPlacement(&wndpl))
	{
		visible = m_pWatch->Visible();
        strMemWatch.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pRegWatch && m_pRegWatch->GetWindowPlacement(&wndpl))
	{
		visible = m_pRegWatch->Visible();
        strRegWatch.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pMCUDlg && m_pMCUDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pMCUDlg->Visible();
        strMCUDlg.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pGraphDlg && m_pGraphDlg->GetWindowPlacement(&wndpl))
	{
		visible = m_pGraphDlg->Visible();
        strPinGraph.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_p7seg && m_p7seg->GetWindowPlacement(&wndpl))
	{
		visible = m_p7seg->Visible();
        str7Seg.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pKeypad && m_pKeypad->GetWindowPlacement(&wndpl))
	{
		visible = m_pKeypad->Visible();
        strKeyPad.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pMemBrowse && m_pMemBrowse->GetWindowPlacement(&wndpl))
	{
		visible = m_pMemBrowse->Visible();
        strMemBrowse.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}

	if (m_pCodeView && m_pCodeView->GetWindowPlacement(&wndpl))
	{
		visible = m_pCodeView->Visible();
        strCodeView.Format(cs_IniFormat, 
			wndpl.flags,
            wndpl.length,
            wndpl.showCmd,
            wndpl.ptMaxPosition.x,
            wndpl.ptMaxPosition.y,
            wndpl.ptMinPosition.x,
            wndpl.ptMinPosition.y,
            wndpl.rcNormalPosition.left, 
            wndpl.rcNormalPosition.top, 
            wndpl.rcNormalPosition.right,
            wndpl.rcNormalPosition.bottom,
			visible);
	}
		//Store data to ini file 
		if (iniSaveDlg.DoModal() == IDOK)
		{
			inifile.Open(iniSaveDlg.GetFileName(), 
				CFile::modeCreate | CFile::modeWrite);
			CArchive ar(&inifile, CArchive::store);
			ar << strRegASet << strRegBSet << strRegCSet << strRegDSet << strRegESet
				<< strMemWatch << strRegWatch << strMCUDlg << strPinGraph << str7Seg
				<< strKeyPad << strMemBrowse << strCodeView << visible;
			ar.Close();
		}
		else
			return;

		inifile.Close();
	
}
