#if !defined(AFX_SETMODEDLG_H__B0E15AC3_96A6_11D1_BF1D_0000C00266E5__INCLUDED_)
#define AFX_SETMODEDLG_H__B0E15AC3_96A6_11D1_BF1D_0000C00266E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SetModeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetModeDlg dialog

//##ModelId=3A3D096E0021
class CSetModeDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096E0035
	CSetModeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetModeDlg)
	enum { IDD = IDD_MODECONFIG };
	//##ModelId=3A3D096E002B
	CString	m_address;
	//##ModelId=3A3D096E0023
	int		m_mode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetModeDlg)
	protected:
	//##ModelId=3A3D096E002E
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetModeDlg)
	//##ModelId=3A3D096E002C
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETMODEDLG_H__B0E15AC3_96A6_11D1_BF1D_0000C00266E5__INCLUDED_)
