// CodeViewerDlg.cpp : implementation file

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "CodeViewerDlg.h"
#include "LstFileDlg.h"
#include "ctrlext.h"
#include "direct.h"  //addendum

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCodeViewerDlg dialog

#pragma warning (push, 4)

CCodeViewerDlg::CCodeViewerDlg(HC11 *_hc11, CWnd* pParent /*=NULL*/)
	: CDialog(CCodeViewerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCodeViewerDlg)
	//}}AFX_DATA_INIT

	hc11 = _hc11;	
	visible = 0;
    Create(IDD_CODEVIEW, NULL);    
}


void CCodeViewerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCodeViewerDlg)
	DDX_Control(pDX, IDC_BUTTON1, m_loadb);
	DDX_Control(pDX, IDC_BUTTON2, m_clearb);
	DDX_Control(pDX, IDOK, m_okb);
	DDX_Control(pDX, IDC_LIST, m_listctrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCodeViewerDlg, CDialog)
	//{{AFX_MSG_MAP(CCodeViewerDlg)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON1, OnLoadLst)
	ON_BN_CLICKED(IDC_BUTTON2, OnClear)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCodeViewerDlg message handlers

void CCodeViewerDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	RECT rect;
	int w;

	if(m_listctrl.m_hWnd)
	{
		m_listctrl.MoveWindow(10, 10, cx - 20, cy - 50);

		m_loadb.GetClientRect(&rect);				
		rect.top = cy - 10 - rect.bottom - rect.top;		
		rect.bottom = cy - 10;					
		rect.right = 10 + (rect.right - rect.left);
		rect.left = 10;		
		m_loadb.MoveWindow(&rect);

		m_clearb.GetClientRect(&rect);				
		rect.top = cy - 10 - rect.bottom - rect.top;		
		rect.bottom = cy - 10;					
		w = (rect.right - rect.left)/2;
		rect.right = cx/2 + w;
		rect.left = cx/2 - w;		
		m_clearb.MoveWindow(&rect);

		m_okb.GetClientRect(&rect);		
		rect.top = cy - 10 - rect.bottom - rect.top;
		rect.bottom = cy - 10;		
		rect.left = cx - 10 - (rect.right - rect.left);		
		rect.right = cx  - 10;				
		m_okb.MoveWindow(&rect);	

		m_listctrl.GetClientRect(&rect);
		m_listctrl.SetColumnWidth(0, rect.right - rect.left);
	}						
}

void CCodeViewerDlg::Visible(bool val)
{
    visible = val;

    if(val)
    {
        ShowWindow(true);	            
    }
    else    
        ShowWindow(false);	        	
}            


void CCodeViewerDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	Visible(0);	
}

void CCodeViewerDlg::AddLine(const char *txt, int address)
{
	CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;
	char txt2[256];

	// I couldn't figure how to make the list control display tabs
	// so I'm converting them to spaces

	int idest = 0;
	for(size_t isrc=0; isrc<strlen(txt); isrc++)
	{	
		if(txt[isrc] == '\t')
		{
			for(unsigned int tab_i=0; tab_i<4; tab_i++)
			{
				txt2[idest++] = ' ';
				if(idest == sizeof(txt2)/sizeof(char)-1)
					break;
			}
		}
		else
		{
			txt2[idest++] = txt[isrc];
		}
		if(idest == sizeof(txt2)/sizeof(char)-1)
			break;
	}

	txt2[idest] = 0;
	
    if(address != -1)
		address_map[address] = ctlList.GetItemCount();
	
    ctlList.AddItem(ctlList.GetItemCount(), 0, txt2);
}

bool CCodeViewerDlg::SelectLine(int address)
{
	CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	
	std::map<int, int>::iterator it;
	bool found = false;
	int line;
	
	it = address_map.find(address);
	
	if(it != address_map.end())	
	{
		line = (*it).second;			
		ctlList.SetItemState(line, LVIS_SELECTED, LVIS_SELECTED);					
		ctlList.EnsureVisible(line, FALSE);		
		found = true;
	}

	return found;
}

void CCodeViewerDlg::Clear(void)
{	
	address_map.clear();
	m_listctrl.DeleteAllItems();		
}

BOOL CCodeViewerDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;		
	RECT rect;

	// added SLB, 4/10/99, Font changes in window
	if ( TheFont.CreateFont(14,0,0,0,FW_MEDIUM,0,0,0,DEFAULT_CHARSET, OUT_TT_PRECIS,
						CLIP_DEFAULT_PRECIS, PROOF_QUALITY, FIXED_PITCH | FF_MODERN,
						"Courier New") )
	{
		m_listctrl.SetFont(&TheFont,FALSE);
	}
	// End font changes

	ctlList.AddColumn("Source Listing", 0);
	ctlList.GetClientRect(&rect);
	ctlList.SetColumnWidth(0, rect.right - rect.left);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCodeViewerDlg::LoadFile(void)
{
	CString filename;
    //m_pHc11View->Update();
	CFileDialog fdlg(TRUE);
	// File filtering added by Steven L. Barnicki, 3/19/99
	char strFilter[]="Relocated Listings (*.rst)\0*.rst\0Listing files (*.lst)\0*.lst\0All files (*.*)\0*.*\0\0";
	// implement CWD
	char buffer[_MAX_PATH];//addendum
	_getcwd(buffer, _MAX_PATH);
	fdlg.m_ofn.lpstrInitialDir = buffer;
	fdlg.m_ofn.lpstrFilter=strFilter;

	if(fdlg.DoModal() == IDOK)
	{	
		filename = fdlg.GetFileName();
		LoadLstFile(filename);
	}	
}

void CCodeViewerDlg::OnLoadLst() 
{
	// TODO: Add your control notification handler code here
	LoadFile();
}

void CCodeViewerDlg::OnClear() 
{	
	Clear();	
}

void CCodeViewerDlg::LoadLstFile(LPCTSTR filename)
{
	FILE *inf = fopen(filename, "r");
	
	if(inf)
	{
		char buf[256];
		int line, address, code;
		CLstFileDlg dlg;
		dlg.DoModal();
		switch (dlg.m_filetype)
		{
		case 0:		// as6811
		case 1:		// gcc
			{
				int start_address = 0;
				sscanf(dlg.m_startingaddr.GetBuffer(0), "%x", &start_address);			
				while(fgets(buf, sizeof(buf)/sizeof(char), inf) && !feof(inf))
				{
					int ret = strlen(buf);
					if(ret && buf[ret-1] == '\n') 
						buf[ret-1] = 0;

					char* ptr = buf;
					while(isspace(*ptr)) // EAD 20050101: Roll "skip whitespace" into sscanf below?
						ptr++;
					
					if(sscanf(ptr, "%x %x", &address, &code) == 2)			
						AddLine(buf, address + start_address);
					else
						AddLine(buf);
				}
			}
			break;
		case 2:		// as11m
			while(fgets(buf, sizeof(buf)/sizeof(char), inf) && !feof(inf))
			{
				int ret = strlen(buf);
				if(ret && buf[ret-1] == '\n') 
					buf[ret-1] = 0;

				if(sscanf(buf, "%d %x %x", &line, &address, &code) == 3)
					AddLine(buf, address);
				else
					AddLine(buf);
			}
			break;
		case 3:		// gcc3
			while(fgets(buf, sizeof(buf)/sizeof(char), inf) && !feof(inf))
			{
				int ret = strlen(buf);
				if(ret && buf[ret-1] == '\n') 
					buf[ret-1] = 0;

				if(sscanf(buf, " %x: %x", &address, &code) == 2) // E.g., "    c000:	8e ff ff..."
					AddLine(buf, address);
				else
					AddLine(buf);
			}
			break;
		case 4:		// MGTEK Assembler ASM11 V1.22 Build 137 for WIN32 (x86) (and probably other versions)
			while(fgets(buf, sizeof(buf)/sizeof(char), inf) && !feof(inf))
			{
				int ret = strlen(buf);
				if(ret && buf[ret-1] == '\n') 
					buf[ret-1] = 0;

				if(sscanf(buf, " %d: %x %x", &line, &address, &code) == 3) // E.g., "   84:     D000 0F..."
					AddLine(buf, address);
				else
					AddLine(buf);
			}
			break;
		default:
			::MessageBox(NULL, "The selected listing format is not yet implemented.  The listing will not be read.",
					"Unimplemented format", MB_OK | MB_ICONWARNING);
			break;
		}
		fclose(inf);
	}
}

void CCodeViewerDlg::SendLstFile(LPCTSTR filename)
{
	LoadLstFile(filename);
}

#pragma warning (pop)
