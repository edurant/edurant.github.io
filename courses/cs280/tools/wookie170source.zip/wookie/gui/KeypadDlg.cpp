////////////////////////////////////////////////////////////////////////////////
// File Name:       KeypadDlg.cpp
// Description:     This file defines all member functions for the CKeypadDlg class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:34:46
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HardCoreWookie.h"
#include "KeypadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeypadDlg dialog


////////////////////////////////////////////////////////////////////////////////
// Function Name:   CKeypadDlg
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function will initialize all key buttons.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  HC11*           pHC11           I/O Pointer to the HC11 object.
//  CWnd*           pParent         I/O Parent class.
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:26:59
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//	04/24/01	BPF & DAB		Altered to initialize lookup table.
//	04/24/01	BPF & DAB		Altered to change default value of m_nPressedValue to 16.
////////////////////////////////////////////////////////////////////////////////

const byte_t CKeypadDlg::m_aLookupTable[17][16] = {{0xE0,0xF1,0xE2,0xF3,0xE4,0xF5,0xE6,0xF7,0xE8,0xF9,0xEA,0xFB,0xEC,0xFD,0xEE,0xFF},
     {0xD0,0xF1,0xD2,0xF3,0xD4,0xF5,0xD6,0xF7,0xD8,0xF9,0xDA,0xFB,0xDC,0xFD,0xDE,0xFF},
     {0xB0,0xF1,0xB2,0xF3,0xB4,0xF5,0xB6,0xF7,0xB8,0xF9,0xBA,0xFB,0xBC,0xFD,0xBE,0xFF},
     {0x70,0xF1,0x72,0xF3,0x74,0xF5,0x76,0xF7,0x78,0xF9,0x7A,0xFB,0x7C,0xFD,0x7E,0xFF},
     {0xE0,0xE1,0xF2,0xF3,0xE4,0xE5,0xF6,0xF7,0xE8,0xE9,0xFA,0xFB,0xEC,0xED,0xFE,0xFF},
     {0xD0,0xD1,0xF2,0xF3,0xD4,0xD5,0xF6,0xF7,0xD8,0xD9,0xFA,0xFB,0xDC,0xDD,0xFE,0xFF},
     {0xB0,0xB1,0xF2,0xF3,0xB4,0xB5,0xF6,0xF7,0xB8,0xB9,0xFA,0xFB,0xBC,0xBD,0xFE,0xFF},
     {0x70,0x71,0xF2,0xF3,0x74,0x75,0xF6,0xF7,0x78,0x79,0xFA,0xFB,0x7C,0x7D,0xFE,0xFF},
     {0xE0,0xE1,0xE2,0xE3,0xF4,0xF5,0xF6,0xF7,0xE8,0xE9,0xEA,0xEB,0xFC,0xFD,0xFE,0xFF},
     {0xD0,0xD1,0xD2,0xD3,0xF4,0xF5,0xF6,0xF7,0xD8,0xD9,0xDA,0xDB,0xFC,0xFD,0xFE,0xFF},
     {0xB0,0xB1,0xB2,0xB3,0xF4,0xF5,0xF6,0xF7,0xB8,0xB9,0xBA,0xBB,0xFC,0xFD,0xFE,0xFF},
     {0x70,0x71,0x72,0x73,0xF4,0xF5,0xF6,0xF7,0x78,0x79,0x7A,0x7B,0xFC,0xFD,0xFE,0xFF},
     {0xE0,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF},
     {0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF},
     {0xB0,0xB1,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF},
     {0x70,0x71,0x72,0x73,0x74,0x75,0x76,0x77,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF},
     {0xF0,0xF1,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF}
    };


CKeypadDlg::CKeypadDlg(HC11* pHC11, CWnd* pParent /*=NULL*/)
	: CDialog(CKeypadDlg::IDD, pParent),
    m_key0(*this, 0),
    m_key1(*this, 1),
    m_key2(*this, 2),
    m_key3(*this, 3),
    m_key4(*this, 4),
    m_key5(*this, 5),
    m_key6(*this, 6),
    m_key7(*this, 7),
    m_key8(*this, 8),
    m_key9(*this, 9),
    m_keyA(*this, 10),
    m_keyB(*this, 11),
    m_keyC(*this, 12),
    m_keyD(*this, 13),
    m_keyE(*this, 14),
    m_keyF(*this, 15)
{
    m_pHC11 = pHC11;
    m_nPressedValue = 16;
	//{{AFX_DATA_INIT(CKeypadDlg)
	//}}AFX_DATA_INIT
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   DoDataExchange
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           Data exchange event.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function binds the member controls to the dialog controls.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CDataExchange*  pDX             I/O Pointer to data exchange object.
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:27:40
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeypadDlg)
	DDX_Control(pDX, IDC_KEYF, m_keyF);
	DDX_Control(pDX, IDC_KEYE, m_keyE);
	DDX_Control(pDX, IDC_KEYD, m_keyD);
	DDX_Control(pDX, IDC_KEYC, m_keyC);
	DDX_Control(pDX, IDC_KEYB, m_keyB);
	DDX_Control(pDX, IDC_KEYA, m_keyA);
	DDX_Control(pDX, IDC_KEY9, m_key9);
	DDX_Control(pDX, IDC_KEY8, m_key8);
	DDX_Control(pDX, IDC_KEY7, m_key7);
	DDX_Control(pDX, IDC_KEY6, m_key6);
	DDX_Control(pDX, IDC_KEY5, m_key5);
	DDX_Control(pDX, IDC_KEY4, m_key4);
	DDX_Control(pDX, IDC_KEY3, m_key3);
	DDX_Control(pDX, IDC_KEY2, m_key2);
	DDX_Control(pDX, IDC_KEY1, m_key1);
	DDX_Control(pDX, IDC_KEY0, m_key0);
	DDX_Control(pDX, IDC_ERROR, m_error);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeypadDlg, CDialog)
	//{{AFX_MSG_MAP(CKeypadDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnOK
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           OK Button Handler.
// Pre-Conditions:  <none>
// Post-Conditions: The window will no longer be displayed.
// Description:     This function will hide the window instead of closing it.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:29:38
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::OnOK() 
{
    Visible(false);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Visible
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           Call this function to make the window visible or to hide the
//                  window.
// Pre-Conditions:  The window must have been created.
// Post-Conditions: If val is true, the window must be displayed, otherwise the
//                  windows must be hidden.
// Description:     This function is used to intercept calls to show and hide the
//                  windows so that it can be attached and detached from any subjects
//                  that it needs to watch.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  bool            val             I   Whether or not to show the window.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:31:40
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::Visible (bool val)
{
    m_bVisible = val;

    if(val)
    {
        ShowWindow(true);
        //make this an observer
        m_pHC11->regfile.PORTC.Attach2(this);
        Update();
    }
    else
    {
        ShowWindow(false);	    
        //clear any subjects
        m_pHC11->regfile.PORTC.UnAttach2();
    }
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Visible (const)
// Scope:           CKeypadDlg
// Usage:           Call this function to check if the window is visible.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function will return whether the window is currently
//                  visible.
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  bool            True if the window is visible.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:30:13
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
bool CKeypadDlg::Visible () const
{
    return(m_bVisible);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Update
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           This function is called when the PORTC gets updated.
// Pre-Conditions:  Must be visible and the HC11 pointer should be set.
// Post-Conditions: <none>
// Description:     This function will determine if the keypad is set up properly,
//                  will read the portc output bits and determine which, if any,
//                  input bits to set if the keypad was pressed since the last clock
//                  cycle.
//
// Author:          Jake & Blake
// Created:         01/28/2001 14:45:51
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//	04/24/01	BPF & DAB		Altered to use lookup table.
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::Update ()
{
    //Static variable to keep from recursively calling this function
    static bool bInContext = false;

    if (!bInContext)
    {
        //Prevent recursive calls to this function.
        bInContext = true;


        //Create the direction byte for the DDRC
        //Make sure the upper nibble are set to input and the lower nibble to output
        if (UpdateDisplay())
        {
	        PortRegister& PORTC = m_pHC11->regfile.PORTC;
	        byte_t output = 
	            (PORTC.Read(3) << 3) |
	            (PORTC.Read(2) << 2) |
	            (PORTC.Read(1) << 1) |
	             PORTC.Read(0);

			//Writes to PORTC the value archived in the lookup table.
			//Indexes are the currently pressed key and the lower nybble of the
			//	value written to PORTC.
			//Once this function is called, PORTC notifies any observers (this would
			//  make this function recursive if we didn't prevent it.
            PORTC.ExternalWrite(m_aLookupTable[m_nPressedValue][output]);
        }

        bInContext = false;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnKeyDown
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           KeySink event fired when one of the keys is pressed.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Stores the key code that was pressed.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  short           nCode           I   Code of the key pressed.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:27:30
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::OnKeyDown (short nCode)
{
    m_nPressedValue = nCode;
	Update();
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   OnKeyUp
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           KeySink event fires when one of the keys is released.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Resets the key press value.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  short           nCode           I   Code of the key released.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:27:32
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::OnKeyUp (short nCode)
{
    m_nPressedValue = 16;
	Update();
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Write
// Scope:           CKeypadDlg
// Return Value:    <none>
// Usage:           PortConnection update event.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function will call the update function.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  byte_t          val             I   New value for the watched port.
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:25:29
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CKeypadDlg::Write (byte_t val)
{
    Update();
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   UpdateDisplay
// Scope:           CKeypadDlg
// Usage:           Call this function to update the error message display.
// Pre-Conditions:  The window should be visible.
// Post-Conditions: <none>
// Description:     Checks the DDRC and returns true if it is set up properly.
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  bool            True if the DDRC is set to 0x0F
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:35:07
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
bool CKeypadDlg::UpdateDisplay ()
{
    bool bRetval = true;
    PortRegister& PORTC = m_pHC11->regfile.PORTC;

    //Create the direction byte for the DDRC
    byte_t bDir = 
        (PORTC.GetMode(7) == Pin::INPUT ? 0x00 : 0x80) |
        (PORTC.GetMode(6) == Pin::INPUT ? 0x00 : 0x40) |
        (PORTC.GetMode(5) == Pin::INPUT ? 0x00 : 0x20) |
        (PORTC.GetMode(4) == Pin::INPUT ? 0x00 : 0x10) |
        (PORTC.GetMode(3) == Pin::INPUT ? 0x00 : 0x08) |
        (PORTC.GetMode(2) == Pin::INPUT ? 0x00 : 0x04) |
        (PORTC.GetMode(1) == Pin::INPUT ? 0x00 : 0x02) |
        (PORTC.GetMode(0) == Pin::INPUT ? 0x00 : 0x01);

    //Make sure the upper nibble are set to input and the lower nibble to output
    if (bDir != 0x0F)
    {
        bRetval = false;
        if (m_error.GetWindowTextLength() == 0)
        {
            m_error.SetWindowText("DDRC is not set properly!");
        }
    }
    else
    {
        m_error.SetWindowText("");
    }

    return(bRetval);
}
