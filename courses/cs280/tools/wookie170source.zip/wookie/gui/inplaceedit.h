// InPlaceEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInPlaceEdit window

//##ModelId=3A3D096C0173
class CInPlaceEdit : public CEdit
{
// Construction
public:
	//##ModelId=3A3D096C019F
	CInPlaceEdit(int iItem, int iSubItem, CString sInitText);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInPlaceEdit)
	public:
	//##ModelId=3A3D096C019C
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	//##ModelId=3A3D096C0196
	virtual ~CInPlaceEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CInPlaceEdit)
	//##ModelId=3A3D096C0193
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//##ModelId=3A3D096C0191
	afx_msg void OnNcDestroy();
	//##ModelId=3A3D096C018A
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//##ModelId=3A3D096C0187
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	//##ModelId=3A3D096C0180
	int m_iItem;
	//##ModelId=3A3D096C017F
	int m_iSubItem;
	//##ModelId=3A3D096C017E
	CString m_sInitText;
	//##ModelId=3A3D096C017D
	BOOL    m_bESC;	 	// To indicate whether ESC key was pressed
};

/////////////////////////////////////////////////////////////////////////////
