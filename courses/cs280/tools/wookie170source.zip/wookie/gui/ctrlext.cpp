//## begin module.includes preserve=yes
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1997 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "ctrlext.h"
//## end module.includes preserve=yes
//## begin module.additionalDeclarations preserve=yes

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define new DEBUG_NEW

/////////////////////////////////////////////////////////////////////////////
// Inline function declarations

#define _AFXCTL_INLINE inline


/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlNode


//## end module.additionalDeclarations
const CTreeCursor& CTreeCursor::operator =(const CTreeCursor& posSrc)
{
//## begin CTreeCursor::operator =%-666618313.body preserve=yes
	if(&posSrc != this){
		m_hTreeItem = posSrc.m_hTreeItem;
		m_pTree = posSrc.m_pTree;
	}
	return *this;
//## end CTreeCursor::operator =%-666618313.body
}


CTreeCursor CTreeCursor::_Insert(LPCTSTR strItem,int nImageIndex,HTREEITEM hAfter)
{
//## begin CTreeCursor::_Insert%1124745139.body preserve=yes
	TV_INSERTSTRUCT ins;
	ins.hParent = m_hTreeItem;
	ins.hInsertAfter = hAfter;
	ins.item.mask = TVIF_TEXT;
	ins.item.pszText = (LPTSTR) strItem;
	if(nImageIndex != -1){
		ins.item.mask |= TVIF_IMAGE | TVIF_SELECTEDIMAGE;
		ins.item.iImage = nImageIndex;
		ins.item.iSelectedImage = nImageIndex;
	}
	return CTreeCursor(m_pTree->InsertItem(&ins), m_pTree);
//## end CTreeCursor::_Insert%1124745139.body
}

int CTreeCursor::GetImageID()
{
//## begin CTreeCursor::GetImageID%1153106720.body preserve=yes
	TV_ITEM item;
	item.mask = TVIF_HANDLE | TVIF_IMAGE;
	item.hItem = m_hTreeItem;
	m_pTree->GetItem(&item);
	return item.iImage;
//## end CTreeCursor::GetImageID%1153106720.body
}

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlEx

// All handled by inlines

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: AddColumn
//
// Author: ???????
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
BOOL CListCtrlEx::AddColumn(LPCTSTR strItem,int nItem,int nSubItem,int nMask,int nFmt)
{
//## begin CListCtrlEx::AddColumn%-592289885.body preserve=yes
	LV_COLUMN lvc;
	lvc.mask = nMask;
	lvc.fmt = nFmt;
	lvc.pszText = (LPTSTR) strItem;
	lvc.cx = GetStringWidth(lvc.pszText) + 15;
	if(nMask & LVCF_SUBITEM){
		if(nSubItem != -1)
			lvc.iSubItem = nSubItem;
		else
			lvc.iSubItem = nItem;
	}
	return InsertColumn(nItem,&lvc);
//## end CListCtrlEx::AddColumn%-592289885.body
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: AddItem
//
// Author: ???????
//
// Purpose: 
//
// Input Parameters: 
//
// Return Value: 
//
// Preconditions:
//
// Post Conditions: 
//
/////////////////////////////////////////////////////////////////////////////
BOOL CListCtrlEx::AddItem(int nItem,int nSubItem,LPCTSTR strItem,int nImageIndex)
{
//## begin CListCtrlEx::AddItem%2077074835.body preserve=yes
	LV_ITEM lvItem;
	lvItem.mask = LVIF_TEXT;
	lvItem.iItem = nItem;
	lvItem.iSubItem = nSubItem;
	lvItem.pszText = (LPTSTR) strItem;
	if(nImageIndex != -1){
		lvItem.mask |= LVIF_IMAGE;
		lvItem.iImage |= LVIF_IMAGE;
	}
	if(nSubItem == 0)
		return InsertItem(&lvItem);
	return SetItem(&lvItem);
//## end CListCtrlEx::AddItem%2077074835.body
}

/////////////////////////////////////////////////////////////////////////////
 
