// MCUDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "MCUDlg.h"
#include "ctrlext.h"
#include "valuedlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMCUDlg dialog
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: CMCUDlg Constructor
//
// Author: Kalle Anderson
//
// Purpose: To initialze the MCU dialog box
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
CMCUDlg::CMCUDlg(HC11 *phc11, CWnd* pParent /*=NULL*/)
	: CDialog(CMCUDlg::IDD, pParent)
{
    Create(IDD_MCU, NULL);    
	//{{AFX_DATA_INIT(CMCUDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

    hc11 = phc11;
    visible = false;

    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	    
    ctlList.AddColumn("Name    ",0);    
    ctlList.AddColumn("Value                  ",1);
    ctlList.AddItem(0,0,"ACCA");
    ctlList.AddItem(1,0,"ACCB");
    ctlList.AddItem(2,0,"ACCD");
    ctlList.AddItem(3,0,"IX");
    ctlList.AddItem(4,0,"IY");
    ctlList.AddItem(5,0,"SP");
    ctlList.AddItem(6,0,"PC");
    ctlList.AddItem(7,0,"CCR");
    ctlList.AddItem(8,0,"");    
    ctlList.AddItem(8,1,"S X H I N Z V C");
}


void CMCUDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMCUDlg)
	DDX_Control(pDX, IDC_CPULIST, m_listctrl);
	//}}AFX_DATA_MAP
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Visible
//
// Author: Kalle Anderson
//
// Purpose: To toggle the visiblity of the CPU dialog box
//
// Input Parameters: bool val - the state to change the CPU dialog to - visible
//								or not visible
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CMCUDlg::Visible(bool val)
{
    visible = val;

    if(val)
    {		
        Update();
        ShowWindow(true);	    
    }
    else    
        ShowWindow(false);	        
}            

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Update
//
// Author: Kalle Anderson
//
// Purpose: To refresh the values on the screen with the actual values in the 
//			HC11
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CMCUDlg::Update(void)
{    
    CListCtrlEx& ctlList = (CListCtrlEx&) m_listctrl;	    
    CString val;
    char *ptr;

    val.Format("$%.2X",(int)hc11->ACCA);//addendum
    ctlList.AddItem(0,1,val);
    val.Format("$%.2X",(int)hc11->ACCB);
    ctlList.AddItem(1,1,val);
    val.Format("$%.4X",(int)((hc11->ACCA<<8)|hc11->ACCB));
    ctlList.AddItem(2,1,val);
    val.Format("$%.4X",(int)hc11->IX);
    ctlList.AddItem(3,1,val);
    val.Format("$%.4X",(int)hc11->IY);
    ctlList.AddItem(4,1,val);
    val.Format("$%.4X",(int)hc11->SP);
    ctlList.AddItem(5,1,val);
    val.Format("$%.4X",(int)hc11->PC);
    ctlList.AddItem(6,1,val);    
	
	// SLB, 4/10/99, Adjusted alignment of flags
    val = "0 0 0 0  0 0 0  0";
    ptr = val.GetBuffer(0);
    if(hc11->CCR.S())ptr[0]='1';
    if(hc11->CCR.X())ptr[2]='1';
    if(hc11->CCR.H())ptr[4]='1';
    if(hc11->CCR.I())ptr[6]='1';
    if(hc11->CCR.N())ptr[9]='1';
    if(hc11->CCR.Z())ptr[11]='1';
    if(hc11->CCR.V())ptr[13]='1';
    if(hc11->CCR.C())ptr[16]='1';
 
	/*val = "0 0 0 0 0 0 0 0";
    ptr = val.GetBuffer(0);
    if(hc11->CCR.S())ptr[0]='1';
    if(hc11->CCR.X())ptr[2]='1';
    if(hc11->CCR.H())ptr[4]='1';
    if(hc11->CCR.I())ptr[6]='1';
    if(hc11->CCR.N())ptr[8]='1';
    if(hc11->CCR.Z())ptr[10]='1';
    if(hc11->CCR.V())ptr[12]='1';
    if(hc11->CCR.C())ptr[14]='1'; */
	
	ctlList.AddItem(7,1,val);
}            



BEGIN_MESSAGE_MAP(CMCUDlg, CDialog)
	//{{AFX_MSG_MAP(CMCUDlg)
	ON_BN_CLICKED(IDC_MCUUPDATE, OnMcuupdate)
	ON_BN_CLICKED(IDC_MCUCHANGE, OnMcuchange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMCUDlg message handlers


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnMcuupdate
//
// Author: Kalle Anderson
//
// Purpose: To update the CPU dialog box
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CMCUDlg::OnMcuupdate() 
{
	Update();	
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: OnMcuchange
//
// Author: Kalle Anderson
//
// Purpose: To modify the HC11 values with the values in the dialog box
//
// Input Parameters: None
//
// Return Value: None
//
// Preconditions: None
//
// Post Conditions: None
//
/////////////////////////////////////////////////////////////////////////////
void CMCUDlg::OnMcuchange() 
{
    CValueDlg dlg;
    int value = -1;
    int i;

    LV_ITEM item;
    item.mask = LVIF_STATE;
    item.stateMask = LVIS_SELECTED;
    item.iSubItem = 0;
    
    for(i=0;i<8;i++)
    {        
        item.iItem = i;
        if(m_listctrl.GetItem(&item) && item.state&LVIS_SELECTED)        
            break;
    }	

    if(i<8)
    {    
        switch(i)
        {
            case 0: dlg.m_value.Format("%X",(int)hc11->ACCA);
                    break;
            case 1: dlg.m_value.Format("%X",(int)hc11->ACCB);
                    break;
            case 2: dlg.m_value.Format("%X",(int)(hc11->ACCA<<8)|hc11->ACCB);                    
                    break;
            case 3: dlg.m_value.Format("%X",(int)hc11->IX);
                    break;
            case 4: dlg.m_value.Format("%X",(int)hc11->IY);
                    break;
            case 5: dlg.m_value.Format("%X",(int)hc11->SP);
                    break;
            case 6: dlg.m_value.Format("%X",(int)hc11->PC);
                    break;
            case 7: // CCR modified in binary
                    dlg.m_value = "00000000";                              
                    for(int j=0;j<8;j++)	                
                    dlg.m_value.SetAt(7-j,((hc11->CCR)&(1<<j)) ? '1' : '0');	 
                    dlg.m_radio = 2;
                    break;
        }
        if(dlg.DoModal() == IDOK)
        {                                
            if(dlg.value_ok)
            {
                switch(i)
                {
                    case 0: hc11->ACCA = dlg.value&0xFF;
                            break;
                    case 1: hc11->ACCB = dlg.value&0xFF;
                            break;
                    case 2: hc11->ACCA =(dlg.value&0xFF00)>>8;
                            hc11->ACCB = dlg.value&0xFF;
                            break;
                    case 3: hc11->IX = dlg.value&0xFFFF;
                            break;
                    case 4: hc11->IY = dlg.value&0xFFFF;
                            break;
                    case 5: hc11->SP = dlg.value&0xFFFF;
                            break;
                    case 6: hc11->PC = dlg.value&0xFFFF;
                            break;
                    case 7: hc11->CCR = dlg.value&0xFF;
                            break;
                }
                Update();
            }
            else AfxMessageBox("bad value!");
        }	
    }
}

void CMCUDlg::OnOK() 
{
    Visible(0);
}
