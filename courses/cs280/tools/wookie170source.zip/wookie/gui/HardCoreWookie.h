// HardCoreWookie.h : main header file for the HARDCOREWOOKIE application
//
#if !defined(AFX_HARDCOREWOOKIE_H__6DC37105_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
#define AFX_HARDCOREWOOKIE_H__6DC37105_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CHardCoreWookieApp:
// See HardCoreWookie.cpp for the implementation of this class
//

//##ModelId=3A3D096A0365
class CHardCoreWookieApp : public CWinApp
{
public:
	//##ModelId=3A3D096A0374
	CHardCoreWookieApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHardCoreWookieApp)
	public:
	//##ModelId=3A3D096A0372
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHardCoreWookieApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HARDCOREWOOKIE_H__6DC37105_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
