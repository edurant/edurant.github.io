#if !defined(AFX_MCUDLG_H__A61C5373_92A3_11D1_BF16_0000C03A66E5__INCLUDED_)
#define AFX_MCUDLG_H__A61C5373_92A3_11D1_BF16_0000C03A66E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MCUDlg.h : header file
//

#include "../emu/hc11.h"

/////////////////////////////////////////////////////////////////////////////
// CMCUDlg dialog

//##ModelId=3A3D096F0091
class CMCUDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096F00CF
	CMCUDlg(HC11 *phc11, CWnd* pParent = NULL);   // standard constructor
    
	//##ModelId=3A3D096F00CD
    void Update(void);    
	//##ModelId=3A3D096F00B1
    HC11 *hc11;
            
	//##ModelId=3A3D096F00C5
    void Visible(bool val);
	//##ModelId=3A3D096F00C7
    bool Visible(void){return visible;};    
	//##ModelId=3A3D096F00A8
    bool visible;

// Dialog Data
	//{{AFX_DATA(CMCUDlg)
	enum { IDD = IDD_MCU };
	//##ModelId=3A3D096F00A5
	CListCtrl	m_listctrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMCUDlg)
	protected:
	//##ModelId=3A3D096F00BE
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMCUDlg)
	//##ModelId=3A3D096F00BC
	afx_msg void OnMcuupdate();
	//##ModelId=3A3D096F00BA
	afx_msg void OnMcuchange();
	//##ModelId=3A3D096F00B4
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MCUDLG_H__A61C5373_92A3_11D1_BF16_0000C03A66E5__INCLUDED_)
