#if !defined(AFX_HC11VIEW_H__6DC37118_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
#define AFX_HC11VIEW_H__6DC37118_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Hc11View.h : header file
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/14/2001  Jake & Dainen   Added the "KeypadDlg.h" include.
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CHc11View form view

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CHc11View
//
// Author: Kalle Anderson & Matt Enwald
//
// Purpose: The main view of the GUI, that contains all the buttons and stuff.
//
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/14/2001  Jake & Dainen   Added the Keypad member.
/////////////////////////////////////////////////////////////////////////////

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "PortIO.h"
#include "MemoryWatch.h"
#include "MCUDlg.h"
#include "PinGraph.h"
#include "7SegDlg.h"
#include "MemoryBrowseDlg.h"
#include "CodeViewerDlg.h"
#include "KeypadDlg.h"
#include "direct.h"  //addendum

#define WM_THREAD_STOP (WM_USER + 1)

//##ModelId=3A3D096B0262
class CHc11View : public CFormView
{
protected:
	//##ModelId=3A3D096C0014
	CHc11View();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CHc11View)

// Form Data
public:
	//{{AFX_DATA(CHc11View)
	enum { IDD = IDD_MAINDIALOG };
	//##ModelId=3A3D096B0370
	CEdit	m_bpctrl;
	//##ModelId=3A3D096B035E
	CButton	m_stepctrl;
	//##ModelId=3A3D096B0352
	CButton	m_runctrl;
	//##ModelId=3A3D096B0340
	CButton	m_xirqctrl;
	//##ModelId=3A3D096B0336
	CButton	m_irqctrl;
	//##ModelId=3A3D096B0322
	CBitmapButton	m_cpubutton;
	//##ModelId=3A3D096B0316
	CString	m_breakp;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
    // These are all the pop-up windows associated with the buttons in this view
	//##ModelId=3A3D096B030E
    CPortIO *m_pADlg;
	//##ModelId=3A3D096B0302
	CPortIO *m_pBDlg;
	//##ModelId=3A3D096B02F0
	CPortIO *m_pCDlg;
	//##ModelId=3A3D096B02E6
	CPortIO *m_pDDlg;
	//##ModelId=3A3D096B02DC
	CPortIO *m_pEDlg;
	//##ModelId=3A3D096B02D0
    CMemoryWatch *m_pWatch;
	//##ModelId=3A3D096B02C6
    CRegisterWatch *m_pRegWatch;
	//##ModelId=3A3D096B02BC
    CMCUDlg *m_pMCUDlg;
	//##ModelId=3A3D096B02AA
    CPinGraph *m_pGraphDlg;
	//##ModelId=3A3D096B02A0
    C7SegDlg *m_p7seg;
	//##ModelId=3A3D096B0296
	CMemoryBrowseDlg *m_pMemBrowse;
	//##ModelId=3A3D096B028C
	CCodeViewerDlg *m_pCodeView;

    CKeypadDlg* m_pKeypad;
    
    // bitmaps for some buttons in this view
	//##ModelId=3A3D096B0282
    CBitmap stepbmp;
	//##ModelId=3A3D096B0278
    CBitmap runningbmp;
	//##ModelId=3A3D096B026E
    CBitmap stoppedbmp;
        
    // called to update some of the pop-up windows
	//##ModelId=3A3D096C000A
    void Update(void);
    
    // Function to recieve the WM_THREAD_STOP message from the worker thread.
	//##ModelId=3A3D096B03E0
    LRESULT OnThreadStop(WPARAM, LPARAM);

    // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHc11View)
	public:
	//##ModelId=3A3D096B03DE
	virtual void OnInitialUpdate();
	protected:
	//##ModelId=3A3D096B03D4
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//##ModelId=3A3D096B03CC
	virtual ~CHc11View();
#ifdef _DEBUG
	//##ModelId=3A3D096B03CA
	virtual void AssertValid() const;
	//##ModelId=3A3D096B03BB
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CHc11View)
	afx_msg void OnMemoryClick();
	afx_msg void OnCpuClick();
	afx_msg void OnPortAClick();
	afx_msg void OnPortBClick();
	afx_msg void OnPortCClick();
	afx_msg void OnPortDClick();
	afx_msg void OnPortEClick();
	afx_msg void OnMemoryWatch();
	afx_msg void OnRegs();
	afx_msg void OnIrq();
	afx_msg void OnXirq();
	afx_msg void OnReset();
	afx_msg void OnRun();
	afx_msg void OnStep();
	afx_msg void OnKillfocusTestedit();
	afx_msg void OnChangeBpedit();
	afx_msg void OnGraphtest();
	afx_msg void OnGo7seg();
	afx_msg void OnViewCode();
	afx_msg void OnKeypad();
	afx_msg void OnLoadWinSettings();
	afx_msg void OnSaveWinSettings();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HC11VIEW_H__6DC37118_53BB_11D1_A2C3_0000C0E665E5__INCLUDED_)
