#if !defined(AFX_PINGRAPH_H__B503F112_98D2_11D1_BF17_0000C03B66E5__INCLUDED_)
#define AFX_PINGRAPH_H__B503F112_98D2_11D1_BF17_0000C03B66E5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PinGraph.h : header file
//

#include "../emu/hc11.h"
#include "../emu/PinConnection.h"
#include "../emu/Pin.h"
#include "../emu/PortConnection.h"
#include "../emu/PortRegister.h"
#include "../emu/PortARegister.h"
#include "../emu/PortBRegister.h"
#include "../emu/DDRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: CPinGraph
//
// Author: Kalle Anderson
//
// Purpose: This can be used to view a waveform on a pin from a port. This
//          was thrown together real quick, so its still kinda experimental.
//          Needs improvement.          
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPinGraph dialog

//##ModelId=3A3D096D0106
class CPinGraph : public CDialog, public PinConnection
{
// Construction
	//##ModelId=3A3D096D01BD
    HC11 *hc11;
	//##ModelId=3A3D096D01B2
    PortRegister * m_port;
	//##ModelId=3A3D096D01A6
    int m_pin;
    
    double pos,tick;
	//##ModelId=3A3D096D019F
    int previous_slider_pos;
	//##ModelId=3A3D096D019C
    bit_t previous_level;
	//##ModelId=3A3D096D0189
    long previous_clock;
	//##ModelId=3A3D096D0188
    bool attached;
	//##ModelId=3A3D096D017E
    double scale;    
    
	//##ModelId=3A3D096D0175
    int high_time;    
	//##ModelId=3A3D096D0174
    int period;
	//##ModelId=3A3D096D016A
    int period_start;

	//##ModelId=3A3D096D0160
    bool visible;
    
public:
	//##ModelId=3A3D096D01ED
	CPinGraph(HC11 *phc11, CWnd* pParent = NULL);   // standard constructor
	//##ModelId=3A3D096D01E3
    void Set(bit_t value);
	//##ModelId=3A3D096D01D2
    bool Visible(void){return visible;};
	//##ModelId=3A3D096D01DA
    void Visible(bool val);

// Dialog Data
	//{{AFX_DATA(CPinGraph)
	enum { IDD = IDD_GRAPHDLG };
	//##ModelId=3A3D096D0158
	CEdit	m_pinname;
	//##ModelId=3A3D096D014E
	CEdit	m_freq;
	//##ModelId=3A3D096D0144
	CButton	m_attach;
	//##ModelId=3A3D096D013A
	CEdit	m_period;
	//##ModelId=3A3D096D0130
	CEdit	m_duty;
	//##ModelId=3A3D096D0126
	CEdit	m_mscalestrc;
	//##ModelId=3A3D096D011C
	CSliderCtrl	m_scale;
	//##ModelId=3A3D096D0112
	CStatic	m_graph;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPinGraph)
	protected:
	//##ModelId=3A3D096D01CF
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPinGraph)
	//##ModelId=3A3D096D01C9
	afx_msg void OnButton1();
	//##ModelId=3A3D096D01C7
	virtual BOOL OnInitDialog();
	//##ModelId=3A3D096D01C5
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PINGRAPH_H__B503F112_98D2_11D1_BF17_0000C03B66E5__INCLUDED_)
