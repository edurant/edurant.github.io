////////////////////////////////////////////////////////////////////////////////
// File Name:       IKeySink.h
// Description:     This file declares the IKeySink interface.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:16:36
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(IKEYSINK_H)
#define IKEYSINK_H

////////////////////////////////////////////////////////////////////////////////
// Class Name:      IKeySink
// Usage:           Derive your dialog from this class when using the CKeyButton
//                  button class.
// Description:     This interface defines the callback functions for when the key
//                  is pressed and when it is released.
//
// Author:          Jake & Blake
// Created:         01/28/2001 18:17:39
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
class IKeySink
{
public:
    virtual void OnKeyDown (short nCode) = 0;
    virtual void OnKeyUp (short nCode) = 0;
};

#endif //!defined(IKEYSINK_H)