// 7SegDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "7SegDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// C7SegDlg dialog


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: C7SegDlg
//
// Author: Kalle Anderson
//
// Purpose: Loads up all the bitmaps for the 11 seg font.
//
// Input Parameters: HC11 pointer
//
// Return Value: None.
//
/////////////////////////////////////////////////////////////////////////////
C7SegDlg::C7SegDlg(HC11 *nhc11, CWnd* pParent /*=NULL*/)
	: CDialog(C7SegDlg::IDD, pParent)
{
    hc11=nhc11;
    Create(IDD_7SEG, NULL);    

    // modified mapping to ASCII, SLB, 3/13/99
	b[0].LoadBitmap(IDB_BLANK); // space, map all chars by subtracting 0x20
    b[1].LoadBitmap(IDB_EXCL);	// !
    b[2].LoadBitmap(IDB_DQUOTE);// "
    b[3].LoadBitmap(IDB_POUND);	// #
    b[4].LoadBitmap(IDB_DOLLAR);// $
    b[5].LoadBitmap(IDB_PERCENT); // %
    b[6].LoadBitmap(IDB_AMP);	// &
    b[7].LoadBitmap(IDB_QUOTE);	// '
    b[8].LoadBitmap(IDB_LPARENS); // (
    b[9].LoadBitmap(IDB_RPARENS); // )
    b[10].LoadBitmap(IDB_AST);	// *
    b[11].LoadBitmap(IDB_PLUS);	// +
    b[12].LoadBitmap(IDB_COMMA);// ,
    b[13].LoadBitmap(IDB_MINUS);// -
    b[14].LoadBitmap(IDB_DOT);	// .
    b[15].LoadBitmap(IDB_BSLASH);// /
    b[16].LoadBitmap(IDB_0);
    b[17].LoadBitmap(IDB_1);
    b[18].LoadBitmap(IDB_2);
    b[19].LoadBitmap(IDB_3);
    b[20].LoadBitmap(IDB_4);
    b[21].LoadBitmap(IDB_5);
    b[22].LoadBitmap(IDB_6);
    b[23].LoadBitmap(IDB_7);
    b[24].LoadBitmap(IDB_8);
    b[25].LoadBitmap(IDB_9);
    b[26].LoadBitmap(IDB_COLON);// :
    b[27].LoadBitmap(IDB_SCOLON);// ;
    b[28].LoadBitmap(IDB_LESS);	// <
    b[29].LoadBitmap(IDB_EQUAL);// =
    b[30].LoadBitmap(IDB_GREATER);// >
    b[31].LoadBitmap(IDB_QUESTION);// ?
    b[32].LoadBitmap(IDB_AT);	// @
    b[33].LoadBitmap(IDB_A);
    b[34].LoadBitmap(IDB_B);
    b[35].LoadBitmap(IDB_C);
    b[36].LoadBitmap(IDB_D);
	b[37].LoadBitmap(IDB_E);
	b[38].LoadBitmap(IDB_F);
	b[39].LoadBitmap(IDB_G);
	b[40].LoadBitmap(IDB_H);
	b[41].LoadBitmap(IDB_I);
	b[42].LoadBitmap(IDB_J);
	b[43].LoadBitmap(IDB_K);
	b[44].LoadBitmap(IDB_L);
	b[45].LoadBitmap(IDB_M);
	b[46].LoadBitmap(IDB_N);
	b[47].LoadBitmap(IDB_O);
	b[48].LoadBitmap(IDB_P);
	b[49].LoadBitmap(IDB_Q);
	b[50].LoadBitmap(IDB_R);
	b[51].LoadBitmap(IDB_S);
	b[52].LoadBitmap(IDB_T);
	b[53].LoadBitmap(IDB_U);
	b[54].LoadBitmap(IDB_V);
	b[55].LoadBitmap(IDB_W);
	b[56].LoadBitmap(IDB_X);
	b[57].LoadBitmap(IDB_Y);
	b[58].LoadBitmap(IDB_Z);
	b[59].LoadBitmap(IDB_LBRACKET);// [
	b[60].LoadBitmap(IDB_SLASH);	/* / */
	b[61].LoadBitmap(IDB_RBRACKET);// ]
	b[62].LoadBitmap(IDB_CARET);	// ^
	b[63].LoadBitmap(IDB_UNDER);	// _

	//{{AFX_DATA_INIT(C7SegDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT    
}


void C7SegDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(C7SegDlg)
	DDX_Control(pDX, IDC_ERROR, m_error);
	DDX_Control(pDX, IDC_D3, m_d3);
	DDX_Control(pDX, IDC_D2, m_d2);
	DDX_Control(pDX, IDC_D1, m_d1);
	DDX_Control(pDX, IDC_D0, m_d0);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(C7SegDlg, CDialog)
	//{{AFX_MSG_MAP(C7SegDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// C7SegDlg message handlers

void C7SegDlg::OnOK() 
{
	// TODO: Add extra validation here
	
    Visible(false);
//	CDialog::OnOK();
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Visible
//
// Author: Kalle Anderson
//
// Purpose: Hide or show this dialog
//
// Input Parameters: visiblity
//
// Return Value: None
//
// Modifications:   1/24/01     Dainen Bugh, Ian Kasprzak
//                  Added checks for PIOC settings & displayed error message
//
/////////////////////////////////////////////////////////////////////////////

void C7SegDlg::Visible(bool val)
{
    visible = val;

    if(val)
    {
        //Get the PIOC register
        PIOCRegister PIOCReg = hc11->regfile.GetPIOCConst();
    
        //Check the preconditions of the PIOC to show an error if necessary

        //First check the PIOC levels, and display an error if the
        //indicated levels are not set correctly
        
        //INVB must be set to zero (Bit 0 of PIOC)
        //HNDS must be set to zero (Bit 4 of PIOC)

        if( !( (PIOCReg.bit0() == 0) && (PIOCReg.bit4() == 0) ) )
        {
           //Indicate the PIOC setup error
           m_error.SetWindowText("Incorrect PIOC Setup");
        }
        else
        {
            //Make sure no error is displayed
            m_error.SetWindowText("");
        }

        ShowWindow(true);	    
        hc11->STRB.Attach(this);
    }
    else
    {
        ShowWindow(false);	    
        // so when port b gets written two this is 
        hc11->STRB.UnAttach();
    }
}            

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Set
//
// Author: Kalle Anderson
//
// Purpose: When STRB goes low, this reads portb for the character index,
//          then loads the character on portc into that position.
//          must be alphabetic character or a number
//
// Input Parameters: level of STRB pin
//
// Return Value: None
//
// Modifications:   1/24/01     Dainen Bugh, Ian Kasprzak
//                  Added checks for PIOC settings & displayed error message
//
/////////////////////////////////////////////////////////////////////////////

void C7SegDlg::Set(bit_t level)
{
    byte_t val;
    
    //Conditions for character display to work
    //STRB (level) must be low
    //INVB must be set to zero (Bit 0 of PIOC)
    //HNDS must be set to zero (Bit 4 of PIOC)
    
    //Get the PIOC register
    PIOCRegister PIOCReg = hc11->regfile.GetPIOCConst();
    
    //Check the preconditions before allowing the character display
    //to display

    //First check the PIOC levels, and display an error if the
    //indicated levels are not set correctly
    if((PIOCReg.bit0() == 0) && (PIOCReg.bit4() == 0))
    {
        //Clear the error
        m_error.SetWindowText("");
        
        if((level==0))
        {
            val = (hc11->regfile.PORTB.Read());

            /*
		    // make sure it is an alphabetic character or a number
            if((val>='0' && val <='9'))
                val-='0';
            else if(val>='A' && val <='Z')
                val-='A'-10;
            else if(val>='a' && val <='a')
                val-='a'-10;
            else val = 36; */


			if (val > 127)
				val = val - 128;  // knock off the high bit if set, SLB, 3/1/2002

			// Modified for ASCII, SLB, 3/13/99
		    if ((val >= ' ' && val <= '_'))
			    val = val - ' ';	// subtract space
		    else val = 0; // space

            switch((hc11->regfile.PORTC.Read())&0x3)
            {
                case 0: m_d0.SetBitmap(b[val]);
                        break;
                case 1: m_d1.SetBitmap(b[val]);
                        break;
                case 2: m_d2.SetBitmap(b[val]);
                        break;
                case 3: m_d3.SetBitmap(b[val]);
                        break;
            }
        }
    }
    else
    {
        //Indicate the PIOC setup error
        m_error.SetWindowText("Incorrect PIOC Setup");
    }
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   Update
// Scope:           C7SegDlg
// Return Value:    <none>
// Usage:           Call this function to update the error message.
// Pre-Conditions:  The window must have been created.
// Post-Conditions: <none>
// Description:     This function will make sure the PIOC is set up properly otherwise
//                  it will display an error message on the display.
//
// Author:          Jake & Blake
// Created:         01/28/2001 16:33:20
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void C7SegDlg::Update ()
{
    //Get the PIOC register
    PIOCRegister PIOCReg = hc11->regfile.GetPIOCConst();
    
    //First check the PIOC levels, and display an error if the
    //indicated levels are not set correctly
    if((PIOCReg.bit0() == 0) && (PIOCReg.bit4() == 0))
    {
        m_error.SetWindowText(NULL);
    }
    else
    {
        //Indicate the PIOC setup error
        m_error.SetWindowText("Incorrect PIOC Setup");
    }
}
