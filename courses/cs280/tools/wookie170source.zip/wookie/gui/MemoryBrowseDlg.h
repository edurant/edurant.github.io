#if !defined(AFX_MEMORYBROWSEDLG_H__6E514F80_353F_11D2_AC60_004033510A08__INCLUDED_)
#define AFX_MEMORYBROWSEDLG_H__6E514F80_353F_11D2_AC60_004033510A08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MemoryBrowseDlg.h : header file
//
#include "../emu/hc11.h"
#include "memlistctrl.h"

/////////////////////////////////////////////////////////////////////////////
// CMemoryBrowseDlg dialog


//##ModelId=3A3D096D0319
class CMemoryBrowseDlg : public CDialog
{
// Construction
public:
	//##ModelId=3A3D096D0375
	CMemoryBrowseDlg(HC11 *hc11, CWnd* pParent = NULL);   // standard constructor

	//##ModelId=3A3D096D036B
    void Visible(bool);    
	//##ModelId=3A3D096D0373
    bool Visible(void){return visible;};    	
	//##ModelId=3A3D096D0369
	void Update(void);

// Dialog Data
	//{{AFX_DATA(CMemoryBrowseDlg)
	enum { IDD = IDD_MEMORY };
	//##ModelId=3A3D096D0343
	CButton	m_okb;
	//##ModelId=3A3D096D0339
	CButton	m_udpateb;
	//##ModelId=3A3D096D032F
	CMemListCtrl	m_listctrl;
	CMemListCtrl	m_listctrladdress;

	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemoryBrowseDlg)
	protected:
	//##ModelId=3A3D096D0362
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	//##ModelId=3A3D096D0327
	HC11 *hc11;
	//##ModelId=3A3D096D0324
	bool visible;
	// Generated message map functions
	//{{AFX_MSG(CMemoryBrowseDlg)
	//##ModelId=3A3D096D0360
	virtual BOOL OnInitDialog();
	//##ModelId=3A3D096D0359
	virtual void OnOK();
	//##ModelId=3A3D096D0357
	afx_msg void OnUpdate();
	//##ModelId=3A3D096D034B
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMORYBROWSEDLG_H__6E514F80_353F_11D2_AC60_004033510A08__INCLUDED_)
