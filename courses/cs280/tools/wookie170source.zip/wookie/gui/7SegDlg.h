#if !defined(AFX_7SEGDLG_H__D3FB26E3_A0D7_11D1_BF1F_0000C02D3FEE__INCLUDED_)
#define AFX_7SEGDLG_H__D3FB26E3_A0D7_11D1_BF1F_0000C02D3FEE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// 7SegDlg.h : header file
//
#include "../emu/hc11.h"

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: C7SegDlg 
//
// Author: Kalle Anderson
//
// Purpose: Works like the ascii display in the briefcase. Actually its not
//          7 segment, its more like 11 or something. PortC is used
//          to address the character position (0-3), and when a character
//          is written to port B, it is displayed. This works when STRB is
//          operating in mode 0, and the pulse is inverted.
//
/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////
// C7SegDlg dialog

//##ModelId=3A3D096E0361
class C7SegDlg : public CDialog, public PinConnection
{
// Construction
	//##ModelId=3A3D096E03AC
    bool visible;
	//##ModelId=3A3D096E03A9
    HC11 *hc11;

    #define NUMCHARS 64  // was 37 changed SLB, 3/13/99
    // the font for the 4 digit display
	//##ModelId=3A3D096E039D
    CBitmap b[NUMCHARS];
public:
	//##ModelId=3A3D096E03C8
	C7SegDlg(HC11 *nhc11, CWnd* pParent = NULL);   // standard constructor
    
    void Update ();

    // Hide or show this window
	//##ModelId=3A3D096E03BD
    void Visible(bool val);
	//##ModelId=3A3D096E03C6
    bool Visible(void){return visible;};    

	//##ModelId=3A3D096E03BB
    void Set(bit_t value);

// Dialog Data
	//{{AFX_DATA(C7SegDlg)
	enum { IDD = IDD_7SEG };
	CStatic	m_error;
	CStatic	m_d3;
	CStatic	m_d2;
	CStatic	m_d1;
	CStatic	m_d0;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(C7SegDlg)
	protected:
	//##ModelId=3A3D096E03B3
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(C7SegDlg)
	//##ModelId=3A3D096E03B1
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_7SEGDLG_H__D3FB26E3_A0D7_11D1_BF1F_0000C02D3FEE__INCLUDED_)
