// MemoryBrowseDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "MemoryBrowseDlg.h"
#include "ctrlext.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemoryBrowseDlg dialog


CMemoryBrowseDlg::CMemoryBrowseDlg(HC11 *phc11, CWnd* pParent /*=NULL*/)
	: CDialog(CMemoryBrowseDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMemoryBrowseDlg)
	//}}AFX_DATA_INIT
    Create(IDD_MEMORY, NULL);    
    visible = 0;    
    hc11 = phc11;
	m_listctrl.Initialize(hc11);
}


void CMemoryBrowseDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemoryBrowseDlg)
	DDX_Control(pDX, IDOK, m_okb);
	DDX_Control(pDX, IDC_UPDATE, m_udpateb);
	DDX_Control(pDX, IDC_LIST1, m_listctrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMemoryBrowseDlg, CDialog)
	//{{AFX_MSG_MAP(CMemoryBrowseDlg)
	ON_BN_CLICKED(IDC_UPDATE, OnUpdate)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemoryBrowseDlg message handlers

BOOL CMemoryBrowseDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMemoryBrowseDlg::Visible(bool val)
{
    visible = val;

    if(val)
    {
        ShowWindow(true);	            
    }
    else    
        ShowWindow(false);	        
}            

void CMemoryBrowseDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	Visible(0);
}

void CMemoryBrowseDlg::Update(void)
{
	m_listctrl.Invalidate(true);	
}

void CMemoryBrowseDlg::OnUpdate() 
{
	Update();
}

void CMemoryBrowseDlg::OnSize(UINT nType, int cx, int cy) 
{
	RECT rect;	

	CDialog::OnSize(nType, cx, cy);	
	// TODO: Add your message handler code here		
	if(m_listctrl.m_hWnd)
	{
		m_listctrl.MoveWindow(10, 10, cx - 20, cy - 50);

		m_udpateb.GetClientRect(&rect);				
		rect.top = cy - 10 - rect.bottom - rect.top;		
		rect.bottom = cy - 10;					
		rect.right = 10 + (rect.right - rect.left);
		rect.left = 10;		
		m_udpateb.MoveWindow(&rect);

		m_okb.GetClientRect(&rect);		
		rect.top = cy - 10 - rect.bottom - rect.top;
		rect.bottom = cy - 10;		
		rect.left = cx - 10 - (rect.right - rect.left);		
		rect.right = cx  - 10;				
		m_okb.MoveWindow(&rect);	
	}
}
