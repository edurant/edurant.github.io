// PinChoose.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "PinChoose.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPinChoose dialog


CPinChoose::CPinChoose(CWnd* pParent /*=NULL*/)
	: CDialog(CPinChoose::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPinChoose)
	m_port = 0;
	m_pin = 0;
	//}}AFX_DATA_INIT
}


void CPinChoose::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPinChoose)
	DDX_Radio(pDX, IDC_RADIO1, m_port);
	DDX_Radio(pDX, IDC_RADIO6, m_pin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPinChoose, CDialog)
	//{{AFX_MSG_MAP(CPinChoose)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPinChoose message handlers
