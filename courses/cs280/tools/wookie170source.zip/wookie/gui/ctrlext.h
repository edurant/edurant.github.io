//## begin module.additionalDeclarations preserve=yes
//## begin module.additionalDeclarations preserve=yes
//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes
//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1997 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#ifndef __TREECTLX_H__
#define __TREECTLX_H__
//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes

#ifdef _AFX_NO_AFXCMN_SUPPORT
	#error Windows Common Control classes not supported in this library variant.
#endif

#ifndef __AFXWIN_H__
	#include <afxwin.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// TREECTLX - MFC Tree Control Helper Classes

//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes
class CTreeCursor;
class CTreeCtrlEx;


/////////////////////////////////////////////////////////////////////////////
// CTreeCursor

//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes
//## end module.additionalDeclarations
//## begin module.additionalDeclarations preserve=yes
//## end module.additionalDeclarations
//## end module.additionalDeclarations
//##ModelId=3A3D096903C8
class CTreeCursor
{
	// Attributes
protected:
	//##ModelId=3A3D096903D7
	HTREEITEM	m_hTreeItem;
	//##ModelId=3A3D096903D4
	CTreeCtrlEx	*m_pTree;

	// Implementation
protected:
	//##ModelId=3A3D096A0077
	CTreeCursor CTreeCursor::_Insert(LPCTSTR strItem,int nImageIndex,HTREEITEM hAfter);

	// Operation
public:
	//##ModelId=3A3D096A006D
	CTreeCursor();
	//##ModelId=3A3D096A006E
	CTreeCursor(HTREEITEM hTreeItem, CTreeCtrlEx* pTree);
	//##ModelId=3A3D096A0071
	CTreeCursor(const CTreeCursor& posSrc);
	//##ModelId=3A3D096A006C
	~CTreeCursor();
	//##ModelId=3A3D096A0065
	const CTreeCursor& operator =(const CTreeCursor& posSrc);
	//##ModelId=3A3D096A0064
	operator HTREEITEM();

	//##ModelId=3A3D096A005C
	CTreeCursor InsertAfter(LPCTSTR strItem,HTREEITEM hAfter,int nImageIndex = -1);
	//##ModelId=3A3D096A0059
	CTreeCursor AddHead(LPCTSTR strItem,int nImageIndex = -1);
	//##ModelId=3A3D096A0052
	CTreeCursor AddTail(LPCTSTR strItem,int nImageIndex = -1);

	//##ModelId=3A3D096A0051
	int GetImageID();

	//##ModelId=3A3D096A004E
	BOOL GetRect(LPRECT lpRect, BOOL bTextOnly);
	//##ModelId=3A3D096A0047
	CTreeCursor GetNext(UINT nCode);
	//##ModelId=3A3D096A0046
	CTreeCursor GetChild();
	//##ModelId=3A3D096A0045
	CTreeCursor GetNextSibling();
	//##ModelId=3A3D096A0044
	CTreeCursor GetPrevSibling();
	//##ModelId=3A3D096A003E
	CTreeCursor GetParent();
	//##ModelId=3A3D096A003D
	CTreeCursor GetFirstVisible();
	//##ModelId=3A3D096A003C
	CTreeCursor GetNextVisible();
	//##ModelId=3A3D096A003B
	CTreeCursor GetPrevVisible();
	//##ModelId=3A3D096A003A
	CTreeCursor GetSelected();
	//##ModelId=3A3D096A0035
	CTreeCursor GetDropHilight();
	//##ModelId=3A3D096A0034
	CTreeCursor GetRoot();
	//##ModelId=3A3D096A0033
	CString GetText();
	//##ModelId=3A3D096A0030
	BOOL GetImage(int& nImage, int& nSelectedImage);
	//##ModelId=3A3D096A002A
	UINT GetState(UINT nStateMask);
	//##ModelId=3A3D096A0029
	DWORD GetData();
	//##ModelId=3A3D096A001D
	BOOL Set(UINT nMask, LPCTSTR lpszItem, int nImage,
		int nSelectedImage,	UINT nState, UINT nStateMask, LPARAM lParam);
	//##ModelId=3A3D096A0017
	BOOL SetText(LPCTSTR lpszItem);
	//##ModelId=3A3D096A0014
	BOOL SetImage(int nImage, int nSelectedImage);
	//##ModelId=3A3D096A000C
	BOOL SetState(UINT nState, UINT nStateMask);
	//##ModelId=3A3D096A000A
	BOOL SetData(DWORD dwData);
	//##ModelId=3A3D096A0009
	BOOL HasChildren();
// Operations
	//##ModelId=3A3D096A0008
	BOOL Delete();

	//##ModelId=3A3D096903E9
	BOOL Expand(UINT nCode = TVE_EXPAND);
	//##ModelId=3A3D096903E6
	BOOL Select(UINT nCode);
	//##ModelId=3A3D096903E8
	BOOL Select();
	//##ModelId=3A3D096903E0
	BOOL SelectDropTarget();
	//##ModelId=3A3D096903DF
	BOOL SelectSetFirstVisible();
	//##ModelId=3A3D096903DE
	CEdit* EditLabel();
	//##ModelId=3A3D096903DD
	CImageList* CreateDragImage();
	//##ModelId=3A3D096903DC
	BOOL SortChildren();
	//##ModelId=3A3D096903D8
	BOOL EnsureVisible();
};


/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlEx

//##ModelId=3A3D096C0295
class CTreeCtrlEx : public CTreeCtrl
{
	// Attributes
protected:

	// Operation
public:
	//##ModelId=3A3D096C02DC
	CTreeCtrlEx();
	//##ModelId=3A3D096C02DB
	~CTreeCtrlEx();
	//##ModelId=3A3D096C02D5
	CImageList* SetImageList(CImageList* pImageList, int nImageListType = TVSIL_NORMAL);

	//##ModelId=3A3D096C02D2
	CTreeCursor GetNextItem(HTREEITEM hItem, UINT nCode);
	//##ModelId=3A3D096C02CD
	CTreeCursor GetChildItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02CB
	CTreeCursor GetNextSiblingItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02C9
	CTreeCursor GetPrevSiblingItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02C7
	CTreeCursor GetParentItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02C1
	CTreeCursor GetFirstVisibleItem();
	//##ModelId=3A3D096C02BF
	CTreeCursor GetNextVisibleItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02BD
	CTreeCursor GetPrevVisibleItem(HTREEITEM hItem);
	//##ModelId=3A3D096C02BA
	CTreeCursor GetSelectedItem();
	//##ModelId=3A3D096C02B9
	CTreeCursor GetDropHilightItem();
	//##ModelId=3A3D096C02B8
	CTreeCursor GetRootItem();
	//##ModelId=3A3D096C02A0
	CTreeCursor InsertItem(LPTV_INSERTSTRUCT lpInsertStruct);
	//##ModelId=3A3D096C02A2
	CTreeCursor InsertItem(UINT nMask, LPCTSTR lpszItem, int nImage,
		int nSelectedImage,	UINT nState, UINT nStateMask, LPARAM lParam,
		HTREEITEM hParent, HTREEITEM hInsertAfter);
	//##ModelId=3A3D096C02AD
	CTreeCursor InsertItem(LPCTSTR lpszItem, HTREEITEM hParent = TVI_ROOT,
		HTREEITEM hInsertAfter = TVI_LAST);
	//##ModelId=3A3D096C02B1
	CTreeCursor InsertItem(LPCTSTR lpszItem, int nImage, int nSelectedImage,
		HTREEITEM hParent = TVI_ROOT, HTREEITEM hInsertAfter = TVI_LAST);
	//##ModelId=3A3D096C0297
	CTreeCursor HitTest(CPoint pt, UINT* pFlags = NULL);
	//##ModelId=3A3D096C029A
	CTreeCursor HitTest(TV_HITTESTINFO* pHitTestInfo);
};

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx

//##ModelId=3A3D096D0247
class CListCtrlEx : public CListCtrl
{
	// Attributes
protected:

	// Operation
public:
	//##ModelId=3A3D096D0261
	CListCtrlEx();
	//##ModelId=3A3D096D0260
	~CListCtrlEx();
	//##ModelId=3A3D096D025D
	CImageList* SetImageList(CImageList* pImageList, int nImageListType = TVSIL_NORMAL);
	//##ModelId=3A3D096D0256
	BOOL AddColumn(
		LPCTSTR strItem,int nItem,int nSubItem = -1,
		int nMask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM,
		int nFmt = LVCFMT_LEFT);
	//##ModelId=3A3D096D0251
	BOOL AddItem(int nItem,int nSubItem,LPCTSTR strItem,int nImageIndex = -1);
};


/////////////////////////////////////////////////////////////////////////////

#include "CtrlExt.inl"
//## begin module.epilog preserve=yes

#endif //__TREECTLX_H__
//## end module.epilog  
