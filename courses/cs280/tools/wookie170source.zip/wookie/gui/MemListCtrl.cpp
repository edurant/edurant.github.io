// MemListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "HardCoreWookie.h"
#include "MemListCtrl.h"
#include "inplaceedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemListCtrl

CMemListCtrl::CMemListCtrl()
{
}

CMemListCtrl::~CMemListCtrl()
{
}


BEGIN_MESSAGE_MAP(CMemListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CMemListCtrl)
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndlabeledit)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_LBUTTONDBLCLK()
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, OnGetdispinfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemListCtrl message handlers

void CMemListCtrl::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO *plvDispInfo = (LV_DISPINFO *)pNMHDR;
	LV_ITEM	*plvItem = &plvDispInfo->item;

	long index = plvItem->iItem;
	long subItem = 	plvItem->iSubItem;	
	int address, value;	
	
	if(plvDispInfo->item.mask & LVIF_TEXT)
	{	
		if(plvItem->pszText != NULL)
		{
			address = index*16 + subItem-1;

			value = -1;
			sscanf(plvItem->pszText,"%x",&value);		
			
			if(value != -1)		
				hc11->memory.Write(address, value);		
		}
	}

	*pResult = FALSE;
}

void CMemListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if( GetFocus() != this ) SetFocus();
	CListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CMemListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if( GetFocus() != this ) SetFocus();
	CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CMemListCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	int index;
	CListCtrl::OnLButtonDown(nFlags, point);

	int colnum;
	if( ( index = HitTestEx( point, &colnum )) != -1 )
	{
		if(colnum != 0)
			EditSubLabel( index, colnum );
	}
}

// HitTestEx	- Determine the row index and column index for a point
// Returns	- the row index or -1 if point is not over a row
// point	- point to be tested.
// col		- to hold the column index
int CMemListCtrl::HitTestEx(CPoint &point, int *col) const
{
	int colnum = 0;
	int row = HitTest( point, NULL );
	
	if( col ) *col = 0;

	// Make sure that the ListView is in LVS_REPORT
	if( (GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT )
		return row;

	// Get the top and bottom row visible
	row = GetTopIndex();
	int bottom = row + GetCountPerPage();
	if( bottom > GetItemCount() )
		bottom = GetItemCount();
	
	// Get the number of columns
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
	int nColumnCount = pHeader->GetItemCount();

	// Loop through the visible rows
	for( ;row <=bottom;row++)
	{
		// Get bounding rect of item and check whether point falls in it.
		CRect rect;
		GetItemRect( row, &rect, LVIR_BOUNDS );
		if( rect.PtInRect(point) )
		{
			// Now find the column
			for( colnum = 0; colnum < nColumnCount; colnum++ )
			{
				int colwidth = GetColumnWidth(colnum);
				if( point.x >= rect.left 
					&& point.x <= (rect.left + colwidth ) )
				{
					if( col ) *col = colnum;
					return row;
				}
				rect.left += colwidth;
			}
		}
	}
	return -1;
}

// EditSubLabel		- Start edit of a sub item label
// Returns		- Temporary pointer to the new edit control
// nItem		- The row index of the item to edit
// nCol			- The column of the sub item.
CEdit* CMemListCtrl::EditSubLabel( int nItem, int nCol )
{
	// The returned pointer should not be saved

	// Make sure that the item is visible
	if( !EnsureVisible( nItem, TRUE ) ) return NULL;

	// Make sure that nCol is valid
	CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
	int nColumnCount = pHeader->GetItemCount();
	if( nCol >= nColumnCount || GetColumnWidth(nCol) < 5 )
		return NULL;

	// Get the column offset
	int offset = 0;
	for( int i = 0; i < nCol; i++ )
		offset += GetColumnWidth( i );

	CRect rect;
	GetItemRect( nItem, &rect, LVIR_BOUNDS );

	// Now scroll if we need to expose the column
	CRect rcClient;
	GetClientRect( &rcClient );
	if( offset + rect.left < 0 || offset + rect.left > rcClient.right )
	{
		CSize size;
		size.cx = offset + rect.left;
		size.cy = 0;
		Scroll( size );
		rect.left -= size.cx;
	}

	// Get Column alignment
	LV_COLUMN lvcol;
	lvcol.mask = LVCF_FMT;
	GetColumn( nCol, &lvcol );
	DWORD dwStyle ;
	if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_LEFT)
		dwStyle = ES_LEFT;
	else if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_RIGHT)
		dwStyle = ES_RIGHT;
	else dwStyle = ES_CENTER;

	rect.left += offset+4;
	rect.right = rect.left + GetColumnWidth( nCol ) - 3 ;
	if( rect.right > rcClient.right) rect.right = rcClient.right;

	dwStyle |= WS_BORDER|WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL;
	CEdit *pEdit = new CInPlaceEdit(nItem, nCol, GetItemText( nItem, nCol ));
	pEdit->Create( dwStyle, rect, this, IDC_IPEDIT );


	return pEdit;
}


void CMemListCtrl::OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
		
	long index = pDispInfo->item.iItem;
	long subItem = 	pDispInfo->item.iSubItem;	
	int address, value;
	char text[10];

	if(pDispInfo->item.mask & LVIF_TEXT)
	{		
		if(subItem == 0 || subItem == 9 || subItem == 18)
		{
			address = index*16;
			sprintf(text, "%04X", address);
		}		
		else
		{
			// modified 2/29/2002 SLB, suggested by Eric Durant
			// address = index*16 + subItem-1;
			address = index*16 + (subItem-1) - (subItem > 9);

			value = (int)hc11->memory.Read(address);
			sprintf(text, "%02X", value);
		}
		lstrcpyn(pDispInfo->item.pszText, text, pDispInfo->item.cchTextMax);
		// moved into if, SLB 12/14/99
	}
	else
		if(pDispInfo->item.mask & LVIF_IMAGE)
		{
			pDispInfo->item.iImage = 0;//set image to first in list	*pResult = 0;} 
		}

	*pResult = 0;
}

void CMemListCtrl::Initialize(HC11 *phc11)
{
	hc11 = phc11;

	AddColumn("address",0);
	AddColumn("00",1);
	AddColumn("01",2);
	AddColumn("02",3);
	AddColumn("03",4);
	AddColumn("04",5);
	AddColumn("05",6);
	AddColumn("06",7);
	AddColumn("07",8);
	AddColumn("address",9);
	AddColumn("08",10);
	AddColumn("09",11);
	AddColumn("0A",12);
	AddColumn("0B",13);
	AddColumn("0C",14);
	AddColumn("0D",15);
	AddColumn("0E",16);
	AddColumn("0F",17);
	AddColumn("address",18);
	SetItemCount(0x10000/16);
};

