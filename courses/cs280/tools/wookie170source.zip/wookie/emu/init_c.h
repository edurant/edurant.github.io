////////////////////////////////////////////////////////////////////////////////
// File Name:       init_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:36:54
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(INIT_C_H)
#define INIT_C_H

#include "ByteRegister.h"

//##ModelId=3A3D099D0051
class INIT_C : public ByteRegister
{
public:
	//##ModelId=3A3D099D005E
    void Write(byte_t data);
	//##ModelId=3A3D099D005D
    void* regmap;
	//##ModelId=3A3D099D005C
    void* chip_ram;
};

#endif //!defined(INIT_C_H)
