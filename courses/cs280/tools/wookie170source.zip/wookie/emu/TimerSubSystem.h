#if !defined(TIMERSUBSYSTEM_H)
#define TIMERSUBSYSTEM_H

#include "basetypes.h"
class HC11;

/////////////////////////////////////////////////////////////////////////////
//
//  Class Name: TimerSubSystem
//
//  Author:  unknown
//
//  Purpose: Defines the TimerSubSystem which handles output compares and
//           the PulseAccumulator
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class TimerSubSystem into its own header
//
//     NOTE: THEY DID NOT IMPLEMENT A DESTRUCTOR!!!?!?!
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099C029E
class TimerSubSystem
{	
 protected:
 
 // Registers (in HC11::regfile)
	//##ModelId=3A3D099C02C8
	HC11* hc11;

 // Clock Dividers Counters	
	//##ModelId=3A3D099C02BE
	word_t	rti_clock_divider;
	//##ModelId=3A3D099C02B4
	word_t	pulse_accumulator_clock_divider;

 //	Functions
	// CHANGE THIS BACK TO PRIVATE!!!!
 public:
    // shouldn't be public, but the STOP opcode needs to access this

	//##ModelId=3A3D099C02A9
	word_t	main_clock_divider;
	//##ModelId=3A3D099C02DB
	void DoOutputCompares(void);
	//##ModelId=3A3D099C02D2
	void DoPulseAccumulator_GatedTimeAccumulationMode(void);

	//##ModelId=3A3D099C02D0
    TimerSubSystem(HC11 * nhc11);
	//##ModelId=3A3D099C02CB
	void ClockSystem(void);
};


#endif //!defined(TIMERSUBSYSTEM_H)
