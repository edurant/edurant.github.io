#include "stdafx.h"
#include "MemoryMap.h"


/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//  12/30/2000  BCA             Converted use of homegrown list to STL list
// 
/////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: MemoryMap::GetObject
//
// Author: Kalle Anderson
//
// Purpose: Finds the first MemoryObject containing the address and returns it.
//          
// Input Parameters: address
//
// Return Value: The memory object, or NULL if it wasn't found.
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////

MemoryObject *MemoryMap::GetObject(word_t address)
{
	MemoryObject *mo;
    std::list<MemoryObject *>::iterator index;

    // this will speed stuff up if there are a lot of continuous
    // accesses to the same region of memory, although I just
    // realized it will screw up the memory priority stuff, if
    // an internal and external block of memory are overlapping
    // so that is why it is comment out
//    if((mo_cache!=NULL) && mo_cache->Contains(address) && mo_cache->enable)		
//			return(mo_cache);		        

    index = map.begin();

    for(; index != map.end(); index++)
	{
        mo = *index;
		if(mo->Contains(address) && mo->enable)		
        {
            mo_cache=mo;
			return(mo);		
        }
	}	
	
	log("INVALID MEMORY ACCESS @ %X!\n",address);
	return (NULL);
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: MemoryMap::Read()
//
// Author: Kalle Anderson
//
// Purpose: Reads a memory address. If there is no object containing that
//          address, the thing it returns, is intenitally uninitialized garbage.
//          
// Input Parameters: address - the address
//
// Return Value: byte_t - the value read from memory
//
/////////////////////////////////////////////////////////////////////////////
byte_t MemoryMap::Read(word_t address)
{
    byte_t data;
    MemoryObject *mo = GetObject(address);

    if(mo)
	    data = mo->Read(address);

    return(data);
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: MemoryMap::Write
//
// Author: Kalle Anderson
//
// Purpose: write a byte to a memory location in the map. This finds the 
//          first memory object to contain the address, and writes the 
//          byte to it. If there is no memory object, it does nothing.
//                    
// Input Parameters: word_t address
//                   byte_t data
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////
void MemoryMap::Write(word_t address, byte_t data)
{    
    MemoryObject *mo = GetObject(address);

    if(mo)
	    mo->Write(address,data);
};

//////////////////////////////////////////////////////////////////////////////
// Function Name: MemoryMap::AddMemoryObject
//
// Author: Kalle Anderson
//
// Purpose: Add an object to the MemoryMap
//          
// Input Parameters: MemoryObject *mo - pointer to the object
//
// Return Value: None
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
void MemoryMap::AddMemoryObject(MemoryObject *mo)
{
    map.push_back(mo);
};


//////////////////////////////////////////////////////////////////////////////
// Function Name: MemoryMap::RemoveMemoryObject
//
// Author: Kalle Anderson
//
// Purpose: Remove an object from the MemoryMap
//          
// Input Parameters: MemoryObject *mo - pointer to the object to remove
//
// Return Value: bool - if it found the object
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////
bool MemoryMap::RemoveMemoryObject(MemoryObject *mo)
{	
    std::list<MemoryObject*>::iterator index = map.begin();

    for(; index != map.end(); index++)
	{
        if(mo == *index)
        {
            if(mo == mo_cache)
                mo_cache = NULL;
            map.remove(*index);            
            return(true);        
		}
	}		
	return (false);
};


//////////////////////////////////////////////////////////////////////////////
// Function Name: MemoryMap::MemoryMap()
// Purpose: None
/////////////////////////////////////////////////////////////////////////////
MemoryMap::MemoryMap()
{
    // nothing needs to be done here at this point
    mo_cache=NULL;
}

//////////////////////////////////////////////////////////////////////////////
// Function Name: MemoryMap::~MemoryMap()
//
// Author: Kalle Anderson
//
// Purpose: Destructor for the MemoryMap. This actually deletes all the memory
//          maps that it contains. 
//          
// Input Parameters: None
//
// Return Value: None
//
// Modification Log:
//  12/30/2000  BCA             Converted use of homegrown list to STL list
//
/////////////////////////////////////////////////////////////////////////////

MemoryMap::~MemoryMap()
{
	// Clean out the list
	MemoryObject *mo;
    std::list<MemoryObject*>::iterator index = map.begin();
	
    for(; index != map.end(); index++)
	{
		mo = *index;
		delete mo;
	}	
}