#if !defined(HANDSHAKEIOSUBSYSTEM_H)
#define HANDSHAKEIOSUBSYSTEM_H

#include "CMemoryObserver.h"
#include "ByteRegister.h"

#include "basetypes.h"
class HC11;

enum strobeState
{
    STAFSet,
    ReadPIOC,
    ReadPORTCL,
    WritePORTCL,
    STAFClear
};

/////////////////////////////////////////////////////////////////////////////
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class HandshakeIOSubSystem into its
//                              own header
//
//      NOTE: THERE IS NO DESTRUCTOR!!??!
/////////////////////////////////////////////////////////////////////////////

//##ModelId=3A3D099D037C
class HandshakeIOSubSystem : public CMemoryObserver
{
private:
	void CheckState(std::string& memoryID, const SubjectType operation);

	void STRAEdgeDetected(byte_t STRAvalue);

	strobeState currentState;

 protected:
 
 // Registers (in HC11::regfile)
	//##ModelId=3A3D099D0390
	HC11* hc11;
	//##ModelId=3A3D099D0386
    byte_t STRB_pulse;

 //	Functions
 public:
	virtual void Update(CMemorySubject& theSubject, enOperation theOperation);

	virtual ~HandshakeIOSubSystem();

	HandshakeIOSubSystem(const HandshakeIOSubSystem& orig);

	HandshakeIOSubSystem& operator=(HandshakeIOSubSystem& rhs);


	//##ModelId=3A3D099D039B
    void WriteToPORTB(void);
 
	//##ModelId=3A3D099D0395
    HandshakeIOSubSystem(HC11 * nhc11);
	//##ModelId=3A3D099D0393
	void ClockSystem(void);
};

#endif //!defined(HANDSHAKEIOSUBSYSTEM_H)
