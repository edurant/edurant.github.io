////////////////////////////////////////////////////////////////////////////////
// File Name:       ByteRegister.cpp
// Description:     ...
//
// Author:          JMB & BPF
// Created:         12/10/2000 17:16:40
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "ByteRegister.h"

byte_t ByteRegister::ReadMemory() const
{
	return byte;
}

void ByteRegister::WriteMemory(byte_t newValue)
{		
	byte = newValue;
}

ByteRegister& ByteRegister::operator=(const ByteRegister& rhs)
{
    //Only copy the value of the register
    if(this != &rhs)
    {
         Byte::operator=(rhs);
    }

    return (*this);
}

ByteRegister::~ByteRegister()
{
	// Nothing to do
}

ByteRegister::ByteRegister()
{
	// Nothing to do
}

ByteRegister::ByteRegister(const ByteRegister& rhs)
: Byte(rhs)
{

}


