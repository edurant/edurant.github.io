////////////////////////////////////////////////////////////////////////////////
// File Name:       stdafx.h
// Description:     ...
//
// Author:          JMB & BPF
// Created:         12/10/2000 16:54:41
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(STDAFX_H)
#define STDAFX_H

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#pragma warning(disable:4786)

#include <cstdio>
#include <cstdlib>
#include <cassert>

#include <list>
#include <set>
using std::set;
using std::list;

#include <string>

#define log(a,b) //fprintf(stderr,a,b)

#endif //!defined(STDAFX_H)