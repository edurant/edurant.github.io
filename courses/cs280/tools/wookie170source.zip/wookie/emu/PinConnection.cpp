#include "stdafx.h"
#include "PinConnection.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Set
//
// Author: Paul Clarke
//
// Purpose: Sets the level of a PinConnection.  When used correctly, this virtual
//          function is overriden by a derived class so this particular function
//          should never be called.
//
// Input Parameters: value - The level to be written to the PinConnection.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PinConnection::Set(bit_t value)
{
//	printf("Pin Updated %d\n",value);
}