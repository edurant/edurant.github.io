//////////////////////////////////////////////////////////////////////////////
//  Filename:	regfile.cpp
//		
//    Purpose:	Contains the overriden functions for the register file.  All the
//    functions in this file are here because specific things happen
//    to the HC11 when bits of certain registers are set or cleared.
//
//    Author(s):	Paul Clarke, Kalle Anderson, Jason Buttron
//
//////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "regfile.h"
#include "memory.h"

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: <>
//
// Author: <>
//
// Purpose: <>
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////
// RegisterFile functions

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: RegisterFile
//
// Author: Paul Clarke
//
// Purpose: Constructs a RegisterFile object and initializes it.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
RegisterFile::RegisterFile()
{
	// Associate the DD registers to their ports
	DDRC.Associate(&PORTC);
	DDRD.Associate(&PORTD);

	// Set some pointer members to associated registers.
	TCTL1.portA = &PORTA;
	PACTL.portA = &PORTA;
	PACTL.oc1m = &OC1M;
	OC1M.portA = &PORTA;
	OC1M.tctl1 = &TCTL1;
	OC1M.pactl = &PACTL;
	CFORC.portA = &PORTA;
	CFORC.oc1m = &OC1M;
	CFORC.oc1d = &OC1D;
	CFORC.tctl1 = &TCTL1;
	SPCR.ddrd = &DDRD;
	SPCR.portD = &PORTD;

	// Make Port E an input port
  for(int i=0;i<8;i++)
      PORTE.SetMode(i, Pin::INPUT);   
  // port a and b configure themselves
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Reset
//
// Author: Paul Clarke
//
// Purpose: To set the registers to their reset state.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void RegisterFile::Reset(Mode mode /*=SPECIAL_TEST*/)
{
	PORTA.Write(0x0);
	PIOC.Write(0x3);	// Bit 2 (PLS) is U
	PORTB.Write(0x0);	// Port B is an output port
	DDRC.Write(0x0);
	DDRD.Write(0x0);
	// Set the ports later, so the direction modes are initialized first
	PORTC.Write(0x0);
	PORTD.Write(0x0);
	PORTCL.Write(0x0);
	PORTE.Write(0x0);		// Port E is an input port
	CFORC.Write(0x0);
	OC1M.Write(0x0);
	OC1D.Write(0x0);
	TCNT.Write(0x0);
	// TICx registers not affected by reset
	TOC1.Write(0xffff);
	TOC2.Write(0xffff);
	TOC3.Write(0xffff);
	TOC4.Write(0xffff);
	TI4O5.Write(0xffff);
	TCTL1.Write(0x0);
	TCTL2.Write(0x0);	
	TMSK1.Write(0x0);
	TFLG1.Write(0x0);
	TMSK2.Write(0x0);
	TFLG2.Write(0x0);
	PACTL.Write(0x0);
	PACNT.Write(0x0);		// Completely U
	SPCR.Write(0x4);  // Bits 0,1 are U
	SPSR.Write(0x0);
	BAUD.Write(0x0);	// Bits 0,1,2 are U
	SCCR1.Write(0x0);	// Bits 6,7 are U
	SCCR2.Write(0x0);
	SCSR.Write(0xc0);
	SCDR.Write(0x0);	// Completely U
	ADCTL.Write(0x0); // Bits 0-5 are U
	ADR1.Write(0x0);	//  A/D input regs
	ADR2.Write(0x0);	
	ADR3.Write(0x0);	
	ADR4.Write(0x0);

	OPTION.Write(0x0);	// No delay
	COPRST.Write(0x0);	// COP register, don't care
	PPROG.Write(0x0);

	INIT.Write(0x1);
	
	// HPRIO reg on reset
	if (mode == SINGLE_CHIP)
		HPRIO.Write(0x5);
	else if (mode == EXPANDED)
		HPRIO.Write(0x25);
	else if (mode == BOOTSTRAP)
		HPRIO.Write(0xc5);
	else if (mode == SPECIAL_TEST)
		HPRIO.Write(0x75);

	TEST1.Write(0x0);
	CONFIG.Write(0xc);	// NOSEC and NOCOP high
}






PIOCRegister& RegisterFile::GetPIOC()
{
	return(PIOC);
}

const PIOCRegister& RegisterFile::GetPIOCConst() const
{
	return(PIOC);
}

PORTCLRegister& RegisterFile::GetPORTCL()
{
	return(PORTCL);
}

const PORTCLRegister& RegisterFile::GetPORTCLConst() const
{
	return(PORTCL);
}


