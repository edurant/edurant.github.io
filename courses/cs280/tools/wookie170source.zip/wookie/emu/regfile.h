// File: regfile.h

// This file contains the definitions of all of the registers
// and all of their accessors and mutators

#ifndef REGFILE_H
#define REGFILE_H

enum Mode { BOOTSTRAP, SPECIAL_TEST, SINGLE_CHIP, EXPANDED};

#include "PinConnection.h"
#include "Pin.h"
#include "PortConnection.h"
#include "PortRegister.h"
#include "PortARegister.h"
#include "PortBRegister.h"
#include "DDRegister.h"
#include "WordRegister.h"
#include "ByteRegister.h"

#include "MemoryObject.h"
#include "RegisterMap.h"
#include "RAM.h"
#include "ROM.h"
#include "MemoryMap.h"

#include "tctl1_c.h"
#include "oc1m_c.h"
#include "pactl_c.h"
#include "init_c.h"
#include "hprio_c.h"
#include "tflg_c.h"
#include "spcr_c.h"
#include "cforc_c.h"

#include "PIOCRegister.h"
#include "PORTCLRegister.h"

// Bit field masks
#define MASK_01 0x3
#define MASK_23 0xc
#define MASK_45 0x30
#define MASK_67 0xc0
#define MASK_0123 0xf
#define MASK_4567 0xf0
#define MASK_34567 0xf8
#define MASK_12 0x6
#define MASK_012 0x7


////////////////////////////////////////////////////////////////////////////////
// Class Name:      RegisterFile
// Usage:           ...
// Description:     ...
//
// Author:          JMB & BPF
// Created:         12/10/2000 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  12/10/2000  JMB & BPF       Removed the nested classes into their own files.
//	12/17/2000	BPF & ILK		Fixed include Typo of "cfor_c.h"
////////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D09A70023
class RegisterFile
{
public:
	PIOCRegister& GetPIOC();

	const PIOCRegister& GetPIOCConst() const;

	PORTCLRegister& GetPORTCL();

	const PORTCLRegister& GetPORTCLConst() const;


  // Memory object pointers
  // Will cast to their associated types later in the code!

	//##ModelId=3A3D09A7033A
  PortARegister PORTA;
  // Reserved at 0x1001
	//##ModelId=3A6B49A00346
  PIOCRegister PIOC;
	//##ModelId=3A3D09A70312
  PortRegister PORTC;
	//##ModelId=3A3D09A70300
  PortBRegister PORTB;
	//##ModelId=3A6B49E5033C
  PORTCLRegister PORTCL;
  // Reserved at 0x1006
	//##ModelId=3A3D09A702D8
  DDRegister DDRC;
	//##ModelId=3A3D09A702CC
  PortRegister PORTD;
	//##ModelId=3A3D09A702B8
  DDRegister DDRD;
	//##ModelId=3A3D09A702A6
  PortRegister PORTE;
	//##ModelId=3A3D09A70292
  CFORC_C      CFORC; // a custom reg
	//##ModelId=3A3D09A70286
  OC1M_C       OC1M;  // a custom reg
	//##ModelId=3A3D09A70272
  ByteRegister OC1D;  // a custom reg
	//##ModelId=3A3D09A7025E
  WordRegister TCNT;  
	//##ModelId=3A3D09A7024A
  WordRegister TIC1;
	//##ModelId=3A3D09A70238
  WordRegister TIC2;
	//##ModelId=3A3D09A7022C
  WordRegister TIC3;
	//##ModelId=3A3D09A70218
  WordRegister TOC1;
	//##ModelId=3A3D09A70206
  WordRegister TOC2;
	//##ModelId=3A3D09A701FA
  WordRegister TOC3;
	//##ModelId=3A3D09A701E6
  WordRegister TOC4;
	//##ModelId=3A3D09A701D4
  WordRegister TI4O5;
	//##ModelId=3A3D09A701C8
  TCTL1_C      TCTL1;  // a custom reg
	//##ModelId=3A3D09A701B4
  ByteRegister TCTL2;  // a custom reg
	//##ModelId=3A3D09A701A2
  ByteRegister TMSK1;  // a custom reg
	//##ModelId=3A3D09A70196
  TFLG_C      TFLG1;  // a custom reg
	//##ModelId=3A3D09A70184
  ByteRegister TMSK2;  // a custom reg
	//##ModelId=3A3D09A70178
  TFLG_C      TFLG2;  // a custom reg
	//##ModelId=3A3D09A70166
  PACTL_C      PACTL;  // a custom reg
	//##ModelId=3A3D09A70152
  ByteRegister PACNT;
	//##ModelId=3A3D09A70148
  SPCR_C     SPCR;  // a custom reg
	//##ModelId=3A3D09A70134
  ByteRegister SPSR;  // a custom reg
	//##ModelId=3A3D09A7012A
  ByteRegister SPDR;
	//##ModelId=3A3D09A70116
  ByteRegister BAUD;  // a custom reg
	//##ModelId=3A3D09A7010A
  ByteRegister SCCR1;  // a custom reg
	//##ModelId=3A3D09A700F8
  ByteRegister SCCR2;  // a custom reg
	//##ModelId=3A3D09A700EC
  ByteRegister SCSR;  // a custom reg
	//##ModelId=3A3D09A700DA
  ByteRegister SCDR;  // a custom reg
	//##ModelId=3A3D09A700CE
  ByteRegister ADCTL;  // a custom reg
	//##ModelId=3A3D09A700BC
  ByteRegister ADR1;
	//##ModelId=3A3D09A700B2
  ByteRegister ADR2;
	//##ModelId=3A3D09A7009E
  ByteRegister ADR3;
	//##ModelId=3A3D09A70093
  ByteRegister ADR4;
	//##ModelId=3A3D09A70089
  ByteRegister BPROT;  // a custom reg
	//##ModelId=3A3D09A70075
  ByteRegister EPROG;  // a custom reg
  // Reserved at 0x1037
  // Reserved at 0x1038
	//##ModelId=3A3D09A7006B
  ByteRegister OPTION;  // a custom reg
	//##ModelId=3A3D09A70061
  ByteRegister COPRST;
	//##ModelId=3A3D09A70055
  ByteRegister PPROG;  // a custom reg
	//##ModelId=3A3D09A7004D
  HPRIO_C     HPRIO;  // a custom reg
	//##ModelId=3A3D09A70041
  INIT_C       INIT;  // a custom reg
	//##ModelId=3A3D09A70037
  ByteRegister TEST1;  // a custom reg
	//##ModelId=3A3D09A70026
  ByteRegister CONFIG;  // a custom reg
  

  // Constructor and Reset function
	//##ModelId=3A3D09AC0021
  RegisterFile();
	//##ModelId=3A3D09AC000C
  void Reset(Mode = SPECIAL_TEST);


/*******************************************************************************

    Register Bit Functions - Accessors and Mutators

/*******************************************************************************/

  ////////////////////////////////////////////////////////
  // OPTION Register function declarations
  // Accessors
  // CR is 2 bits
	//##ModelId=3A3D09AB03D6
  inline byte_t CR()  { return (OPTION.byte&0x3); }                                                                                         
  // Bit 2 is unused
	//##ModelId=3A3D09AB03B8
  inline bit_t CME()  { return OPTION.bit3(); }
	//##ModelId=3A3D09AB03A4
  inline bit_t DLY()  { return OPTION.bit4(); }
	//##ModelId=3A3D09AB0386
  inline bit_t IRQE() { return OPTION.bit5(); }
	//##ModelId=3A3D09AB0368
  inline bit_t CSEL() { return OPTION.bit6(); }
	//##ModelId=3A3D09AB034A
  inline bit_t ADPU() { return OPTION.bit7(); }

  // Mutators
  // CR is two bits
	//##ModelId=3A3D09AB03E0
  inline void CR(byte_t val)  { OPTION.byte = OPTION.byte&(~MASK_01)|(val&MASK_01); }
	//##ModelId=3A3D09AB03C2
  inline void CME(bit_t val)  { OPTION.bit3(val); }
	//##ModelId=3A3D09AB03A5
  inline void DLY(bit_t val)  { OPTION.bit4(val); }
	//##ModelId=3A3D09AB0387
  inline void IRQE(bit_t val) { OPTION.bit5(val); }
	//##ModelId=3A3D09AB0372
  inline void CSEL(bit_t val) { OPTION.bit6(val); }
	//##ModelId=3A3D09AB0354
  inline void ADPU(bit_t val) { OPTION.bit7(val); }


  ////////////////////////////////////////////////////////
  // PPROG Register
  // Accessors
	//##ModelId=3A3D09AB0336
  inline bit_t EPGM() { return PPROG.bit0(); }
	//##ModelId=3A3D09AB0318
  inline bit_t EELAT()  { return PPROG.bit1(); }
	//##ModelId=3A3D09AB02FA
  inline bit_t ERASE()  { return PPROG.bit2(); }
	//##ModelId=3A3D09AB02DC
  inline bit_t ROW()    { return PPROG.bit3(); }
	//##ModelId=3A3D09AB02C8
  inline bit_t BYTE() { return PPROG.bit4(); }
	//##ModelId=3A3D09AB02AA
  inline bit_t ELAT3()  { return PPROG.bit5(); }
	//##ModelId=3A3D09AB028C
  inline bit_t EVEN() { return PPROG.bit6(); }
	//##ModelId=3A3D09AB026E
  inline bit_t ODD()    { return PPROG.bit7(); }

  // Mutators
	//##ModelId=3A3D09AB0337
  inline void EPGM(bit_t val)   { PPROG.bit0(val); }
	//##ModelId=3A3D09AB0319
  inline void EELAT(bit_t val)  { PPROG.bit1(val); }
	//##ModelId=3A3D09AB0304
  inline void ERASE(bit_t val)  { PPROG.bit2(val); }
	//##ModelId=3A3D09AB02E6
  inline void ROW(bit_t val)    { PPROG.bit3(val); }
	//##ModelId=3A3D09AB02C9
  inline void BYTE(bit_t val)   { PPROG.bit4(val); }
	//##ModelId=3A3D09AB02AB
  inline void ELAT3(bit_t val)  { PPROG.bit5(val); }
	//##ModelId=3A3D09AB028D
  inline void EVEN(bit_t val)   { PPROG.bit6(val); }
	//##ModelId=3A3D09AB0278
  inline void ODD(bit_t val)    { PPROG.bit7(val); }


  ////////////////////////////////////////////////////////
  // HPRIO Register 
  // Accessors
  // PSEL is 4 bits
	//##ModelId=3A3D09AB025A
  inline byte_t PSEL()  { return HPRIO.byte&0xf; }
	//##ModelId=3A3D09AB023C
  inline bit_t IRVNE()  { return HPRIO.bit4(); }
	//##ModelId=3A3D09AB021E
  inline bit_t MDA()    { return HPRIO.bit5(); }
	//##ModelId=3A3D09AB0200
  inline bit_t SMOD()   { return HPRIO.bit6(); }
	//##ModelId=3A3D09AB01EC
  inline bit_t RBOOT()  { return HPRIO.bit7(); }

  // Mutators
  // PSEL is 4 bits
	//##ModelId=3A3D09AB025B
  inline void PSEL(bit_t val) { HPRIO.byte = HPRIO.byte&(~MASK_0123)|(val&MASK_0123); }
	//##ModelId=3A3D09AB023D
  inline void IRVNE(bit_t val){ HPRIO.bit4(val); }
	//##ModelId=3A3D09AB021F
  inline void MDA(bit_t val)  { HPRIO.bit5(val); }
	//##ModelId=3A3D09AB020A
  inline void SMOD(bit_t val) { HPRIO.bit6(val); }
	//##ModelId=3A3D09AB01ED
  inline void RBOOT(bit_t val){ HPRIO.bit7(val); }
  
  ////////////////////////////////////////////////////////
  // INIT Register  

  // TO WRITE TO THE INIT REGISTER, YOU MUST USE THE INIT::Write() FUNCTION!!!
  
  // Accessors
  // REG is 4 bits
  //  inline byte_t REG() { return (INIT.byte&0xf); }
  // RAM is 4 bits
  //  inline byte_t RAM() { return (INIT.byte&0xf0)>>4; }

  // Mutators
  // REG is 4 bits
  //  inline void REG(byte_t val) { INIT.byte = INIT.byte&(~MASK_0123)|(val&MASK_0123); } 
  // RAM is 4 bits
  //  inline void RAM(byte_t val) { INIT.byte = INIT.byte&(~MASK_4567)|(val<<4)&MASK_4567; }  

  ////////////////////////////////////////////////////////
  // TEST1 Register
  // Accessors
	//##ModelId=3A3D09AB01CE
  inline bit_t TCON() { return TEST1.bit0(); }
	//##ModelId=3A3D09AB01B0
  inline bit_t FCOP() { return TEST1.bit1(); }
	//##ModelId=3A3D09AB0192
  inline bit_t FCM()  { return TEST1.bit2(); }
	//##ModelId=3A3D09AB017E
  inline bit_t DISR() { return TEST1.bit3(); }
	//##ModelId=3A3D09AB0160
  inline bit_t CBYP() { return TEST1.bit4(); }
	//##ModelId=3A3D09AB0141
  inline bit_t OCCR() { return TEST1.bit5(); }
  // Bit 6 is unused
	//##ModelId=3A3D09AB0123
  inline bit_t TILOP()  { return TEST1.bit7(); }

  // Mutators
	//##ModelId=3A3D09AB01CF
  inline void TCON(bit_t val) { TEST1.bit0(val); }
	//##ModelId=3A3D09AB01B1
  inline void FCOP(bit_t val) { TEST1.bit1(val); }
	//##ModelId=3A3D09AB019C
  inline void FCM(bit_t val)  { TEST1.bit2(val); }
	//##ModelId=3A3D09AB017F
  inline void DISR(bit_t val) { TEST1.bit3(val); }
	//##ModelId=3A3D09AB0161
  inline void CBYP(bit_t val) { TEST1.bit4(val); }
	//##ModelId=3A3D09AB0142
  inline void OCCR(bit_t val) { TEST1.bit5(val); }
  // Bit 6 is unused
	//##ModelId=3A3D09AB012D
  inline void TILOP(bit_t val){ TEST1.bit7(val); }

  
  ////////////////////////////////////////////////////////
  // CONFIG Register
  // Accessors
	//##ModelId=3A3D09AB010F
  inline bit_t EEON() { return CONFIG.bit0(); }
	//##ModelId=3A3D09AB00F1
  inline bit_t ROMON()  { return CONFIG.bit1(); }
	//##ModelId=3A3D09AB00D3
  inline bit_t NOCOP()  { return CONFIG.bit2(); }
	//##ModelId=3A3D09AB00B5
  inline bit_t NOSEC()  { return CONFIG.bit3(); }
  // EE is 4 bits
	//##ModelId=3A3D09AB0097
  inline byte_t EE()  { return (CONFIG.byte&MASK_4567)>>4;  }
  
  // Mutators
	//##ModelId=3A3D09AB0110
  inline void EEON(bit_t val) { CONFIG.bit0(val); }
	//##ModelId=3A3D09AB00F2
  inline void ROMON(bit_t val)  { CONFIG.bit1(val); }
	//##ModelId=3A3D09AB00D4
  inline void NOCOP(bit_t val)  { CONFIG.bit2(val); }
	//##ModelId=3A3D09AB00BF
  inline void NOSEC(bit_t val)  { CONFIG.bit3(val); }
  // EE is 4 bits
	//##ModelId=3A3D09AB00A1
  inline void EE(byte_t val)    { CONFIG.byte = CONFIG.byte&(~MASK_4567)|(val<<4)&MASK_4567; }  


  ////////////////////////////////////////////////////////
  // TCTL1 Register
  // Accessors
	//##ModelId=3A3D09AB0083
  inline bit_t OL5()  { return TCTL1.bit0(); }
	//##ModelId=3A3D09AB0065
  inline bit_t OM5()  { return TCTL1.bit1(); }
	//##ModelId=3A3D09AB0047
  inline bit_t OL4()  { return TCTL1.bit2(); }
	//##ModelId=3A3D09AB0029
  inline bit_t OM4()  { return TCTL1.bit3(); }
	//##ModelId=3A3D09AB0015
  inline bit_t OL3()  { return TCTL1.bit4(); }
	//##ModelId=3A3D09AA03DF
  inline bit_t OM3()  { return TCTL1.bit5(); }
	//##ModelId=3A3D09AA03C1
  inline bit_t OL2()  { return TCTL1.bit6(); }
	//##ModelId=3A3D09AA03A3
  inline bit_t OM2()  { return TCTL1.bit7(); }

  // Mutators
  // These pins activate or deactivate the pin action for
  // the output compares Port A pins
  // PA3 - OC5
  // PA4 - OC4
  // PA5 - OC3
  // PA6 - OC2
  // PA7 - OC1
	//##ModelId=3A3D09AB0084
  inline void OL5(bit_t val)  { TCTL1.bit0(val); 
                                if (OL5() || OM5()) 
                                  PORTA.SetMode(3,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(3,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AB0066
  inline void OM5(bit_t val)  { TCTL1.bit1(val); 
                                if (OL5() || OM5()) 
                                  PORTA.SetMode(3,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(3,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AB0051
  inline void OL4(bit_t val)  { TCTL1.bit2(val); 
                                if (OL4() || OM4()) 
                                  PORTA.SetMode(4,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(4,Pin::OUTPUT); 
                                }
	//##ModelId=3A3D09AB0033
  inline void OM4(bit_t val)  { TCTL1.bit3(val); 
                                if (OL4() || OM4()) 
                                  PORTA.SetMode(4,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(4,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AB0016
  inline void OL3(bit_t val)  { TCTL1.bit4(val); 
                                if (OL3() || OM3()) 
                                  PORTA.SetMode(5,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(5,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AA03E0
  inline void OM3(bit_t val)  { TCTL1.bit5(val); 
                                if (OL3() || OM3()) 
                                  PORTA.SetMode(5,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(5,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AA03CB
  inline void OL2(bit_t val)  { TCTL1.bit6(val); 
                                if (OL2() || OM2()) 
                                  PORTA.SetMode(6,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(6,Pin::OUTPUT); 
                              }
	//##ModelId=3A3D09AA03AD
  inline void OM2(bit_t val)  { TCTL1.bit7(val); 
                                if (OL2() || OM2()) 
                                  PORTA.SetMode(6,Pin::AUTO); 
                                else 
                                  PORTA.SetMode(6,Pin::OUTPUT); 
                              }


  ////////////////////////////////////////////////////////
  // TCTL2 Register
  // Accessors
  // EDG3 is 2 bits
	//##ModelId=3A3D09AA038F
  inline byte_t EDG3()  { return TCTL2.byte&0x3; }
  // EDG2 is 2 bits
	//##ModelId=3A3D09AA0371
  inline byte_t EDG2() { return (TCTL2.byte&0xc)>>2; }
  // EDG1 is 2 bits
	//##ModelId=3A3D09AA0353
  inline byte_t EDG1()  { return (TCTL2.byte&0x30)>>4; }
  // EDG4 is 2 bits
	//##ModelId=3A3D09AA0337
  inline byte_t EDG4() { return (TCTL2.byte&0xc0)>>6; }
  
  // Mutators
  // EDG3 is 2 bits
	//##ModelId=3A3D09AA0390
  inline void EDG3(byte_t val) { TCTL2.byte = TCTL2.byte&(~MASK_01)|(val&MASK_01);      }
  // EDG2 is 2 bits
	//##ModelId=3A3D09AA0372
  inline void EDG2(byte_t val)  { TCTL2.byte = TCTL2.byte&(~MASK_23)|(val<<2)&MASK_23;  }
  // EDG1 is 2 bits
	//##ModelId=3A3D09AA035D
  inline void EDG1(byte_t val) { TCTL2.byte = TCTL2.byte&(~MASK_45)|(val<<4)&MASK_45; }
  // EDG4 is 2 bits
	//##ModelId=3A3D09AA033F
  inline void EDG4(byte_t val) { TCTL2.byte = TCTL2.byte&(~MASK_67)|(val<<6)&MASK_67; } 


  ////////////////////////////////////////////////////////
  // CFORC Register
  // Accessors
  // First three bits are unused
	//##ModelId=3A3D09AA0336
  inline bit_t FOC5() { return CFORC.bit3(); }
	//##ModelId=3A3D09AA0335
  inline bit_t FOC4() { return CFORC.bit4(); }
	//##ModelId=3A3D09AA032C
  inline bit_t FOC3() { return CFORC.bit5(); }
	//##ModelId=3A3D09AA032B
  inline bit_t FOC2() { return CFORC.bit6(); }
	//##ModelId=3A3D09AA0321
  inline bit_t FOC1() { return CFORC.bit7(); }

  // These bit mutators are disabled because nowhere in the HC11 is this 
  // register written to.
  // Mutators
  // First three bits are unused
/*  inline void FOC5(bit_t val) { CFORC.bit3(val); }
  inline void FOC4(bit_t val) { CFORC.bit4(val); }
  inline void FOC3(bit_t val) { CFORC.bit5(val); }
  inline void FOC2(bit_t val) { CFORC.bit6(val); }
  inline void FOC1(bit_t val) { CFORC.bit7(val); }
*/
  ////////////////////////////////////////////////////////
  // OC1M Register
  // Accessors
  // First three bits are unused
	//##ModelId=3A3D09AA030D
  inline bit_t OC1M3() { return OC1M.bit3(); }
	//##ModelId=3A3D09AA02EF
  inline bit_t OC1M4() { return OC1M.bit4(); }
	//##ModelId=3A3D09AA02D1
  inline bit_t OC1M5() { return OC1M.bit5(); }
	//##ModelId=3A3D09AA02B3
  inline bit_t OC1M6() { return OC1M.bit6(); }
	//##ModelId=3A3D09AA029F
  inline bit_t OC1M7() { return OC1M.bit7(); }

  // Mutators
  // First three bits are unused
  
  // Each of this bits may affect Port A pin modes!
	//##ModelId=3A3D09AA030E
  inline void OC1M3(bit_t val) { OC1M.bit3(val); 
                                  if (val) 
                                    PORTA.SetMode(3,Pin::AUTO);
                                  else 
                                    PORTA.SetMode(3,Pin::OUTPUT);
                                }
	//##ModelId=3A3D09AA02F0
  inline void OC1M4(bit_t val) { OC1M.bit4(val); 
                                  if (val)
                                    PORTA.SetMode(4,Pin::AUTO);
                                  else 
                                    PORTA.SetMode(4,Pin::OUTPUT);
                                }
	//##ModelId=3A3D09AA02DB
  inline void OC1M5(bit_t val) { OC1M.bit5(val); 
                                  if (val) 
                                    PORTA.SetMode(5,Pin::AUTO);
                                  else 
                                    PORTA.SetMode(5,Pin::OUTPUT);
                                }
	//##ModelId=3A3D09AA02BD
  inline void OC1M6(bit_t val) { OC1M.bit6(val); 
                                  if (val)
                                    PORTA.SetMode(6,Pin::AUTO);
                                  else 
                                    PORTA.SetMode(6,Pin::OUTPUT);
                                }
	//##ModelId=3A3D09AA02A0
  inline void OC1M7(bit_t val) { OC1M.bit7(val); 
                                  if (val) 
                                  {
                                    if (PORTA.GetMode(7) == Pin::OUTPUT)
                                      PORTA.SetMode(7,Pin::AUTO);
                                  }
                                  else if (PACTL.bit7())
                                    PORTA.SetMode(7,Pin::OUTPUT);
                                  else 
                                    PORTA.SetMode(7,Pin::INPUT);
                                }

  ////////////////////////////////////////////////////////
  // OC1D Register
  // Accessors
  // First three bits are unused
  // OC1M is 5 bits
	//##ModelId=3A3D09AA0281
  inline bit_t OC1D3() { return OC1D.bit3(); }
	//##ModelId=3A3D09AA0262
  inline bit_t OC1D4() { return OC1D.bit4(); }
	//##ModelId=3A3D09AA0244
  inline bit_t OC1D5() { return OC1D.bit5(); }
	//##ModelId=3A3D09AA0230
  inline bit_t OC1D6() { return OC1D.bit6(); }
	//##ModelId=3A3D09AA0212
  inline bit_t OC1D7() { return OC1D.bit7(); }
  
  // Mutators
  // First three bits are unused  
  // OC1M is 5 bits
	//##ModelId=3A3D09AA0282
  inline void OC1D3(bit_t val) { OC1D.bit3(val); }
	//##ModelId=3A3D09AA026C
  inline void OC1D4(bit_t val) { OC1D.bit4(val); }
	//##ModelId=3A3D09AA024E
  inline void OC1D5(bit_t val) { OC1D.bit5(val); }
	//##ModelId=3A3D09AA0231
  inline void OC1D6(bit_t val) { OC1D.bit6(val); }
	//##ModelId=3A3D09AA0213
  inline void OC1D7(bit_t val) { OC1D.bit7(val); }

  ////////////////////////////////////////////////////////
  // TMSK1 Register
  // Accessors
	//##ModelId=3A3D09AA01F4
  inline bit_t IC3I() { return TMSK1.bit0(); }
	//##ModelId=3A3D09AA01D6
  inline bit_t IC2I() { return TMSK1.bit1(); }
	//##ModelId=3A3D09AA01C2
  inline bit_t IC1I() { return TMSK1.bit2(); }
	//##ModelId=3A3D09AA01A4
  inline bit_t I4O5I(){ return TMSK1.bit3(); }
	//##ModelId=3A3D09AA0186
  inline bit_t OC4I() { return TMSK1.bit4(); }
	//##ModelId=3A3D09AA0168
  inline bit_t OC3I() { return TMSK1.bit5(); }
	//##ModelId=3A3D09AA0154
  inline bit_t OC2I() { return TMSK1.bit6(); }
	//##ModelId=3A3D09AA0136
  inline bit_t OC1I() { return TMSK1.bit7(); }

  // Mutators
	//##ModelId=3A3D09AA01FE
  inline void IC3I(bit_t val) { TMSK1.bit0(val); }
	//##ModelId=3A3D09AA01E0
  inline void IC2I(bit_t val) { TMSK1.bit1(val); }
	//##ModelId=3A3D09AA01C3
  inline void IC1I(bit_t val) { TMSK1.bit2(val); }
	//##ModelId=3A3D09AA01A5
  inline void I4O5I(bit_t val){ TMSK1.bit3(val); }
	//##ModelId=3A3D09AA0190
  inline void OC4I(bit_t val) { TMSK1.bit4(val); }
	//##ModelId=3A3D09AA0172
  inline void OC3I(bit_t val) { TMSK1.bit5(val); }
	//##ModelId=3A3D09AA0155
  inline void OC2I(bit_t val) { TMSK1.bit6(val); }
	//##ModelId=3A3D09AA0140
  inline void OC1I(bit_t val) { TMSK1.bit7(val); }

  ////////////////////////////////////////////////////////
  // TFLG1 Register
  // Accessors
	//##ModelId=3A3D09AA0118
  inline bit_t IC3F() { return TFLG1.bit0(); }
	//##ModelId=3A3D09AA0104
  inline bit_t IC2F() { return TFLG1.bit1(); }
	//##ModelId=3A3D09AA00E6
  inline bit_t IC1F() { return TFLG1.bit2(); }
	//##ModelId=3A3D09AA00C8
  inline bit_t I4O5F(){ return TFLG1.bit3(); }
	//##ModelId=3A3D09AA00AA
  inline bit_t OC4F() { return TFLG1.bit4(); }
	//##ModelId=3A3D09AA0096
  inline bit_t OC3F() { return TFLG1.bit5(); }
	//##ModelId=3A3D09AA0078
  inline bit_t OC2F() { return TFLG1.bit6(); }
	//##ModelId=3A3D09AA005A
  inline bit_t OC1F() { return TFLG1.bit7(); }
  
  // Mutators
	//##ModelId=3A3D09AA0122
  inline void IC3F(bit_t val) { TFLG1.bit0(val); }
	//##ModelId=3A3D09AA0105
  inline void IC2F(bit_t val) { TFLG1.bit1(val); }
	//##ModelId=3A3D09AA00E7
  inline void IC1F(bit_t val) { TFLG1.bit2(val); }
	//##ModelId=3A3D09AA00D2
  inline void I4O5F(bit_t val){ TFLG1.bit3(val); }
	//##ModelId=3A3D09AA00B4
  inline void OC4F(bit_t val) { TFLG1.bit4(val); }
	//##ModelId=3A3D09AA0097
  inline void OC3F(bit_t val) { TFLG1.bit5(val); }
	//##ModelId=3A3D09AA0079
  inline void OC2F(bit_t val) { TFLG1.bit6(val); }
	//##ModelId=3A3D09AA005B
  inline void OC1F(bit_t val) { TFLG1.bit7(val); }

  ////////////////////////////////////////////////////////
  // TMSK2 Register
  // Accessors
  // PR is two bits
	//##ModelId=3A3D09AA003C
  inline byte_t PR()  { return TMSK2.byte&MASK_01; }  
  // Bits 2 and 3 are unused
	//##ModelId=3A3D09AA0028
  inline bit_t PAII() { return TMSK2.bit4(); }
	//##ModelId=3A3D09AA000A
  inline bit_t PAOVI()  { return TMSK2.bit5(); }
	//##ModelId=3A3D09A903D4
  inline bit_t RTII() { return TMSK2.bit6(); }
	//##ModelId=3A3D09A903B6
  inline bit_t TOI()    { return TMSK2.bit7(); }
  
  // Mutators
  // PR is two bits
	//##ModelId=3A3D09AA0046
  inline void PR(byte_t val) { TMSK2.byte = TMSK2.byte&(~MASK_01)|(val&MASK_01); }
  // Bits 2 and 3 are unused
	//##ModelId=3A3D09AA0029
  inline void PAII(bit_t val) { TMSK2.bit4(val); }
	//##ModelId=3A3D09AA000B
  inline void PAOVI(bit_t val)  { TMSK2.bit5(val); }
	//##ModelId=3A3D09A903D5
  inline void RTII(bit_t val) { TMSK2.bit6(val); }
	//##ModelId=3A3D09A903C0
  inline void TOI(bit_t val)    { TMSK2.bit7(val); }

  ////////////////////////////////////////////////////////
  // TFLG2 Register
  // Accessors
  // First four bits are unused
	//##ModelId=3A3D09A903A1
  inline bit_t PAIF() { return TFLG2.bit4(); }
	//##ModelId=3A3D09A90383
  inline bit_t PAOVF()  { return TFLG2.bit5(); }
	//##ModelId=3A3D09A90365
  inline bit_t RTIF() { return TFLG2.bit6(); }
	//##ModelId=3A3D09A90347
  inline bit_t TOF()    { return TFLG2.bit7(); }

  // Mutators
  // First four bits are unused
	//##ModelId=3A3D09A903A2
  inline void PAIF(bit_t val) { TFLG2.bit4(val); }
	//##ModelId=3A3D09A90384
  inline void PAOVF(bit_t val)  { TFLG2.bit5(val); }
	//##ModelId=3A3D09A9036F
  inline void RTIF(bit_t val) { TFLG2.bit6(val); }
	//##ModelId=3A3D09A90351
  inline void TOF(bit_t val)    { TFLG2.bit7(val); }

  ////////////////////////////////////////////////////////
  // PACTL Register
  // Accessors
  // RTR is 2 bits
	//##ModelId=3A3D09A90333
  inline byte_t RTR (){ return PACTL.byte&MASK_01; }
	//##ModelId=3A3D09A90315
  inline bit_t I4O5() { return PACTL.bit2(); }
	//##ModelId=3A3D09A902F7
  inline bit_t DDRA3(){ return PACTL.bit3(); }
	//##ModelId=3A3D09A902E3
  inline bit_t PEDGE(){ return PACTL.bit4(); }
	//##ModelId=3A3D09A902C5
  inline bit_t PAMOD(){ return PACTL.bit5(); }
	//##ModelId=3A3D09A902A7
  inline bit_t PAEN() { return PACTL.bit6(); }
	//##ModelId=3A3D09A90289
  inline bit_t DDRA7(){ return PACTL.bit7(); }

  // Mutators
  // RTR is 2 bits
	//##ModelId=3A3D09A90334
  inline void RTR(byte_t val) { PACTL.byte = PACTL.byte&(~MASK_01)|(val&MASK_01); }
	//##ModelId=3A3D09A90316
  inline void I4O5(bit_t val) { PACTL.bit2(val); }
	//##ModelId=3A3D09A90301
  inline void DDRA3(bit_t val){ PACTL.bit3(val); }
	//##ModelId=3A3D09A902E4
  inline void PEDGE(bit_t val){ PACTL.bit4(val); }
	//##ModelId=3A3D09A902C6
  inline void PAMOD(bit_t val){ PACTL.bit5(val); }
	//##ModelId=3A3D09A902A8
  inline void PAEN(bit_t val) { PACTL.bit6(val); }
  // Bit 7 affects the mode of the PA7 pin!
	//##ModelId=3A3D09A9028A
  inline void DDRA7(bit_t val){ PACTL.bit7(val);  
                                if (val)
                                {
                                  if (OC1M7())
                                    PORTA.SetMode(7,Pin::AUTO);
                                  else
                                    PORTA.SetMode(7,Pin::OUTPUT); 
                                }
                                else 
                                  PORTA.SetMode(7,Pin::INPUT); 
                              }

  ////////////////////////////////////////////////////////
  // BPROT Register
  // Accessors
  // BPRT is 4 bits
	//##ModelId=3A3D09A9026B
  inline byte_t BPRT () { return BPROT.byte&MASK_0123; }
	//##ModelId=3A3D09A9024D
  inline bit_t PTCON()  { return BPROT.bit4(); }
  // Bits 5,6,7 are unused

  // Mutators
  // BPRT is 4 bits
	//##ModelId=3A3D09A9026C
  inline void BPRT(byte_t val){ BPROT.byte = BPROT.byte&(~MASK_0123)|(val&MASK_0123); }
	//##ModelId=3A3D09A9024E
  inline void PTCON(bit_t val){ BPROT.bit4(val); }
  // Bits 5,6,7 are unused

  ////////////////////////////////////////////////////////
  // EPROG Register
  // Accessors
	//##ModelId=3A3D09A9022F
  inline bit_t PGM () { return EPROG.bit0(); }
  // T is 2 bits
	//##ModelId=3A3D09A90211
  inline byte_t T()   { return (EPROG.byte&MASK_12)>>1; }
	//##ModelId=3A3D09A901FD
  inline bit_t EXROW(){ return EPROG.bit3(); }
	//##ModelId=3A3D09A901DF
  inline bit_t EXCOL(){ return EPROG.bit4(); }
	//##ModelId=3A3D09A901C1
  inline bit_t ELAT() { return EPROG.bit5(); }
  // Bit 6 is unused
	//##ModelId=3A3D09A901A3
  inline bit_t MBE()  { return EPROG.bit7(); }

  // Mutators
	//##ModelId=3A3D09A90230
  inline void PGM(bit_t val)  { EPROG.bit0(val); }
  // T is 2 bits
	//##ModelId=3A3D09A9021B
  inline void T(byte_t val)   { EPROG.byte = EPROG.byte&(~MASK_12)|(val<<1)&MASK_12; }
	//##ModelId=3A3D09A901FE
  inline void EXROW(bit_t val){ EPROG.bit3(val); }
	//##ModelId=3A3D09A901E0
  inline void EXCOL(bit_t val){ EPROG.bit4(val); }
	//##ModelId=3A3D09A901CB
  inline void ELAT(bit_t val) { EPROG.bit5(val); }
  // Bit 6 is unused
	//##ModelId=3A3D09A901AD
  inline void MBE(bit_t val)  { EPROG.bit7(val); }

  ////////////////////////////////////////////////////////
  // SPCR Register
  // Accessors
  // SPR is 2 bits
	//##ModelId=3A3D09A9018F
  inline byte_t SPR() { return SPCR.byte&MASK_01; }
	//##ModelId=3A3D09A90171
  inline bit_t CPHA() { return SPCR.bit2(); }
	//##ModelId=3A3D09A90153
  inline bit_t CPOL() { return SPCR.bit3(); }
	//##ModelId=3A3D09A9013F
  inline bit_t MSTR() { return SPCR.bit4(); }
	//##ModelId=3A3D09A90121
  inline bit_t DWOM() { return SPCR.bit5(); }
	//##ModelId=3A3D09A90103
  inline bit_t SPE()  { return SPCR.bit6(); }
	//##ModelId=3A3D09A900E4
  inline bit_t SPIE() { return SPCR.bit7(); }
  
  // Mutators
  // SPR is 2 bits
	//##ModelId=3A3D09A90190
  inline void SPR(byte_t val) { SPCR.byte = SPCR.byte&(~MASK_01)|(val&MASK_01); }
	//##ModelId=3A3D09A90172
  inline void CPHA(bit_t val) { SPCR.bit2(val); }
	//##ModelId=3A3D09A9015D
  inline void CPOL(bit_t val) { SPCR.bit3(val); }
	//##ModelId=3A3D09A90140
  inline void MSTR(bit_t val) { SPCR.bit4(val); }
	//##ModelId=3A3D09A90122
  inline void DWOM(bit_t val) { SPCR.bit5(val);
                if(val)   //if DWOM==1 in SPCR, PortD is handed over to the SCI system.
                  for(int i=0;i<=5;i++)  //since we don't have the SCI system implemented
                    PORTD.SetMode(i,Pin::AUTO);  //PORTD is effectively disabled.
                else
                {
                  for(int x=0;x<=5;x++)
                    PORTD.SetMode(x,Pin::OUTPUT);

                  DDRD.Write(DDRD.Read());
                }
                }
	//##ModelId=3A3D09A90104
  inline void SPE(bit_t val)  { SPCR.bit6(val); }
	//##ModelId=3A3D09A900EE
  inline void SPIE(bit_t val) { SPCR.bit7(val); }

  ////////////////////////////////////////////////////////
  // SPSR Register
  // Accessors
  // First 4 bits are unused
	//##ModelId=3A3D09A900D0
  inline bit_t MODF() { return SPSR.bit4(); }
  // Bit 5 is unused
	//##ModelId=3A3D09A900B2
  inline bit_t WCOL() { return SPSR.bit6(); }
	//##ModelId=3A3D09A90094
  inline bit_t SPIF() { return SPSR.bit7(); }

  // Mutators
  // First 4 bits are unused
	//##ModelId=3A3D09A900D1
  inline void MODF(bit_t val) { SPSR.bit4(val); }
  // Bit 5 is unused
	//##ModelId=3A3D09A900B3
  inline void WCOL(bit_t val) { SPSR.bit6(val); }
	//##ModelId=3A3D09A90095
  inline void SPIF(bit_t val) { SPSR.bit7(val); }

  ////////////////////////////////////////////////////////
  // BAUD Register
  // Accessors
  // SCR is 3 bits
	//##ModelId=3A3D09A90076
  inline byte_t SCR() { return BAUD.byte&MASK_012; }
	//##ModelId=3A3D09A90058
  inline bit_t RCKB() { return BAUD.bit3(); }
  // SCP is 2 bits
	//##ModelId=3A3D09A9003A
  inline bit_t SCP()  { return (BAUD.byte&MASK_45)>>4; }
	//##ModelId=3A3D09A90026
  inline bit_t SCP2() { return BAUD.bit6(); }
	//##ModelId=3A3D09A90008
  inline bit_t TCLR() { return BAUD.bit7(); }
  
  // Mutators
  // SCR is 3 bits
	//##ModelId=3A3D09A90077
  inline void SCR(byte_t val) { BAUD.byte = BAUD.byte&(~MASK_012)|(val&MASK_012); } 
	//##ModelId=3A3D09A90062
  inline void RCKB(bit_t val) { BAUD.bit3(val); }
  // SCP is 2 bits
	//##ModelId=3A3D09A90044
  inline void SCP(byte_t val) { BAUD.byte = BAUD.byte&(~MASK_45)|(val<<4)&MASK_45; }
	//##ModelId=3A3D09A90027
  inline void SCP2(bit_t val) { BAUD.bit6(val); }
	//##ModelId=3A3D09A90009
  inline void TCLR(bit_t val) { BAUD.bit7(val); }

  ////////////////////////////////////////////////////////
  // PIOC Register
  // Accessors
	//##ModelId=3A3D09A803D2
  inline bit_t INVB() { return PIOC.bit0(); }
	//##ModelId=3A3D09A803BE
  inline bit_t EGA()  { return PIOC.bit1(); }
	//##ModelId=3A3D09A803A0
  inline bit_t PLS()  { return PIOC.bit2(); }
	//##ModelId=3A3D09A80382
  inline bit_t OIN()  { return PIOC.bit3(); }
	//##ModelId=3A3D09A80364
  inline bit_t HNDS() { return PIOC.bit4(); }
	//##ModelId=3A3D09A80350
  inline bit_t CWOM() { return PIOC.bit5(); }
	//##ModelId=3A3D09A80332
  inline bit_t STAI() { return PIOC.bit6(); }
	//##ModelId=3A3D09A80314
  inline bit_t STAF() { return PIOC.bit7(); }
  // Mutators
	//##ModelId=3A3D09A803DC
  inline void INVB(bit_t val) { PIOC.bit0(val); }
	//##ModelId=3A3D09A803BF
  inline void EGA(bit_t val)  { PIOC.bit1(val); }
	//##ModelId=3A3D09A803A1
  inline void PLS(bit_t val)  { PIOC.bit2(val); }
	//##ModelId=3A3D09A80383
  inline void OIN(bit_t val)  { PIOC.bit3(val); }
	//##ModelId=3A3D09A8036E
  inline void HNDS(bit_t val) { PIOC.bit4(val); }
	//##ModelId=3A3D09A80351
  inline void CWOM(bit_t val) { PIOC.bit5(val); }
	//##ModelId=3A3D09A80333
  inline void STAI(bit_t val) { PIOC.bit6(val); }
	//##ModelId=3A3D09A8031E
  inline void STAF(bit_t val) { PIOC.bit7(val); }


  ////////////////////////////////////////////////////////
  // SCCR1 Register
  // Accessors
  // First three bits are unused
	//##ModelId=3A3D09A802F6
  inline bit_t WAKE() { return SCCR1.bit3(); }
	//##ModelId=3A3D09A802E2
  inline bit_t M()  { return SCCR1.bit4(); }
  // Bit 5 is unused
	//##ModelId=3A3D09A802C4
  inline bit_t T8() { return SCCR1.bit6(); }
	//##ModelId=3A3D09A802A6
  inline bit_t R8() { return SCCR1.bit7(); }

  // Mutators
  // First three bits are unused
	//##ModelId=3A3D09A80300
  inline void WAKE(bit_t val) { SCCR1.bit3(val); }
	//##ModelId=3A3D09A802E3
  inline void M(bit_t val)  { SCCR1.bit4(val); }
  // Bit 5 is unused
	//##ModelId=3A3D09A802C5
  inline void T8(bit_t val) { SCCR1.bit6(val); }
	//##ModelId=3A3D09A802B0
  inline void R8(bit_t val) { SCCR1.bit7(val); }


  ////////////////////////////////////////////////////////
  // SCCR2 Register
  // Accessors
	//##ModelId=3A3D09A80288
  inline bit_t SBK()  { return SCCR2.bit0(); }
	//##ModelId=3A3D09A80274
  inline bit_t RWU()  { return SCCR2.bit1(); }
	//##ModelId=3A3D09A80256
  inline bit_t RE()   { return SCCR2.bit2();  }
	//##ModelId=3A3D09A80238
  inline bit_t TE()   { return SCCR2.bit3(); }
	//##ModelId=3A3D09A80219
  inline bit_t ILIE() { return SCCR2.bit4();  }
	//##ModelId=3A3D09A801FB
  inline bit_t RIE()  { return SCCR2.bit5();  }
	//##ModelId=3A3D09A801E7
  inline bit_t TCIE() { return SCCR2.bit6(); }
	//##ModelId=3A3D09A801C9
  inline bit_t TIE()  { return SCCR2.bit7(); }
  // Mutators
	//##ModelId=3A3D09A80292
  inline void SBK(bit_t val) { SCCR2.bit0(val); }
	//##ModelId=3A3D09A80275
  inline void RWU(bit_t val)  { SCCR2.bit1(val);  }
	//##ModelId=3A3D09A80257
  inline void RE(bit_t val) { SCCR2.bit2(val);  }
	//##ModelId=3A3D09A80239
  inline void TE(bit_t val) { SCCR2.bit3(val);  }
	//##ModelId=3A3D09A80224
  inline void ILIE(bit_t val) { SCCR2.bit4(val);  }
	//##ModelId=3A3D09A80205
  inline void RIE(bit_t val)  { SCCR2.bit5(val);  }
	//##ModelId=3A3D09A801E8
  inline void TCIE(bit_t val) { SCCR2.bit6(val); }
	//##ModelId=3A3D09A801CA
  inline void TIE(bit_t val)  { SCCR2.bit7(val); }


  ////////////////////////////////////////////////////////
  // SCSR Register
  // Accessors
  // Bit 0 is unused
	//##ModelId=3A3D09A801AB
  inline bit_t FE()   { return SCSR.bit1(); }
	//##ModelId=3A3D09A8018D
  inline bit_t NF()   { return SCSR.bit2(); }
	//##ModelId=3A3D09A8016F
  inline bit_t OR()   { return SCSR.bit3(); }
	//##ModelId=3A3D09A8015B
  inline bit_t IDLE() { return SCSR.bit4(); }
	//##ModelId=3A3D09A8013D
  inline bit_t RDRF() { return SCSR.bit5(); }
	//##ModelId=3A3D09A8011F
  inline bit_t TC()   { return SCSR.bit6(); }
	//##ModelId=3A3D09A80101
  inline bit_t TDRE() { return SCSR.bit7(); }
  // Mutators
  // Bit 0 is unused
	//##ModelId=3A3D09A801AC
  inline void FE(bit_t val)   { SCSR.bit1(val); }
	//##ModelId=3A3D09A80197
  inline void NF(bit_t val)   { SCSR.bit2(val); }
	//##ModelId=3A3D09A80179
  inline void OR(bit_t val)   { SCSR.bit3(val); }
	//##ModelId=3A3D09A8015C
  inline void IDLE(bit_t val) { SCSR.bit4(val); }
	//##ModelId=3A3D09A8013E
  inline void RDRF(bit_t val) { SCSR.bit5(val); }
	//##ModelId=3A3D09A80129
  inline void TC(bit_t val)   { SCSR.bit6(val); }
	//##ModelId=3A3D09A8010B
  inline void TDRE(bit_t val) { SCSR.bit7(val); }

  ////////////////////////////////////////////////////////
  // SCDR Register
  // Accessors
	//##ModelId=3A3D09A800E3
  inline bit_t R0T0() { return SCDR.bit0(); }
	//##ModelId=3A3D09A800CF
  inline bit_t R1T1() { return SCDR.bit1(); }
	//##ModelId=3A3D09A800B1
  inline bit_t R2T2() { return SCDR.bit2(); }
	//##ModelId=3A3D09A80093
  inline bit_t R3T3() { return SCDR.bit3(); }
	//##ModelId=3A3D09A80075
  inline bit_t R4T4() { return SCDR.bit4(); }
	//##ModelId=3A3D09A80057
  inline bit_t R5T5() { return SCDR.bit5(); }
	//##ModelId=3A3D09A80039
  inline bit_t R6T6() { return SCDR.bit6(); }
	//##ModelId=3A3D09A80025
  inline bit_t R7T7() { return SCDR.bit7(); }
  // Mutators
	//##ModelId=3A3D09A800ED
  inline void R0T0(bit_t val) { SCDR.bit0(val); }
	//##ModelId=3A3D09A800D0
  inline void R1T1(bit_t val) { SCDR.bit1(val); }
	//##ModelId=3A3D09A800B2
  inline void R2T2(bit_t val) { SCDR.bit2(val); }
	//##ModelId=3A3D09A80094
  inline void R3T3(bit_t val) { SCDR.bit3(val); }
	//##ModelId=3A3D09A8007F
  inline void R4T4(bit_t val) { SCDR.bit4(val); }
	//##ModelId=3A3D09A80061
  inline void R5T5(bit_t val) { SCDR.bit5(val); }
	//##ModelId=3A3D09A80043
  inline void R6T6(bit_t val) { SCDR.bit6(val); }
	//##ModelId=3A3D09A80026
  inline void R7T7(bit_t val) { SCDR.bit7(val); }

  ////////////////////////////////////////////////////////
  // ADCTL Register
  // Accessors
	//##ModelId=3A3D09A80007
  inline bit_t CA()   { return ADCTL.bit0(); }
	//##ModelId=3A3D09A703D1
  inline bit_t CB()   { return ADCTL.bit1(); }
	//##ModelId=3A3D09A703B3
  inline bit_t CC()   { return ADCTL.bit2();  }
	//##ModelId=3A3D09A70395
  inline bit_t CD()   { return ADCTL.bit3(); }
	//##ModelId=3A3D09A70377
  inline bit_t MULT() { return ADCTL.bit4();  }
	//##ModelId=3A3D09A70359
  inline bit_t SCAN() { return ADCTL.bit5();  }
  // Bit 6 is unused
	//##ModelId=3A3D09A70344
  inline bit_t CCF()  { return SCSR.bit7(); }
  // Mutators
	//##ModelId=3A3D09A80008
  inline void CA(bit_t val)   { ADCTL.bit0(val); }
	//##ModelId=3A3D09A703D2
  inline void CB(bit_t val)   { ADCTL.bit1(val);  }
	//##ModelId=3A3D09A703B4
  inline void CC(bit_t val)   { ADCTL.bit2(val);  }
	//##ModelId=3A3D09A70396
  inline void CD(bit_t val)   { ADCTL.bit3(val);  }
	//##ModelId=3A3D09A70381
  inline void MULT(bit_t val) { ADCTL.bit4(val);  }
	//##ModelId=3A3D09A70363
  inline void SCAN(bit_t val) { ADCTL.bit5(val);  }
  // Bit 6 is unused
	//##ModelId=3A3D09A70345
  inline void CCF(bit_t val)  { ADCTL.bit7(val); }

};

#endif // REGFILE_H
