////////////////////////////////////////////////////////////////////////////////
// File Name:       tctl1_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:34:37
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(TCTL1_C_H)
#define TCTL1_C_H

#include "ByteRegister.h"
#include "PortRegister.h"

//##ModelId=3A3D099C03C1
class TCTL1_C : public ByteRegister
{
public:
	//##ModelId=3A3D099C03D5
    void Write(byte_t data);          
	//##ModelId=3A3D099C03CE
    PortRegister* portA;  
};

#endif //!defined(TCTL1_C_H)
