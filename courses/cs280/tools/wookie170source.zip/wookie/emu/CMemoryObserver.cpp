////////////////////////////////////////////////////////////////////////////////
// File Name:       CMemoryObserver.cpp
// Description:     This file defines all CMemoryObserver member functions.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CMemorySubject.h"
#include "CMemoryObserver.h"


////////////////////////////////////////////////////////////////////////////////
// Function Name:   Update
// Scope:           CMemoryObserver
// Return Value:    <none>
// Usage:           This gets called by a subject when a change occurs.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CMemorySubject& theSubject      I/O the subject that is being watched
//  enOperation     theOperation    I   the operation that occurred
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void CMemoryObserver::Update(CMemorySubject& theSubject, enOperation theOperation)
{
	//Nothing to do in the base class
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~CMemoryObserver
// Scope:           CMemoryObserver
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemoryObserver::~CMemoryObserver()
{
	//Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CMemoryObserver
// Scope:           CMemoryObserver
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemoryObserver::CMemoryObserver()
{
	//Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CMemoryObserver
// Scope:           CMemoryObserver
// Return Value:    <none>
// Usage:           Copy Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CMemoryO� orig            I   the object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemoryObserver::CMemoryObserver(const CMemoryObserver& orig)
{
	//Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           CMemoryObserver
// Usage:           Copy assignment operator.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CMemoryObserve� rhs             I/O the object to assign
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  CMemoryObserve� Returns a reference to the newly modified object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CMemoryObserver& CMemoryObserver::operator=(CMemoryObserver& rhs)
{
	//nothing to do 
	
	return (*this);
}


