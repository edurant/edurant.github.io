#if !defined(DDREGISTER_H)
#define DDREGISTER_H

#include "basetypes.h"
#include "ByteRegister.h"
#include "PortRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: DDRegister
//
//  Author: Kalle Anderson, Paul Clarke
// 
//  Purpose: This register class affects the modes of pins of an 
//          associated port.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class DDRegister into its own header
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099E0052
class DDRegister: public ByteRegister
{
 private:
	// This is the associated port register to this data
	// direction register
	//##ModelId=3A3D099E005F
	PortRegister* port_reg;

 public:	
	
	//##ModelId=3A3D099E0070
	DDRegister();

	//##ModelId=3A3D099E006A
	void Associate(PortRegister* port);
		
	//##ModelId=3A3D099E0068
	byte_t Read(void);
	//##ModelId=3A3D099E0066
	void Write(byte_t data);
};

#endif //!defined(DDREGISTER_H)
