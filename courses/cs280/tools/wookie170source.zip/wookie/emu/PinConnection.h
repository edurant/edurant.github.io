#if !defined(PINCONNECTION_H)
#define PINCONNECTION_H

#include "basetypes.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Class Name: PinConnnection
//
//  Author:  Paul Clarke et al.
//
//  Purpose: Allows a pin to set a value in a different module (or thread)
//           by way of virtual functions.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class PinConnection into its own header
//
/////////////////////////////////////////////////////////////////////////////

//##ModelId=3A3D09AE033B
class PinConnection
{
public:
	// GUI writes this function
	//##ModelId=3A3D09AE033C
	virtual void Set(bit_t value);

};

#endif //!defined(PINCONNECTION_H)
