////////////////////////////////////////////////////////////////////////////////
// File Name:       STRAPin.cpp
// Description:     This file defines all STRAPin member functions.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "STRAPin.h"


////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~STRAPin
// Scope:           STRAPin
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
STRAPin::~STRAPin()
{
	// Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           STRAPin
// Usage:           Copy assignment operator.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Assigns all members from rhs to this
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const STRAPin&  rhs             I   object to assign
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  STRAPin&        Returns a reference to the newly modifed object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
STRAPin& STRAPin::operator=(const STRAPin& rhs)
{
    //Check for self assignment
    if(this != &rhs)
    {
        Pin::operator=(rhs);
    }
 
	return (*this);
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   STRAPin
// Scope:           STRAPin
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the ID for the STRAPin.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
STRAPin::STRAPin()
{
	// Set the id
    ID = "STRA";
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   STRAPin
// Scope:           STRAPin
// Return Value:    <none>
// Usage:           Copy Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the Pin copy constructor.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const STRAPin&  rhs             I   object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
STRAPin::STRAPin(const STRAPin& rhs)
:Pin(rhs)
{
	//Nothing to do
}


