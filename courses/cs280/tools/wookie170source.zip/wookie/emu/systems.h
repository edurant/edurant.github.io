///////////////////////////////////////////////////////////////
// File Name: systems.h
// Purpose:  Definition the subsystem base class
///////////////////////////////////////////////////////////////

#ifndef SYSTEMS_H
#define SYSTEMS_H

#include "basetypes.h"
#include "register.h"
#include "hc11io.h"

class HC11SubSystem
{
 protected:
	class HC11 *hc11;
 public:	
		
    HC11SubSystem(){hc11=NULL;};
    HC11SubSystem(HC11 *nhc11);	
    void ClockSystem(void);

 friend class HC11;
};

#endif
