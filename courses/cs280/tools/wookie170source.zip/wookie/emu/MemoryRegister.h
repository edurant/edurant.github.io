#if !defined(MEMORYREGISTER_H)
#define MEMORYREGISTER_H

#include "CRegisterSubject.h"

#include "basetypes.h"

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: MemoryRegister
//
// Author: Kalle Anderson et al.
//
// Purpose: This class is a common register that every memory-mapped register
//					is derived from.  This allows the memory map to read and write to
//					all registers without knowing the specific type of register.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class MemoryRegister into its own header
//
//  01/28/2001  Ian Kasprzak    Added constructor and copy constructor
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099D006F
class MemoryRegister : public CRegisterSubject
{    
 public:
	MemoryRegister(const MemoryRegister& rhs);

    MemoryRegister();

	//##ModelId=3A3D099D007C
	 virtual byte_t Read(void)=0;
	//##ModelId=3A3D099D0079
	 virtual void Write(byte_t data)=0;	
};

#endif //!defined(MEMORYREGISTER_H)
