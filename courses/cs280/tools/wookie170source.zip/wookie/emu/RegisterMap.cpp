#include "stdafx.h"
#include "RegisterMap.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////



#define SIZE_OF_REGISTER_BLOCK 0x3f


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: RegisterMap::RegisterMap()
//
// Author: Paul Clarke
//
// Purpose: 
//          
// Input Parameters:    word_t base,
//                      RegisterFile* regfile
//
// Return Value: None
//
/////////////////////////////////////////////////////////////////////////////
RegisterMap::RegisterMap(word_t base,RegisterFile* regfile):MemoryObject()
{	
    
	base_addr = base;
	top_addr = base_addr + SIZE_OF_REGISTER_BLOCK;
    size = SIZE_OF_REGISTER_BLOCK;

	// Assign the array of pointers to the register objects

	regs[0x00] = &regfile->PORTA;
	regs[0x01] = &reserved;
	regs[0x02] = &regfile->PIOC;
	// Reserved at 0x03
	regs[0x03] = &regfile->PORTC;
	regs[0x04] = &regfile->PORTB;
	// should be port CL (paul didn't implement this guy) bad paul bad paul
	regs[0x05] = &regfile->PORTC;
	// Reserved at 0x06
	regs[0x06] = &reserved;
	regs[0x07] = &regfile->DDRC;
	regs[0x08] = &regfile->PORTD;
	regs[0x09] = &regfile->DDRD;
	regs[0x0a] = &regfile->PORTE;
	regs[0x0b] = &regfile->CFORC;
	regs[0x0c] = &regfile->OC1M;
	regs[0x0d] = &regfile->OC1D;
	regs[0x0e] = &regfile->TCNT.high;
	regs[0x0f] = &regfile->TCNT.low;
	regs[0x10] = &regfile->TIC1.high;
	regs[0x11] = &regfile->TIC1.low;
	regs[0x12] = &regfile->TIC2.high;
	regs[0x13] = &regfile->TIC2.low;
	regs[0x14] = &regfile->TIC3.high;
	regs[0x15] = &regfile->TIC3.low;
	regs[0x16] = &regfile->TOC1.high;
	regs[0x17] = &regfile->TOC1.low;
	regs[0x18] = &regfile->TOC2.high;
	regs[0x19] = &regfile->TOC2.low;
	regs[0x1a] = &regfile->TOC3.high;
	regs[0x1b] = &regfile->TOC3.low;
	regs[0x1c] = &regfile->TOC4.high;
	regs[0x1d] = &regfile->TOC4.low;
	regs[0x1e] = &regfile->TI4O5.high;
	regs[0x1f] = &regfile->TI4O5.low;
	regs[0x20] = &regfile->TCTL1;
	regs[0x21] = &regfile->TCTL2;
	regs[0x22] = &regfile->TMSK1;
	regs[0x23] = &regfile->TFLG1;
	regs[0x24] = &regfile->TMSK2;
	regs[0x25] = &regfile->TFLG2;
	regs[0x26] = &regfile->PACTL;
	regs[0x27] = &regfile->PACNT;
	regs[0x28] = &regfile->SPCR;
	regs[0x29] = &regfile->SPSR;
	regs[0x2a] = &regfile->SPDR;
	regs[0x2b] = &regfile->BAUD;
	regs[0x2c] = &regfile->SCCR1;
	regs[0x2d] = &regfile->SCCR2;
	regs[0x2e] = &regfile->SCSR;
	regs[0x2f] = &regfile->SCDR;
	regs[0x30] = &regfile->ADCTL;
	regs[0x31] = &regfile->ADR1;
	regs[0x32] = &regfile->ADR2;
	regs[0x33] = &regfile->ADR3;
	regs[0x34] = &regfile->ADR4;
	regs[0x35] = &regfile->BPROT;
	regs[0x36] = &regfile->EPROG;
	// Reserved at 0x37
	regs[0x37] = &reserved;
	// Reserved at 0x38
	regs[0x38] = &reserved;
	regs[0x39] = &regfile->OPTION;
	regs[0x3a] = &regfile->COPRST;
	regs[0x3b] = &regfile->PPROG;
	regs[0x3c] = &regfile->HPRIO;
	regs[0x3d] = &regfile->INIT;
	regs[0x3e] = &regfile->TEST1;
	regs[0x3f] = &regfile->CONFIG;

}

RegisterMap::~RegisterMap()
{
}

byte_t RegisterMap::Read(word_t address)
{
	return(regs[address-base_addr]->Read());
}

void RegisterMap::Write(word_t address, byte_t data)
{
	assert(address >= base_addr);
	regs[address-base_addr]->Write(data);
}