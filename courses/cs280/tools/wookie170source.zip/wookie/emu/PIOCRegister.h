////////////////////////////////////////////////////////////////////////////////
// File Name:       PIOCRegister.h
// Description:     This is the PIOC register on the M68HC11
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:34
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented class

////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_PIOCREGISTER_3A6B478B02C8_INCLUDED
#define _INC_PIOCREGISTER_3A6B478B02C8_INCLUDED

#include "ByteRegister.h"

class PIOCRegister 
: public ByteRegister
{
public:
	~PIOCRegister();

	PIOCRegister();

	PIOCRegister(const PIOCRegister& rhs);

	PIOCRegister& operator=(const PIOCRegister& rhs);

};

#endif /* _INC_PIOCREGISTER_3A6B478B02C8_INCLUDED */

