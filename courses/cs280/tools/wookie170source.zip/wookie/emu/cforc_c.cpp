////////////////////////////////////////////////////////////////////////////////
// File Name:       cforc_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:49:58
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "cforc_c.h"

/////////////////////////////////////////////////////////////////
// CFORC function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: Writes to the CFORC register and possibly causes an output compare.
//
// Input Parameters: val - byte that is written to the CFORC register
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void CFORC_C::Write(byte_t val)
{
	
	Byte b = val;

	// IMPORTANT 
	// CFORC can only be read as a zero, the bits never actually change 
	// levels.  A logical one written to a bit will fire an output compare.
	// A zero written to CFORC does nothing.
	if (byte != 0)
		byte = 0;

	// NOTE:  If OC1 activates a pin, other output compares cannot
	bit_t has_control2 = 0;
	bit_t has_control3 = 0;
	bit_t has_control4 = 0;
	bit_t has_control5 = 0;

	if (b.bit7())	// FOC1
	{
		// Check the control bits and set pin levels if necessary
		if (oc1m->bit3())
		{
			portA->Action(3,oc1d->bit3());
			has_control5 = 1;
		}
		if (oc1m->bit4())
		{
			portA->Action(4,oc1d->bit4());
			has_control4 = 1;
		}
		if (oc1m->bit5())
		{
			portA->Action(5,oc1d->bit5());
			has_control3 = 1;
		}
		if (oc1m->bit6())
		{
			portA->Action(6,oc1d->bit6());
			has_control2 = 1;
		}
		if (oc1m->bit7())
			portA->Action(7,oc1d->bit7());
	}

	if (b.bit6() && !has_control2)	// FOC2
	{
		bit_t ol2 = tctl1->bit6();
		bit_t om2 = tctl1->bit7();
	
		// Check the output compare enabling bits
		switch((om2<<1)|ol2)
		{
			case 0x0:		// does not affect pin
				break;
			case 0x1:		// toggles pin
				portA->Action(6,!portA->Read(6));
				break;
			case 0x2:		// clears pin
				portA->Action(6,0);
				break;
			case 0x3:		// sets pin
				portA->Action(6,1);
				break;
			default:	assert(false);
		}	
	}

	if (b.bit5() && !has_control3)	// FOC3
	{
		bit_t ol3 = tctl1->bit4();
		bit_t om3 = tctl1->bit5();
	
		// Check the output compare enabling bits
		switch((om3<<1)|ol3)
		{
			case 0x0:		// does not affect pin
				break;
			case 0x1:		// toggles pin
				portA->Action(5,!portA->Read(5));
				break;
			case 0x2:		// clears pin
				portA->Action(5,0);
				break;
			case 0x3:		// sets pin
				portA->Action(5,1);
				break;
			default:	assert(false);
		}
	}

	if (b.bit4() && !has_control4)	// FOC4
	{
		bit_t ol4 = tctl1->bit2();
		bit_t om4 = tctl1->bit3();
	
		// Check the output compare enabling bits
		switch((om4<<1)|ol4)
		{
			case 0x0:		// does not affect pin
				break;
			case 0x1:		// toggles pin
				portA->Action(4,!portA->Read(4));
				break;
			case 0x2:		// clears pin
				portA->Action(4,0);
				break;
			case 0x3:		// sets pin
				portA->Action(4,1);
				break;
			default:	assert(false);
		}
	}

	if (b.bit3() && !has_control5)	// FOC5
	{
		bit_t ol5 = tctl1->bit0();
		bit_t om5 = tctl1->bit1();
	
		// Check the output compare enabling bits
		switch((om5<<1)|ol5)
		{
			case 0x0:		// does not affect pin
				break;
			case 0x1:		// toggles pin
				portA->Action(3,!portA->Read(3));
				break;
			case 0x2:		// clears pin
				portA->Action(3,0);
				break;
			case 0x3:		// sets pin
				portA->Action(3,1);
				break;
			default:	assert(false);
		}
	}
}

