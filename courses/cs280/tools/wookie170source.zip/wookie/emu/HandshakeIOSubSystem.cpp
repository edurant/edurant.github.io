////////////////////////////////////////////////////////////////////////////
//	File:	HandshakeIOSubSystem.cpp
//
//	Purpose:	Contains the code for the HC11 Timer subsystem
////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HandshakeIOSubSystem.h"
#include "HC11.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//                              Functions had extraneous semi-colons after...
//                               these were removed
//          
/////////////////////////////////////////////////////////////////////////////






HandshakeIOSubSystem::HandshakeIOSubSystem(HC11 *nhc11)
{
    hc11 = nhc11;
    STRB_pulse=0;
}


void HandshakeIOSubSystem::WriteToPORTB(void)
{
    switch(hc11->regfile.HNDS())
    {
        case 0:
            if(hc11->regfile.INVB())
            {
                hc11->STRB.Output(1);
                STRB_pulse=2;
            }
            else
            {
                hc11->STRB.Output(0);
                STRB_pulse=2;
            }
            break;
        //other modes aren't implemented yet
    }        
}

void HandshakeIOSubSystem::ClockSystem(void)
{     
    switch(hc11->regfile.HNDS())
    {
        case 0:
            if(STRB_pulse>0)
                STRB_pulse--;
            else
            {
                STRB_pulse=0;
                if(hc11->regfile.INVB())                
                    hc11->STRB.Output(0);                
                else
                    hc11->STRB.Output(1);
            }
            break;
        //other modes aren't implemented yet
    }        
}

void HandshakeIOSubSystem::Update(CMemorySubject& theSubject, enOperation theOperation)
{
	// ToDo: Add your specialized code here or after the call to base class
}

HandshakeIOSubSystem::~HandshakeIOSubSystem()
{
	// ToDo: Add your specialized code here and/or call the base class
}

HandshakeIOSubSystem::HandshakeIOSubSystem(const HandshakeIOSubSystem& orig)
{
	// ToDo: Add your specialized code here and/or call the base class
}

HandshakeIOSubSystem& HandshakeIOSubSystem::operator=(HandshakeIOSubSystem& rhs)
{
	// ToDo: Add your specialized code here and/or call the base class
	
	return rhs;
}

void HandshakeIOSubSystem::CheckState(std::string& memoryID, const SubjectType operation)
{
	// TODO: Add your specialized code here.
}

void HandshakeIOSubSystem::STRAEdgeDetected(byte_t STRAvalue)
{
	// TODO: Add your specialized code here.
}


