////////////////////////////////////////////////////////////////////////////////
// File Name:       CRegisterSubject.cpp
// Description:     This is the implementation of the CRegisterSubject
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CRegisterSubject.h"

////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~CRegisterSubject
// Scope:           CRegisterSubject
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CRegisterSubject::~CRegisterSubject()
{
	//Nothing to do 
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CRegisterSubject
// Scope:           CRegisterSubject
// Return Value:    <none>
// Usage:           No-Argument Constructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the type.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CRegisterSubject::CRegisterSubject()
{
    //Set the type
    type = REGISTER_TYPE;
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CRegisterSubject
// Scope:           CRegisterSubject
// Return Value:    <none>
// Usage:           Copy Constructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Copies the useful information by calling the CMemorySubject
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CRegiste� orig            I   the object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CRegisterSubject::CRegisterSubject(const CRegisterSubject& orig)
: CMemorySubject(orig)
{
	//Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           CRegisterSubject
// Usage:           Copy assignment operator
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Assigns the data in the rhs to the lhs
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  CRegisterSubje� rhs             I/O the data to copy assign to the lhs
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  CRegisterSubje� the newly copied object
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CRegisterSubject& CRegisterSubject::operator=(CRegisterSubject& rhs)
{
   //Call base class
    CMemorySubject::operator=(rhs);
	
	return (*this);
}
