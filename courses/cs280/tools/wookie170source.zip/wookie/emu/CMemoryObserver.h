////////////////////////////////////////////////////////////////////////////////
// File Name:       CMemoryObserver.h
// Description:     This is an observer (from the pattern) of a memory object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:48:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented the observer
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CMEMORYOBSERVER_3A62105F028B_INCLUDED
#define _INC_CMEMORYOBSERVER_3A62105F028B_INCLUDED

class CMemorySubject;
enum enOperation;

class CMemoryObserver 
{
public:
	virtual void Update(CMemorySubject& theSubject, enOperation theOperation);

	~CMemoryObserver();

	CMemoryObserver();

	CMemoryObserver(const CMemoryObserver& orig);

	CMemoryObserver& operator=(CMemoryObserver& rhs);

};

#include "CMemorySubject.h"

#endif /* _INC_CMEMORYOBSERVER_3A62105F028B_INCLUDED */

