#include "stdafx.h"
#include "PortRegister.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: PortRegister
//
// Author: Paul Clarke
//
// Purpose: Constructor - Initializes the PortConnection member.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
PortRegister::PortRegister()
{
	connect = NULL;
    connect2 = NULL;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Read
//
// Author: Kalle Anderson et al.
//
// Purpose: Reads in the value of a port register.
//
// Input Parameters: None.
//
// Return Value: The byte value of the register.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
byte_t PortRegister::Read(void)
{
    Byte value;
    
    value.bit0(pins[0].GetLevel());
    value.bit1(pins[1].GetLevel());
    value.bit2(pins[2].GetLevel());
    value.bit3(pins[3].GetLevel());
    value.bit4(pins[4].GetLevel());
    value.bit5(pins[5].GetLevel());
    value.bit6(pins[6].GetLevel());
    value.bit7(pins[7].GetLevel());
    
    return value;
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Read
//
// Author: Paul Clarke
//
// Purpose: To read in the level of a particular pin of a port.
//
// Input Parameters: PinNo - The pin number (0-7).
//
// Return Value: The level of the pin (0 or 1)
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
bit_t PortRegister::Read(int PinNo)
{
  assert((PinNo >=0) && (PinNo <= 7));
	return pins[PinNo].GetLevel();
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Kalle Anderson et al.
//
// Purpose: Writes a byte value to a port.
//
// Input Parameters: data - The byte to be written to the port.  Will update the
//                    PortConnection if one is attached and one of the pins is 
//                    an output pin.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Write(byte_t data)
{
    Byte value;
    value = data;
	bit_t update = 0;

	  pins[0].Output(value.bit0());
    pins[1].Output(value.bit1());
    pins[2].Output(value.bit2());
    pins[3].Output(value.bit3());
    pins[4].Output(value.bit4());
    pins[5].Output(value.bit5());
    pins[6].Output(value.bit6());
    pins[7].Output(value.bit7());
/*	
	// If at least one of the pins is an output pin, the update the entire port
	for (int x = 0; x < 7; x++)
	{
		if (pins[x].GetMode() == Pin::OUTPUT)
		{
			update = 1;
			break;
		}
	}
*/
	if ((connect != NULL)) //&&(update)
		connect->Write(Read());
    if ((connect2 != NULL))
        connect2->Write(Read());
}

void PortRegister::ExternalWrite(byte_t data)
{
    Byte value;
    value = data;
	bit_t update = 0;

    pins[0].Input(value.bit0());
    pins[1].Input(value.bit1());
    pins[2].Input(value.bit2());
    pins[3].Input(value.bit3());
    pins[4].Input(value.bit4());
    pins[5].Input(value.bit5());
    pins[6].Input(value.bit6());
    pins[7].Input(value.bit7());
}

/*

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Input
//
// Author: Paul Clarke
//
// Purpose: To provide an input level to a particular pin of a port.  The level
//          of the pin will only be updated if the pin's direction is INPUT.
//          Will update the PortConnection if one is attached.
//
// Input Parameters: PinNo - The pin number (0-7).
//                    level - The new level of the pin.
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Input(int PinNo,bit_t level)
{
	assert((PinNo >=0) && (PinNo <= 7));
	// Pin::Input will check the direction of the pin
	pins[PinNo].Input(level);

	if (connect != NULL)
		connect->Write(Read());
}
*/
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Output
//
// Author: Paul Clarke
//
// Purpose: To provide an output level to a particular pin of a port. The level
//          of the pin will only change if the pin's direction mode is OUTPUT.
//          Will update the PortConnection if one is attached.
//
// Input Parameters: PinNo - The pin number (0-7)
//                    level - The new level of the pin.
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Output(int PinNo,bit_t level)
{
	assert((PinNo >=0) && (PinNo <= 7));
	// Pin::Input will check the direction of the pin
	pins[PinNo].Output(level);

	if (connect != NULL)
		connect->Write(Read());
    if (connect2 != NULL)
        connect2->Write(Read());
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Action
//
// Author: Paul Clarke
//
// Purpose: To change the level of a pin of a port. The level of the pin will
//          only change if the pin's direction mode is AUTO.  Will update the
//          the PortConnection if one is attached.
//
// Input Parameters:  PinNo - The pin number (0-7).
//                    level - The new level of the pin.
//
// Return Value: None.
//
// Preconditions: PinNo must be betwee 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Action(int PinNo,bit_t level)
{
	assert((PinNo >=0) && (PinNo <= 7));
	// Pin::Input will check the direction of the pin
	pins[PinNo].Action(level);

	if (connect != NULL)
		connect->Write(Read());
    if (connect2 != NULL)
        connect2->Write(Read());
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: PinInput
//
// Author: Paul Clarke
//
// Purpose: To provide an input level to a pin of a port. The level of the pin
//          will only change if the pin's direction mode is INPUT. Will update
//          the PortConnection if one is attached.
//
// Input Parameters:  PinNo - The pin number (0-7).
//                    level - The new level of the pin.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::PinInput(int PinNo, bit_t value)
{
	// Input just one pin
	assert((PinNo >= 0) && (PinNo <= 7));
 
	pins[PinNo].Input(value);

	if (connect != NULL)
		connect->Write(Read());
    if (connect2 != NULL)
        connect->Write(Read());
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Attach
//
// Author: Paul Clarke
//
// Purpose: To attach a PortConnection object to a port. If the input parameter
//          is NULL, it will not be attached.
//
// Input Parameters: pConnect - A pointer to a PortConnection object.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Attach(PortConnection* pConnect)
{
	// Attach one output object to the entire port
	if (pConnect != NULL)
		connect = pConnect;
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Attach
//
// Author: Paul Clarke
//
// Purpose: To attach a PinConnection object to a pin on a port.
//
// Input Parameters:  PinNo - The pin number (0-7).
//                    pConnect - A pointer to a PinConnection object.
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::Attach(int PinNo, PinConnection* pConnect)
{
	assert((PinNo >= 0) && (PinNo <= 7));
	
  if (pConnect != NULL)
	  pins[PinNo].Attach(pConnect);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: UnAttach
//
// Author: Kalle Anderson
//
// Purpose: To release the attachment of a PinConnection from a port's pin.
//
// Input Parameters:  PinNo - The pin number (0-7).
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::UnAttach(int PinNo)
{
	assert((PinNo >= 0) && (PinNo <= 7));

	pins[PinNo].UnAttach();
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: SetMode
//
// Author: Paul Clarke
//
// Purpose: To set the direction mode of a port's pin.
//
// Input Parameters:  PinNo - The pin number (0-7).
//                    dir - The direction mode.
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PortRegister::SetMode(int PinNo, Pin::PinDirection dir)
{
	assert((PinNo >= 0) && (PinNo <= 7));

	pins[PinNo].SetMode(dir);
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: GetMode
//
// Author: Paul Clarke
//
// Purpose: To return the direciton mode of a port's pin.
//
// Input Parameters:  PinNo - The pin number (0-7)
//
// Return Value: None.
//
// Preconditions: PinNo must be between 0 and 7 inclusively.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
Pin::PinDirection PortRegister::GetMode(int PinNo)
{
	assert((PinNo >= 0) && (PinNo <= 7));

	return pins[PinNo].GetMode();
}

byte_t PortRegister::ReadMemory() const
{
	// ToDo: Add your specialized code here
	
	return static_cast<byte_t>(0);
}

void PortRegister::WriteMemory(byte_t newValue)
{
	// ToDo: Add your specialized code here
	
	static_cast<void>(0);
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   Attach2
// Scope:           PortRegister
// Return Value:    <none>
// Usage:           Call this as a secondary attach function.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function will attach a second observer.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  PortConnection* pConnect        I/O Observer to attach to this.
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:41:08
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void PortRegister::Attach2(PortConnection* pConnect)
{
    connect2 = pConnect;
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   UnAttach2
// Scope:           PortRegister
// Return Value:    <none>
// Usage:           Call this function to unattach the secondary observer.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This function gets rid of the secondary observer.
//
// Author:          Jake & Blake
// Created:         01/28/2001 19:41:10
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
void PortRegister::UnAttach2 ()
{
    connect2 = NULL;
}
