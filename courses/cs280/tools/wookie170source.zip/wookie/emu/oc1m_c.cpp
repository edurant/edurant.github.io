////////////////////////////////////////////////////////////////////////////////
// File Name:       oc1m_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:47:02
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "oc1m_c.h"

/////////////////////////////////////////////////////////////////
// OC1M function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: Writes to the OC1M register and changes the modes of Port A pins
//					as necessary.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void OC1M_C::Write(byte_t val)
{
	byte = val;

	// The PA7 bit must be set to an output bit before the
	// pin can be changed to an automatic mode
	if (bit7())
	{
		if(portA->GetMode(7) == Pin::OUTPUT)
			portA->SetMode(7,Pin::AUTO);
	}
	else if (pactl->bit7())
		portA->SetMode(7,Pin::OUTPUT);
	else 
		portA->SetMode(7,Pin::INPUT);

	// Check to see if OC1 is controlling any other pins
	// If the individual output compares are not controlling the pin,
	// set it back to output
	if (bit6())
		portA->SetMode(6,Pin::AUTO);
	else if(!(tctl1->bit7() || tctl1->bit6()))
		portA->SetMode(6,Pin::OUTPUT);

	if (bit5())
		portA->SetMode(5,Pin::AUTO);
	else if(!(tctl1->bit5() || tctl1->bit4()))
		portA->SetMode(5,Pin::OUTPUT);

	if (bit4())
		portA->SetMode(4,Pin::AUTO);
	else if(!(tctl1->bit3() || tctl1->bit2()))
		portA->SetMode(4,Pin::OUTPUT);

	if (bit3())
		portA->SetMode(3,Pin::AUTO);
	else if(!(tctl1->bit1() || tctl1->bit0()))
		portA->SetMode(3,Pin::OUTPUT);

}

