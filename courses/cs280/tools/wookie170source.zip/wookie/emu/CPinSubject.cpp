////////////////////////////////////////////////////////////////////////////////
// File Name:       CPinSubject.cpp
// Description:     This is the implementation of the CPinSubject.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:55:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CPinSubject.h"


////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~CPinSubject
// Scope:           CPinSubject
// Return Value:    <none>
// Usage:           Destructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:55:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CPinSubject::~CPinSubject()
{
	//Nothing to do
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CPinSubject
// Scope:           CPinSubject
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the type.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:55:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CPinSubject::CPinSubject()
{
    //Set the type
    type = PIN_TYPE;
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   CPinSubject
// Scope:           CPinSubject
// Return Value:    <none>
// Usage:           Copy constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the CMemorySubject copy constructor.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CPinSubj� orig            I   the object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:55:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CPinSubject::CPinSubject(const CPinSubject& orig)
: CMemorySubject(orig)
{
	//Nothing to do 
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           CPinSubject
// Usage:           Copy assignment operator
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     This assigns the useful data to the lhs.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const CPinSubj� rhs             I   the object to copy assign
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  CPinSubject&    the newly copy assigned object
//
// Author:          Ian Kasprzak
// Created:         02/04/2001 17:01:12
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
CPinSubject& CPinSubject::operator=(const CPinSubject& rhs)
{
    //Call base class
    CMemorySubject::operator=(rhs);
	
	return (*this);
}
