#if !defined(PORTCONNECTION_H)
#define PORTCONNECTION_H

#include "basetypes.h"
#include "MemoryRegister.h"
#include "ByteRegister.h"
#include "WordRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: PortConnection
//
//  Author: Paul Clarke
//
//  Purpose: Allows a port to write a value to an object in a different module
//          or thread via virtual functions.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class PortConnection into its own header
//  12/17/2000  BPF and ILK     Changed #include "register.h" to 
//									include MemoryRegister.h, ByteRegister.h,
//									and WordRegister.h
//
/////////////////////////////////////////////////////////////////////////////

//##ModelId=3A3D099D03CC
class PortConnection
{
public:	// Port writing to GUI
	// GUI writes this function
	//##ModelId=3A3D099D03CD
	virtual void Write(byte_t);
};

#endif //!defined(PORTCONNECTION_H)
