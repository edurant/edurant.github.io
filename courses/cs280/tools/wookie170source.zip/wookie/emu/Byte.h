#if !defined(BYTE_H)
#define BYTE_H

#include "basetypes.h"

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: Byte
//
// Author: Kalle Anderson
//
// Purpose: Allows access to the bits of a byte(unsinged char).Bit-fields
//          were not used for this, because the C/C++ standard does not
//          gaurantee the ordering of bits in a bit-field.
//
//          The bit_t structure could have been a bool, but the compiler
//          would have generated extra code in order to gaurantee that the
//          value was always 0 or 1.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved struct Byte into its own header
//                              Changed struct Byte to class (made public)
//
//  01/28/2001  Ian Kasprzak    Added the big four (constructor, etc)
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099D017D
class Byte
{
public:
	~Byte();

	Byte(const Byte& rhs);

	Byte& operator=(const Byte& rhs);

	//##ModelId=3A3D099D0189
    byte_t byte;    

	//##ModelId=3A3D099D01D3
    bit_t bit0(void){return (byte&0x1);};
	//##ModelId=3A3D099D01CF
    bit_t bit1(void){return (byte&0x2)>>1;};
	//##ModelId=3A3D099D01C6
    bit_t bit2(void){return (byte&0x4)>>2;};
	//##ModelId=3A3D099D01BC
    bit_t bit3(void){return (byte&0x8)>>3;};
	//##ModelId=3A3D099D01B4
    bit_t bit4(void){return (byte&0x10)>>4;};
	//##ModelId=3A3D099D01B0
    bit_t bit5(void){return (byte&0x20)>>5;};
	//##ModelId=3A3D099D01A7
    bit_t bit6(void){return (byte&0x40)>>6;};
	//##ModelId=3A3D099D019C
    bit_t bit7(void){return (byte&0x80)>>7;};

	//##ModelId=3A3D099D01D9
    void bit0(bit_t value){byte = (byte & 0xfe) | value;};
	//##ModelId=3A3D099D01D1
    void bit1(bit_t value){byte = (byte & 0xfd) | value<<1;};
	//##ModelId=3A3D099D01C8
    void bit2(bit_t value){byte = (byte & 0xfb) | value<<2;};
	//##ModelId=3A3D099D01C4
    void bit3(bit_t value){byte = (byte & 0xf7) | value<<3;};
	//##ModelId=3A3D099D01BA
    void bit4(bit_t value){byte = (byte & 0xef) | value<<4;};
	//##ModelId=3A3D099D01B2
    void bit5(bit_t value){byte = (byte & 0xdf) | value<<5;};
	//##ModelId=3A3D099D01A9
    void bit6(bit_t value){byte = (byte & 0xbf) | value<<6;};
	//##ModelId=3A3D099D019E
    void bit7(bit_t value){byte = (byte & 0x7f) | value<<7;};

	//##ModelId=3A3D099D0194
    Byte(void){};
	//##ModelId=3A3D099D0196
    Byte(byte_t data){byte = data;};
	//##ModelId=3A3D099D0193
	operator byte_t(){return byte;}; 
	//##ModelId=3A3D099D0191
	Byte &operator=(byte_t data){byte = data;return *this;};
};

#endif //!defined(BYTE_H)
