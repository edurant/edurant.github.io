////////////////////////////////////////////////////////////////////////////////
// File Name:       pactl_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:46:38
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "pactl_c.h"

/////////////////////////////////////////////////////////////////
// PACTL function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke
//
// Purpose: Writes to the PACTL register and sets the mode of PA7 if necessary
//
// Input Parameters: val - byte to be written to the PACTL register.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void PACTL_C::Write(byte_t val)
{
	byte = val;

	// Check DDRA7 to change the mode of PA7
	if (!bit7())
		portA->SetMode(7,Pin::INPUT);
	
	// If the pin is no longer an input pin, see if OC1 will now control it
	else if (oc1m->bit7())
		portA->SetMode(7,Pin::AUTO);
	else
		portA->SetMode(7,Pin::OUTPUT);
}

