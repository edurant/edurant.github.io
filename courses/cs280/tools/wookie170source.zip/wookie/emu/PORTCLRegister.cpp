////////////////////////////////////////////////////////////////////////////////
// File Name:       PORTCLRegister.cpp
// Description:     This file defines all PORTCLRegister member functions.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "PORTCLRegister.h"


////////////////////////////////////////////////////////////////////////////////
// Function Name:   ~PORTCLRegister
// Scope:           PORTCLRegister
// Return Value:    <none>
// Usage:           Destructor
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Does nothing.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PORTCLRegister::~PORTCLRegister()
{
    //nothing
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   operator=
// Scope:           PORTCLRegister
// Usage:           Copy assignment operator.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Assigns all members from rhs to this
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const PORTCLRe� rhs             I   object to assign
//
// Return Value
//  Type            Description
//  --------------- ------------------------------------------------------------
//  PORTCLRegister& Returns a reference to the newly modifed object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PORTCLRegister& PORTCLRegister::operator=(const PORTCLRegister& rhs)
{
    //Check for self assignment
    if(this != &rhs)
    {
        ByteRegister::operator=(rhs);
    }
    
	return (*this);
}

////////////////////////////////////////////////////////////////////////////////
// Function Name:   PORTCLRegister
// Scope:           PORTCLRegister
// Return Value:    <none>
// Usage:           No-Argument Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Sets the ID for the PORTCLRegister.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PORTCLRegister::PORTCLRegister()
{
	//Set the ID
    ID = "PortCL";
}


////////////////////////////////////////////////////////////////////////////////
// Function Name:   PORTCLRegister
// Scope:           PORTCLRegister
// Return Value:    <none>
// Usage:           Copy Constructor.
// Pre-Conditions:  <none>
// Post-Conditions: <none>
// Description:     Calls the ByteRegister copy constructor.
//
// Function Arguments
//  Type            Name            Dir Description
//  --------------- --------------- --- ----------------------------------------
//  const PORTCLRe� rhs             I   object to copy
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:52:57
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
PORTCLRegister::PORTCLRegister(const PORTCLRegister& rhs)
: ByteRegister(rhs)
{
	//Nothing to do
}


