#if !defined(BYTEREGISTER_H)
#define BYTEREGISTER_H

#include "Byte.h"
#include "MemoryRegister.h"

//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: ByteRegister
//
//  Author: Kalle Anderson et al.
//
//  Purpose: A Byte object that has Read and Write operations.
//
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class ByteRegister into its own header
//
//  01/28/2001  Ian Kasprzak    Added the big four (constructor, etc)
//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099C02F9
class ByteRegister: public Byte, public MemoryRegister
{    
 public:
	ByteRegister& operator=(const ByteRegister& rhs);

	~ByteRegister();

	ByteRegister();

	ByteRegister(const ByteRegister& rhs);

	virtual byte_t ReadMemory() const;

	virtual void WriteMemory(byte_t newValue);
	
	//##ModelId=3A3D099C030D
    byte_t Read(void){return byte;};
	//##ModelId=3A3D099C0307
    void Write(byte_t data){byte = data;};

	//##ModelId=3A3D099C0305
    ByteRegister &operator=(byte_t data){byte = data;return *this;};  

	//##ModelId=3A3D099C02FC
    byte_t operator++(int){return(++byte);}
	//##ModelId=3A3D099C0304
    byte_t operator++(){return(++byte);}
};



#endif //!defined(BYTEREGISTER_H)
