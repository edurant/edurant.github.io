#include "stdafx.h"
#include "byte.h"

Byte::~Byte()
{
	// Nothing to do
}

Byte::Byte(const Byte& rhs)
{
    byte = rhs.byte;
}

Byte& Byte::operator=(const Byte& rhs)
{
    //Check for self assignment
    if(this != &rhs)
    {
        byte = rhs.byte;
    }

    return (*this);
}
