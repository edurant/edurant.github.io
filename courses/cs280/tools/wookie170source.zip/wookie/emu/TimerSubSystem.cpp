////////////////////////////////////////////////////////////////////////////
//	File:	TimerSubSystem.cpp
//	
//	Purpose:	Contains the code for the HC11 Timer subsystem
//
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "TimerSubSystem.h"
#include "HC11.h"




//////////////////////////////////////////////////////////////////////////////
//
// Function Name: TimerSubSystem
//
// Author: Kalle Anderson
//
// Purpose: Contains all of the functionality of the timer system in the HC11
//					Handles the clock division for the TCNT and the RTI
//
// Input Parameters: nhc11 - The hc11 object.  Used for access to registers and
//													 ports.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
TimerSubSystem::TimerSubSystem(HC11 *nhc11)
{
       hc11 = nhc11;
       main_clock_divider=0;
       rti_clock_divider=0;
       pulse_accumulator_clock_divider=0;    
}

//////////////////////////////////////////////////////////////////////////////
//
// Function Name: ClockSystem
//
// Author: Kalle Anderson
//
// Purpose: The function called for the timer system on every E-clock.  
//					Handles all clock division.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void TimerSubSystem::ClockSystem(void)
{ 
    int PR = hc11->regfile.PR();
	
    main_clock_divider++;

    // TCNT rate
    if((PR == 0) ||
      ((PR == 1) && !(main_clock_divider%4)) ||
      ((PR == 2) && !(main_clock_divider%8)) ||           
      ((PR == 3) && !(main_clock_divider%16)))
    {        
        // Counter overflow
        if((++hc11->regfile.TCNT) == 0)
            hc11->regfile.TOF(1);
    }
        
    // The base RTI rate
	if(!(main_clock_divider % (1<<13)))
	{
		rti_clock_divider++;
        // RTI is further divided by RTR
		if(!(rti_clock_divider%(1<<hc11->regfile.RTR())))		
            hc11->regfile.RTIF(1);		
	}

	DoPulseAccumulator_GatedTimeAccumulationMode();
	DoOutputCompares();

};


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: DoOutputCompares
//
// Author: Paul Clarke et al.
//
// Purpose: To check and see if an output compare has fired.  If it has, to 
//					do the appropriate action on a pin or generate an interrupt.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void TimerSubSystem::DoOutputCompares(void)
{
	// Check TCNT vs. all of the TOCx registers
	word_t tcnt = hc11->regfile.TCNT.Read();

  bit_t has_control2 = 0;
	bit_t has_control3 = 0;
	bit_t has_control4 = 0;
	bit_t has_control5 = 0;


  // OC1 has priority over all pins
	if (tcnt == hc11->regfile.TOC1.Read())
	{
			// Set the flag
		hc11->regfile.OC1F(1);

		// Check the control bits and set pin levels if necessary
	    if (hc11->regfile.OC1M3())
        {
		    hc11->regfile.PORTA.Action(3,hc11->regfile.OC1D3());
            has_control5 = 1;
        }
	    if (hc11->regfile.OC1M4())
        {
		    hc11->regfile.PORTA.Action(4,hc11->regfile.OC1D4());
            has_control4 = 1;
        }
	    if (hc11->regfile.OC1M5())
        {
		    hc11->regfile.PORTA.Action(5,hc11->regfile.OC1D5());
            has_control3 = 1;
        }
	    if (hc11->regfile.OC1M6())
        {
		    hc11->regfile.PORTA.Action(6,hc11->regfile.OC1D6());
            has_control2 = 1;
        }
	    if (hc11->regfile.OC1M7())
			    hc11->regfile.PORTA.Action(7,hc11->regfile.OC1D7());
	}

	// OC2, PA6
	if (tcnt == hc11->regfile.TOC2.Read())
	{
		// Set the flag
		hc11->regfile.OC2F(1);
		
		bit_t ol6 = hc11->regfile.OL2();
		bit_t om6 = hc11->regfile.OM2();
	
		// Check the output compare enabling bits
        if (!has_control2)
        {
          switch((om6<<1)|ol6)
		  {
			  case 0x0:		// does not affect pin
				  break;
			  case 0x1:		// toggles pin
				  hc11->regfile.PORTA.Action(6,!hc11->regfile.PORTA.Read(6));
				  break;
			  case 0x2:		// clears pin
				  hc11->regfile.PORTA.Action(6,0);
				  break;
			  case 0x3:		// sets pin
				  hc11->regfile.PORTA.Action(6,1);
				  break;
			  default:	assert(false);
		  }		
        }
	}

	// OC3, PA5
	if (tcnt == hc11->regfile.TOC3.Read())
	{
		// Set the flag
		hc11->regfile.OC3F(1);
		
		bit_t ol5 = hc11->regfile.OL3();
		bit_t om5 = hc11->regfile.OM3();
	
		// Check the output compare enabling bits
        if (!has_control3)
        {
          switch((om5<<1)|ol5)
		  {
			  case 0x0:		// does not affect pin
				  break;
			  case 0x1:		// toggles pin
				  hc11->regfile.PORTA.Action(5,!hc11->regfile.PORTA.Read(5));
				  break;
			  case 0x2:		// clears pin
				  hc11->regfile.PORTA.Action(5,0);
				  break;
			  case 0x3:		// sets pin
				  hc11->regfile.PORTA.Action(5,1);
				  break;
			  default:	assert(false);
		  }
        }
	}
	

	// OC4, PA4
	if (tcnt == hc11->regfile.TOC4.Read())
	{
		// Set the flag
		hc11->regfile.OC4F(1);
				
		bit_t ol4 = hc11->regfile.OL4();
		bit_t om4 = hc11->regfile.OM4();
	
		// Check the output compare enabling bits
		if (!has_control4)
        {
          switch((om4<<1)|ol4)
		  {
			  case 0x0:		// does not affect pin
				  break;
			  case 0x1:		// toggles pin
				  hc11->regfile.PORTA.Action(4,!hc11->regfile.PORTA.Read(4));
				  break;
			  case 0x2:		// clears pin
				  hc11->regfile.PORTA.Action(4,0);
				  break;
			  case 0x3:		// sets pin
				  hc11->regfile.PORTA.Action(4,1);
				  break;
			  default:	assert(false);
		  }
        }		
	}


	// OC5, PA3
	if (tcnt == hc11->regfile.TI4O5.Read())
	{
		// Set the flag
		hc11->regfile.I4O5F(1);
		
		bit_t ol3 = hc11->regfile.OL5();
		bit_t om3 = hc11->regfile.OM5();
	
		// Check the output compare enabling bits
		if (!has_control5)
        {
          switch((om3<<1)|ol3)
		  {
			  case 0x0:		// does not affect pin
				  break;
			  case 0x1:		// toggles pin
				  hc11->regfile.PORTA.Action(3,!hc11->regfile.PORTA.Read(3));
				  break;
			  case 0x2:		// clears pin
				  hc11->regfile.PORTA.Action(3,0);
				  break;
			  case 0x3:		// sets pin
				  hc11->regfile.PORTA.Action(3,1);
				  break;
			  default:	assert(false);
		  }
        }
	}
}



//////////////////////////////////////////////////////////////////////////////
//
// Function Name: DoPulseAccumulator_GatedTimeAccumulationMode
//
// Author: Jason Buttron
//
// Purpose: This functions handles the the function of the Pulse
//			Accumulator when it is in the Gated Time Accumulation Mode. 
//
// Input Parameters: Nne.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////

void TimerSubSystem::DoPulseAccumulator_GatedTimeAccumulationMode(void)
{
	if(hc11->regfile.PAEN() & hc11->regfile.PAMOD())    ///Pulse Accumulator Gated-Time accumulation mode
	{
		if(!(main_clock_divider%64))			//E clock/64
		{
			if(hc11->regfile.PORTA.Read(7)==hc11->regfile.PEDGE())  //decide edge to count
			{				     
				if(!(++hc11->regfile.PACNT))		
					hc11->regfile.PAOVF(1);		//send interupt				
			}	
		}
	}
}
