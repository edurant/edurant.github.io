#include "stdafx.h"
#include "Pin.h"
#include "PortConnection.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Input
//
// Author: Paul Clarke
//
// Purpose: To input a level to a pin.  The level of the pin will only change
//          if the pin's direction mode is INPUT. The PinConnection is updated
//          if one is attached.
//
// Input Parameters: value - The new level of the pin (0 or 1).
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void Pin::Input(bit_t value) 
{ 
	if (mode == Pin::INPUT) 
	{
		level = value;
		if (connect != NULL) 
			connect->Set(level); 
	}
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Output
//
// Author: Paul Clarke
//
// Purpose: To output a level to a pin.  The level of the pin will only change
//          if the pin's direction mode is OUTPUT.  The PinConnection will be
//          updated if one is attached.
//
// Input Parameters: value - The new level of the pin (0 or 1).
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void Pin::Output(bit_t value)	
{	
	if (mode == Pin::OUTPUT) 
	{
		level=value;
		if (connect != NULL) 
			connect->Set(level); 
	}
}
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Action
//
// Author: Paul Clarke
//
// Purpose: To set the level of a pin.  The level of the pin will only be 
//          changed if the pin's direction mode is AUTO.  The PinConnection will
//          be updated if one is attached.
//
// Input Parameters: None.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void Pin::Action(bit_t value)
{
	if (mode == AUTO)
	{
		level = value;
		if (connect != NULL)
			connect->Set(level);
	}
}

byte_t Pin::ReadMemory() const
{	
	return level;
}

void Pin::WriteMemory(byte_t newValue)
{
    //Make sure we only have a one or a zero
    newValue = newValue & 0x1;
    
   level = newValue;
}

Pin::~Pin()
{
	// Nothing to do
}

Pin::Pin(const Pin& rhs)
: CPinSubject(rhs)
{
    connect = rhs.connect;

    mode = rhs.mode;

    level = rhs.level;
}

Pin& Pin::operator=(const Pin& rhs)
{
    if(this != (&rhs) )
    {
        CPinSubject::operator=(rhs);
    
        connect = rhs.connect;

        mode = rhs.mode;

        level = rhs.level;
    }

	return (*this);
}


