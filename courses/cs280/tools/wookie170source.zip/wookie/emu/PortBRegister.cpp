#include "stdafx.h"
#include "PortBRegister.h"
#include "HC11.h"


/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////


PortBRegister::PortBRegister()
{
  // Make Port B an output port
  for(int i=0;i<8;i++)
      SetMode(i, Pin::OUTPUT);   
}


//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Kalle Anderson
//
// Purpose: PortB needs some special stuff cause it is associated with
//          the handshake IO system.
//
// Input Parameters:  byte_t value
//                    
// Return Value: None.
/////////////////////////////////////////////////////////////////////////////

void PortBRegister::Write(byte_t data)
{
    PortRegister::Write(data);
    hc11->handshake_system->WriteToPORTB();
}