////////////////////////////////////////////////////////////////////////////////
// File Name:       tflg_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:37:13
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(TFLG_C_H)
#define TFLG_C_H

#include "ByteRegister.h"

//##ModelId=3A3D099D001F
class TFLG_C: public ByteRegister
{
public:
	//##ModelId=3A3D099D0021
    void Write(byte_t data);
    //  void Set(byte_t val); 
};

#endif //!defined(TFLG_C_H)
