////////////////////////////////////////////////////////////////////////////////
// File Name:       CMemorySubject.h
// Description:     This is a subject (from the pattern) of a memory object.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:50:00
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented class
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CMEMORYSUBJECT_3A62109A033A_INCLUDED
#define _INC_CMEMORYSUBJECT_3A62109A033A_INCLUDED

#include "basetypes.h"


class CMemoryObserver;

enum enOperation
{
    READ_OPERATION,
    WRITE_OPERATION
};

enum SubjectType
{
    REGISTER_TYPE,
    PIN_TYPE,
    INVALID_TYPE
};

class CMemorySubject 
{
public:
	virtual ~CMemorySubject();

	CMemorySubject();

	CMemorySubject(const CMemorySubject& orig);

	void Attach(CMemoryObserver& newObserver);

	void Detach(CMemoryObserver& removeSubject);

	void Notify(enOperation operation);

	virtual byte_t ReadMemory () const = 0;

	virtual void WriteMemory(byte_t newValue) = 0;

	const std::string& GetID() const;

	SubjectType get_type() const;

	CMemorySubject& operator=(const CMemorySubject& rhs);

protected:
	SubjectType type;

    std::string ID;

private:

    set<CMemoryObserver*> m_setObservers;

};

#include "CMemoryObserver.h"

#endif /* _INC_CMEMORYSUBJECT_3A62109A033A_INCLUDED */

