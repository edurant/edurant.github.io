////////////////////////////////////////////////////////////////////////////////
// File Name:       CRegisterSubject.h
// Description:     This is a non-abstract subject.
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:51:15
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented class
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CREGISTERSUBJECT_3A62184002BD_INCLUDED
#define _INC_CREGISTERSUBJECT_3A62184002BD_INCLUDED

#include "CMemorySubject.h"

class CRegisterSubject 
: public CMemorySubject
{
public:
	virtual ~CRegisterSubject();

	CRegisterSubject();

	CRegisterSubject(const CRegisterSubject& orig);

	CRegisterSubject& operator=(CRegisterSubject& rhs);
};

#endif /* _INC_CREGISTERSUBJECT_3A62184002BD_INCLUDED */

