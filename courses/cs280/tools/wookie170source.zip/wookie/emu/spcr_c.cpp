////////////////////////////////////////////////////////////////////////////////
// File Name:       spcr_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:50:27
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "spcr_c.h"

/////////////////////////////////////////////////////////////////
// SPCR function overrides
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Paul Clarke, Jason Buttron
//
// Purpose: Writes a byte to the SPCR register, updates the mode of Port D
//					pins as necessary.
//
// Input Parameters: val - byte to be written to the SPCR register.
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void SPCR_C::Write(byte_t val)
{
	byte = val;

	// Check the DWOM bit to see if PORTD is being controlled by
  // the SCI

  // THIS WAS COMMENTED OUT BECAUSE THE SCI ONLY MAKES THE PORTD
  // PINS AS OPEN_DRAIN PINS, NOT PINS THAT CANNOT BE WRITTEN TO

/*	if (bit5())
	{
		// Take control of the PORTD pins
		for (int i = 0; i < 6; i++)
		{
			portD->SetMode(i,Pin::AUTO);
		}
	}
	else 
	{
		// Disable the AUTO setting we setup before
		for (int x = 0; x < 6; x++)
		{
			portD->SetMode(x,Pin::OUTPUT);
		}

		// Now go by the DDRD
		ddrd->Write(ddrd->Read());
	}
  */
}