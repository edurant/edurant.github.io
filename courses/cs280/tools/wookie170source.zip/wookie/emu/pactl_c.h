////////////////////////////////////////////////////////////////////////////////
// File Name:       pactl_c.h
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:36:45
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#if !defined(PACTL_C_H)
#define PACTL_C_H

#include "ByteRegister.h"
#include "PortRegister.h"

//##ModelId=3A3D099D010F
class PACTL_C : public ByteRegister
{
public:
	//##ModelId=3A3D099D0128
    void Write(byte_t data);
	//##ModelId=3A3D099D0125
    PortRegister* portA;
	//##ModelId=3A3D099D011B
    ByteRegister* oc1m;
};

#endif //!defined(PACTL_C_H)
