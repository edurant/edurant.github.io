#if !defined(PORTBREGISTER_H)
#define PORTBREGISTER_H

#include "basetypes.h"

#include "MemoryRegister.h"
#include "ByteRegister.h"
#include "WordRegister.h"

#include "DDRegister.h"
#include "PortRegister.h"
class HC11;

//////////////////////////////////////////////////////////////////////////////
//
// Class Name: PortBRegister
//
// Author: Kalle Anderson
//
// Purpose: The override of a PortRegister so special events may happen
//          when Port B is changed.  This class is mainly used to capture
//          inputs on the pins.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class PortBRegister into its own header
//                              Removed the keyword 'class' from before HC11
//  12/17/2000  BPF and ILK     Changed #include "register.h" to 
//									include MemoryRegister.h, ByteRegister.h,
//									and WordRegister.h

//
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D099C017C
class PortBRegister: public PortRegister
{
 private:
	//##ModelId=3A3D099C0188
    HC11 *hc11;
 public:	
	//##ModelId=3A3D099C0193
    PortBRegister();
	//##ModelId=3A3D099C0191
    void SetHC11(HC11 *mcu){hc11 = mcu;};    
	//##ModelId=3A3D099C018B
	void Write(byte_t data);
    friend class DDRegister;
};

#endif //!defined(PORTBREGISTER_H)
