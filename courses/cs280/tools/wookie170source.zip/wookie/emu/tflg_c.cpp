////////////////////////////////////////////////////////////////////////////////
// File Name:       tflg_c.cpp
// Description:     ...
//
// Author:          Blake C. Adams
// Created:         12/10/2000 16:49:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "tflg_c.h"

/////////////////////////////////////////////////////////////////
// TFLG1 and TFLG2
//////////////////////////////////////////////////////////////////////////////
//
// Function Name: Write
//
// Author: Curious George
//
// Purpose: Writes to a TFLG register.  A bit is cleared in this register
//					if a one is written to it.
//
// Input Parameters: mask - The mask of what bits to clear
//
// Return Value: None.
//
// Preconditions: None.
//
// Post Conditions: None.
//
/////////////////////////////////////////////////////////////////////////////
void TFLG_C::Write(byte_t mask)
{
	byte &= ~mask;
}

/*void TFLG_C::Set(byte_t val)
{
byte = val;
}*/
	
