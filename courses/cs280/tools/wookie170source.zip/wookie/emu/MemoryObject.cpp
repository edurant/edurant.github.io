#include "stdafx.h"
#include "MemoryObject.h"

/////////////////////////////////////////////////////////////////////////////
//
//  Modifications:
//
//  12/10/2000  BCA and BPF     Moved code into its own source file
//          
/////////////////////////////////////////////////////////////////////////////

MemoryObject::MemoryObject()
{
    enable = true;
}

void MemoryObject::Move(word_t new_base)
{
    int new_top;
        
    new_top = new_base + size;
    // maximum address is 0xffff, so truncate this block at 0xffff    
    if(new_top > 0xffff)
        new_top = 0xffff;

    base_addr = new_base;
    top_addr = new_top;
}