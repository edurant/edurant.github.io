#if !defined(PORTREGISTER_H)
#define PORTREGISTER_H

#include "basetypes.h"
#include "Pin.h"
#include "PortConnection.h"
#include "MemoryRegister.h"


//////////////////////////////////////////////////////////////////////////////
//
//  Class Name: PortRegister
//
//  Author: Kalle Anderson
//
//  Purpose: Handles all port operations and all of the operation of pins.
//
//  Modifications:
//
//  12/10/2000  BCA and ILK     Moved class PortRegister into its own header
//
// Created:         01/28/2001 19:42:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Jake & Blake    Added the connect2 member and the secondary attach
//                              and detach functions.  These were needed to attach
//                              both the PORTC io and the Keypad simultaneously.
//                              A prefered method for this would have been to add
//                              a list or set of observers to the port register
//                              class but that would break to many interfaces.
/////////////////////////////////////////////////////////////////////////////
//##ModelId=3A3D09AF00A7
class PortRegister: public MemoryRegister
{
 protected:
	//##ModelId=3A3D09AF00C5
    Pin pins[8];
	//##ModelId=3A3D09AF00B3
    PortConnection* connect;
    PortConnection* connect2;

 public:
	virtual byte_t ReadMemory() const;

	virtual void WriteMemory(byte_t newValue);
	

	//##ModelId=3A3D09AF0104
	PortRegister();

	// SIMULATOR INTERFACE TO PORT  
	//##ModelId=3A3D09AF00FB
    byte_t Read(void);
	//##ModelId=3A3D09AF0102
	bit_t  Read(int PinNo);
	
	// These functions will update the pins
	//##ModelId=3A3D09AF00F9
	void Write(byte_t data);

    void ExternalWrite(byte_t data);

	// GUI INTERFACE TO PINS
	//##ModelId=3A3D09AF00EE
 	void Attach(PortConnection* pConnect);
	//##ModelId=3A3D09AF00F0
	void Attach(int PinNo, PinConnection* pConnect);
	//##ModelId=3A3D09AF00E5
    void UnAttach(void){connect = NULL;};
	//##ModelId=3A3D09AF00E7
    void UnAttach(int PinNo);

    // Secondary attach and detach
    void Attach2(PortConnection* pConnect);
    void UnAttach2 ();

	//##ModelId=3A3D09AF00DD
	virtual void PinInput(int PinNo,bit_t value);

	//##ModelId=3A3D09AF00DA
	void SetMode(int PinNo, Pin::PinDirection dir);
	//##ModelId=3A3D09AF00D3
	Pin::PinDirection GetMode(int PinNo);
    
    // !must make sure this can't be read/written to without using read/write!
	//##ModelId=3A3D09AF00D0
    void Action(int PinNo,bit_t level);
	//##ModelId=3A3D09AF00C8
	void Output(int PinNo,bit_t level);

	friend class DDRegister;
};


#endif //!defined(PORTREGISTER_H)
