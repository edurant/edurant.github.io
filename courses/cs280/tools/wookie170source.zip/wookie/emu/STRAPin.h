////////////////////////////////////////////////////////////////////////////////
// File Name:       STRAPin.h
// Description:     This is the STRA pin on the M68HC11
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:53:25
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Implemented class
////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2001 MSOE

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_STRAPIN_3A6B484D0281_INCLUDED
#define _INC_STRAPIN_3A6B484D0281_INCLUDED

#include "Pin.h"

class STRAPin 
: public Pin
{
public:
	~STRAPin();

	STRAPin& operator=(const STRAPin& rhs);

	STRAPin();

	STRAPin(const STRAPin& rhs);

};

#endif /* _INC_STRAPIN_3A6B484D0281_INCLUDED */

