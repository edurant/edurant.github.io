////////////////////////////////////////////////////////////////////////////////
// File Name:       MemoryRegister.cpp
// Description:     ...
//
// Author:          Ian Kasprzak
// Created:         01/28/2001 16:32:52
// Revision History
//  Date        Who             Description
//  ----------- --------------- ------------------------------------------------
//  01/28/2001  Ian Kasprzak    Added copy constructor

////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MemoryRegister.h"


MemoryRegister::MemoryRegister()
{
    //Nothing to do
}

MemoryRegister::MemoryRegister(const MemoryRegister& rhs)
: CRegisterSubject(rhs)
{
}
