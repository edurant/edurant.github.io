/* $Id$ */

/* display.h
   Functions for the four character display
   by Steven L. Barnicki
   updates for GCC 3.0.4 by EAD 28 February 2003
*/

#ifndef _DISPLAY_H
#define _DISPLAY_H

#include <msoe/common.h>
#include <msoe/ports.h>

#ifdef __cplusplus
extern "C" {
#endif

void showstring(const char* sin);
void showchar(int pos, char ch);  /* positions are 1234 from left */

/* next function written by Henry Welch */
char digit2ascii(byte digit);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _DISPLAY_H */
