/* $Id$ */
/***************************************/
/* Ports.h, version 2.1                */
/*   by Steven L. Barnicki, 2/1/99     */
/*   2/5/99 changed adctl spelling-SLB */
/***************************************/
/* Updates for GCC 3.0.4 EAD 28 February 2003 */

#ifndef _PORTS_H
#define _PORTS_H

#include <msoe/common.h>

#ifdef __cplusplus
extern "C" {
#endif

  extern volatile byte porta;
  extern volatile byte pioc;
  extern volatile byte portc;
  extern volatile byte portb;
  extern volatile byte portcl;
  extern volatile byte ddrc;
  extern volatile byte portd;
  extern volatile byte ddrd;
  extern volatile byte porte;
  extern volatile byte cforc;
  extern volatile byte oc1m;
  extern volatile byte oc1d;
  extern volatile word tcnt;
  extern volatile word tic1;
  extern volatile word tic2;
  extern volatile word tic3;
  extern volatile word toc1;
  extern volatile word toc2;
  extern volatile word toc3;
  extern volatile word toc4;
  extern volatile word ti4;
  extern volatile byte tctl1;
  extern volatile byte tctl2;
  extern volatile byte tmsk1;
  extern volatile byte tflg1;
  extern volatile byte tmsk2;
  extern volatile byte tflg2;
  extern volatile byte pactl;
  extern volatile byte pacnt;
  extern volatile byte spcr;
  extern volatile byte spsr;
  extern volatile byte spdr;
  extern volatile byte baud;
  extern volatile byte sccr;
  extern volatile byte sccr;
  extern volatile byte scsr;
  extern volatile byte scdr;
  extern volatile byte adctl;
  extern volatile byte adr1;
  extern volatile byte adr2;
  extern volatile byte adr3;
  extern volatile byte adr4;
  extern volatile byte bprot;
  extern volatile byte eprog;
  extern volatile byte option;
  extern volatile byte coprst;
  extern volatile byte pprog;
  extern volatile byte hprio;
  extern volatile byte init;
  extern volatile byte test1;
  extern volatile byte config;

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _PORTS_H */
