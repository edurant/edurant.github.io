/* $Id$ */
/*
   display.h
   Functions for the four character display

   by Steven L. Barnicki - 2/7/98
   modified SLB 2/1/99
   modified HW 2/5/99
*/

#include <msoe/display.h>
#include <msoe/time.h>

void showstring(const char* sin)
{
  const byte* s=sin;
  byte j;
  byte temp;
  byte pos=4;
  byte oldddrc;

  /* save old ddrc */
  oldddrc=ddrc;

  /* set port c direction out */
  ddrc = oldddrc | 0x03;

  /* invert sense of STRB */
  j=pioc;
  j=j & 0xfe; /* reset bit 0 to 0 */
  pioc=j;

  while( *s != '\0' )
  {
    if (pos==0)
      {
      pos=4;
      s-=3;
      wait(250);
      }
    else  /* ok to print */
      {
      temp=pos-1;
      temp=temp & 0x03;       /* keep only 2 least significant bits */
      j=portcl;
      j=(j & 0xfc) | temp;       /* only affect 2 lower bits */
      portcl=j;
      pos--;
      portb=(*s);
      s++;
      }
  }
  /* restore original ddrc */
  ddrc=oldddrc;
} /* showstring() */

void showchar(int pos, char ch)
{
  byte npos;
  byte j;
  byte temp;
  byte oldddrc;

  /* save old ddrc */
  oldddrc=ddrc;

  /* set port c direction out */
  ddrc = oldddrc | 0x03;

  /* invert sense of STRB */
  j=pioc;
  j=j & 0xfe; /* reset bit 0 to 0 */
  pioc=j;
  /* the position     maps       */
  /* on display      in function */
  /*    3210           1234      */
  npos=pos-1;
  npos=~npos;
  npos=npos & 0x03; /* only keep the 2 LSB */

  j=portcl;
  j=(j & 0xfc) | npos;       /* only affect 2 lower bits */
  portcl=j;

  portb=ch;                  /* Output character */

  /* restore original ddrc */
  ddrc=oldddrc;
}  /* showchar() */


/*********************************************************
**                                                      **
**                                                      **
** Written by: H. Welch 29-January-1999                 **
**                                                      **
** Special Needs: MSOE Development Platform             **
**                                                      **
**                                                      **
** digit2ascii - Converts a single digit value 0-9,A-F  **
**               to appropriate ASCII character.        **
**                                                      **
** Parameters   digit - The digit to convert            **
**                                                      **
** Returns ASCII character equivalent of the digit      **
**                                                      **
** Calls <NONE>                                         **
**                                                      **
** Globals <NONE>                                       **
**                                                      **
*********************************************************/
char digit2ascii(byte digit)
{
	/* Determine if digit 0-9 or letter A-F */
	if (digit <= 9)
		return digit+'0';               /* Digit */
	else if (digit <= 0xF)
		return digit-10+'A';            /* Letter */
	else
		return ' ';                     /* Other is space */
}
