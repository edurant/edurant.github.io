Documentation for gnu-68hc1x-3.0-msoe.zip
by Dr. E. Durant <durant@msoe.edu>
First Release 9 March 2004
Second Release 3 January 2005 (msoe.x fixes: _io_ports, etc.)
Third Release 6 March 2005 (Chain 2.2 to 3.0 updates, Fox11 updates)

The accompanying .zip archive contains local customizations for using 
the latest GNU toolchain for the HC11 with both the MSOE briefcase and 
Fox11 board.  In particular, a linker configuration file (briefcase.x) 
is included that knows about the 0-page memory layout of the briefcase 
with the standard talker, as is a file (fox11w.x) for the Fox11 board 
using the powerful Wytec talker.  Also included are library functions 
that will be useful in some CS280 labs.

RESOURCES

http://www.gnu-m68hc11.org/ [latest]
http://stephane.carrez.free.fr/m68hc11_port.php [alternate site]
http://groups.yahoo.com/group/gnu-m68hc11/ [good help resource]
http://www.gnu.org/software/m68hc11/ [out of date]

INSTALLATION

Installing these localizations is step 2 of the 4-step tool installation process
described at http://people.msoe.edu/~durant/courses/cs280/tools.shtml .

The accompanying .zip file should be extracted into the root of your C:\ drive.
It is necessary to preserve pathnames.

Several MSOE-related files will be created in C:\usr\..., which was created
in step 1 when you installed the GNU toolchain.

Also, C:\data\msoe\cs280 will be created with some needed files and a directory.
You may move the contents of this cs280 directory to any convenient location on
your system.  This directory will be called your "root working directory".

It is convenient to be able to quickly open a command prompt to your root working
directory.  Microsoft makes a property menu extension that allows you to right-click
on a directory in Windows Explorer and then open a command prompt in that directory
with 1 click.  If you wish to install this, see the following...

For Windows XP: http://www.microsoft.com/windowsxp/pro/downloads/powertoys.asp

It is recommended that you create directories named "lab1", "lab2", etc. 
in your root working directory and store your source code in those 
directories.

After opening a command window, you must run "gccvars" to set up the
environment for that command window so that the GNU tools can be found.  If
you open a window in your lab1 directory, you would type "..\gccvars" (without
the quotation marks) and press enter.

To get started, let's assume that you have an assembly source file named
lab1.s in your lab1 directory and you have followed the steps above.
Then, you will find the following commands useful...

Assemble with:  as -o lab1.o lab1.s
Link with:      ld -T ../fox11w.x -o lab1.elf lab1.o
Convert to S19: objcopy -O srec lab1.elf lab1.s19
Create listing: objdump -d lab1.elf > lab1.rst

The S19 file can be run on both Wookie (you must specify the correct 
starting address) and the Fox11 board (download with WBUG11 via AsmIDE).

Wookie (>= 1.68) will recognize lab1.rst as a valid disassembly in GCC3 format.
