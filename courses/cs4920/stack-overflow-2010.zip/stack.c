/* an example of how the stack looks during a call to a function
** (stack.c)
** to build execute:
** make stack
** Written by: JiM Strassburg 01/18/2000 */

void function(int a, char* str)
{
  char buf0[3];
  char buf1[5];
  char buf2[10];
}

int main(int argc, char* argv[])
{
  function(10,"test string"); /* call the function with args */
  return 0;
}
