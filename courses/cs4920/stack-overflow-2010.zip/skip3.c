#include <stdio.h>

#define   OFFSET  7 /* Ubuntu 8.04   gcc 4.2.4 i686 */

#define EXTRA_STACK 0 /* Ubuntu 8.04  gcc 4.2.4 i686 */

void function()
{
  char buf0[4];
  int *returnAddress; /* a pointer to a word */
  // note byte (not int) math on right side of assignment operator...
  returnAddress = (int*) (buf0 // our stack begin
			+ sizeof(buf0) + sizeof(int*) // move down past locals on this stack
			+ EXTRA_STACK); // move down further if needed due to compiler code generation.
  (*returnAddress) += OFFSET;
}

int main(int argc, char* argv[])
{
  int x = 0x1234; /* initialize x */
  function(); /* call the function to modify the return address */
  x = 0x5678; /* we're going to skip this line of code */
  printf("x=0x%x\n",x); /* print the value of x which should be 0x1234 */
  return 0;
}
