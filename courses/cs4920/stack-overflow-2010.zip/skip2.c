/* skip2.c - example of how program flow can be altered
 * a line of code will be skipped during execution
 * to build execute
 * Based on code by: JiM Strassburg 01/29/2000
 * See skip.c for intermediate updates
 * Updated by: Eric Durant 5/5/2010 (offsets more complicated in new compiler, use disassembly approach)
 */

#include <stdio.h>

// OFFSET is the (effective) length of the assignment to x instruction
#define   OFFSET  7 /* Ubuntu 8.04   gcc 4.2.4 i686 */

// EXTRA_STACK is the additional space the compiler needs on the function call stack
// beyond what we would minimally expect for a literal compile.
#define EXTRA_STACK 0 /* Ubuntu 8.04  gcc 4.2.4 i686 */

void function()
{
  char buf0[4];
  int *returnAddress; /* a pointer to a word */
  // note byte (not int) math on right side of assignment operator...
  returnAddress = (int*) (buf0 // our stack begin
			+ sizeof(buf0) + sizeof(int*) // move down past locals on this stack			+ EXTRA_STACK); // move down further if needed due to compiler code generation.
  (*returnAddress) += OFFSET;
  /* return OFFSET bytes later than we should,
     skipping the x = 0x5678 assignment */
}
int main(int argc, char* argv[])
{
  int x = 0x1234; /* initialize x */
  function(); /* call the function to modify the return address */
  x = 0x5678; /* we're going to skip this line of code */
  printf("x=0x%x\n",x); /* print the value of x which should be 0x1234 */
  return 0;
}
