/* a typical (but simple) example of a vulnerable application (vulnerable.c)
 *
 * Written by : JiM Strassburg 02/05/2000
 * based on code written by: Aleph One
 *
 */

#include <stdio.h>

void main(int argc, char* argv[])
{
  char buffer[512];
  if (argc < 2)
    exit(fprintf(stderr,"Usage : %s <string>\n",argv[0]));
  strcpy(buffer, argv[1]);
}
