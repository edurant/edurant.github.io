/* this is the code necessary to launch a shell
 * (shell.c)
 * to build execute
 * make shell
 * Written by : JiM Strassburg 01/30/2000
 * Modified by: Eric Durant 5/5/2006 (added output if execve returns - unexpected)
 */
#include <stdio.h>

int main()
{
  char* shell[] = {"/bin/sh",NULL};
  execve(shell[0],shell,NULL);
  printf("%s\n", "execve() returned!"); // EAD 5/5/2006
  exit(0);
  return 0;
}
