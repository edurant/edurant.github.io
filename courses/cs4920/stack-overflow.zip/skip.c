/* An example of how program flow can be altered
 * a line of code will be skipped during execution
 * (skip.c)
 * to build execute
 * make skip
 * Written by: JiM Strassburg 01/29/2000
 * Updated by: Eric Durant 5/5/2006 (OFFSET for compiler, different constants for clarity)
 */

#include <stdio.h>

#define   OFFSET  7 /* Ubuntu 5.04   gcc 3.3.5 i386 */
//#define OFFSET 10 /* Fedora Core 2 gcc 3.3.3 i386 */
//#define OFFSET  8 /* Red Hat 6.1   egcs 2.91 i386*/

void function(int a)
{
  char buf0[4];
  int *returnAddress; /* a pointer to a word */
  returnAddress = buf0 + 8;
  (*returnAddress) += OFFSET;
  /* return OFFSET bytes later than we should,
     skipping the x = 0x5678 assignment */
}
int main(int argc, char* argv[])
{
  int x = 0x1234; /* initialize x */
  function(1); /* call the function to modify the return address */
  x = 0x5678; /* we're going to skip this line of code */
  printf("x=0x%x\n",x); /* print the value of x which should be 1 */
  return 0;
}
