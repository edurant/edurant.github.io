/* an example of what happens when a buffer is overflown
** (overflow.c)
** to build execute:
** make overflow
** Written by: JiM Strassburg 01/22/2000 */

void function(char *str)
{
  char buf0[5];
  strcpy(str,buf0); /* strcpy does no bounds checking */
}

int main(int argc, char* argv[])
{
  function("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
/* call the function with a string that is too big for the buffer*/
  return 0;
}
